# TuTienCore 4.5.5 PREMIUM — patch notes

- Ngự Kiếm: corrected the lateral/right-vector Z sign in `DefaultMovementController`; A/D strafing should now stay consistent as yaw changes.
- Class skills: added lightweight, class-themed particle rings and directional streaks for the six paths; no custom model/resource pack is required for these visuals.
- Cloud build workflow: Java 21 + Maven; the JAR is uploaded as a GitHub Actions artifact after a successful build.

Important: this is a source patch, not a verified release. The build and in-game movement still need to be tested on Paper 1.21.11. If the sword itself appears rotated incorrectly, that is a separate ItemDisplay transform/model-orientation issue and should be checked with a screenshot/video from the server.
