# TuTienCore 3.0.0 — Release Notes

## Bản cập nhật toàn diện
3.0.0 đóng gói lại nền tảng TuTienCore thành bản HyperVN release: cultivation, MMORPG combat, phái/kỹ năng, Pháp Tướng, đột phá/độ kiếp, Ngự Kiếm, Tông Môn, dungeon, quest, alchemy, artifact, pet, rank, cosmetics và công cụ quản trị.

### Compatibility
- Java 21
- Paper API 1.21.11
- Vault
- WorldEdit
- WorldGuard
- Các hook mềm được khai báo trong `plugin.yml`

### Build
```bash
mvn clean package
```
JAR đầu ra nằm trong `target/`.


## Quest Update
- `/nhiemvu` mở GUI Nhiệm Vụ Tu Tiên, nhận thưởng ngày/tuần trực tiếp.
- `/autoquest` tạo NPC **Trưởng Lão** cách người chơi 2 block, có sẵn quest; click NPC mở GUI quest.
- `/autoquest remove` xóa Trưởng Lão quest gần người chơi.
