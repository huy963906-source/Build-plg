# TuTienCore 4.2.0

## Update 4.2.0
- Ngự Kiếm: model CustomModelData `67`, tốc độ bay tăng, A/D được chuẩn hóa tại PaperInputProvider.
- `/ngukiem`: yêu cầu Trúc Cơ Tầng 1+.
- `/donthuat`: yêu cầu Kim Đan Tầng 1+.
- Đột Phá: 9 Hồng Lôi tuần tự, mỗi đợt cách 5 giây, damage tăng 0.5 → 2.1 tim.
- Độ Kiếp Trúc Cơ: 19 Hồng Lôi tuần tự, mỗi đợt cách 5 giây, damage tăng 0.5 → 4.1 tim; Phù Đột Phá chặn 8 đợt đầu.
- Luyện Khí Tầng 10 + full Linh Khí: khóa `/dotpha`, bắt buộc `/dokiep`.
- `/bakhi` đổi thành hệ thống Aura.
- VFX tu luyện theo Phái, tất cả xoay 360°; Phật Tu dùng Phật Quang.
- `/kinang` mở GUI gán kỹ năng.
- `/phaptuong` kích hoạt Pháp Tướng / Thần Thông tối thượng khi Thần Thức đạt 100%.
- Giữ Tông Môn Core và hệ thống Tông Môn hiện có.
- Chu kỳ tu luyện cơ bản cố định 320 giây; rank giảm 10 giây/rank.

# TuTienCore 2.5.1 – Cảnh giới 1-100

Đã cập nhật hệ thống cảnh giới theo progression cấp 1-100:

- 1-10: Luyện Khí Kỳ
- 11-20: Trúc Cơ Kỳ
- 21-30: Kết Đan Kỳ / Kim Đan Kỳ
- 31-40: Nguyên Anh Kỳ
- 41-50: Hóa Thần Kỳ
- 51-60: Luyện Hư Kỳ
- 61-70: Hợp Thể Kỳ
- 71-80: Độ Kiếp Kỳ
- 81-90: Đại Thừa Kỳ
- 91: Chân Tiên Hạ Phẩm
- 92: Chân Tiên Trung Phẩm
- 93: Chân Tiên Thượng Phẩm
- 94: Kim Tiên Sơ Kỳ
- 95: Kim Tiên Hậu Kỳ
- 96: Thái Ất Ngọc Tiên
- 97: Đại La Kim Tiên
- 98: Chuẩn Thánh / Bán Thánh
- 99: Thánh Nhân
- 100: Thiên Đạo Chủ Tể

Cấp 91-100 là các cảnh giới đơn tầng; các cảnh giới 1-90 có 10 tầng. Placeholder mới: `%tutien_canhgioi_cap%`.

Bản source này không bao gồm JAR build sẵn. Maven package cần chạy bằng Java 21 + Maven ở máy build.


## 2.6.0
- 30 rank prefixes updated to the supplied RGB/Neon LuckPerms commands.
- LuckPerms is read-only: TuTienCore does not create/delete groups or change player groups/prefixes.
- Added /dontuat (aliases /don, /ngukiem2): Riptide-style flight following the full camera direction, including looking up/down, with water/cloud particle trail.
- /ngukiem remains as a backward-compatible alias for the same flight state.


## 2.6.1 – Linh Thạch vật phẩm
- Linh Thạch là vật phẩm GOLD_NUGGET tên Linh Thạch, tách khỏi Vault Economy.
- Quái chết mặc định rơi Linh Thạch 100%, số lượng 1–3; chỉnh được trong config.yml.
- AFK Linh Thạch và admin linhthach add/set dùng vật phẩm thật trong túi.


## 2.6.2 - Linh Thạch Space
- Linh Thạch là tiền riêng, độc lập với Vault Economy và PlayerPoints.
- `/catlinhthach` cất toàn bộ Linh Thạch item trong túi vào kho Không Gian Linh Thạch.
- Kho dùng BigInteger nên không bị giới hạn thực tế như `int`/`long`.
- `%tutien_linhthach%` = số dư trong Không Gian Linh Thạch; `%tutien_linhthach_tui%` = Linh Thạch vật phẩm đang nằm trong túi.
- Thêm config loot riêng cho quái thường, zombie, husk, drowned, skeleton, elite-boss và boss phó bản.

## 2.8.0 update
- `/donthuat` is the only Độn Thuật command; Shift or touching ground cancels flight with one visual explosion burst.
- Added seven movement/visual Độn Thuật skills with cooldowns.
- Successful breakthroughs permanently add +2 max health, movement speed and flying speed bonuses.
- Each successful breakthrough grants 1 Linh Căn roll; `/linhcan` opens the roll menu and shows configured rates.
- Added Tàng Kinh Các Core item for Tông Môn owners.


# TuTienCore 2.8.1 – AFK WorldEdit + WorldGuard

## Đặt khu AFK
1. Cài và bật **WorldEdit** + **WorldGuard**.
2. Dùng WorldEdit chọn 2 góc của khu vực bằng `//wand`.
3. Tạo khu AFK tiền:
   `/setafk <tên-khu>`
4. Tạo khu AFK Linh Thạch:
   `/setafklinhthach <tên-khu>`

TuTienCore tự tạo region WorldGuard với tên:
- `tutien_afk_money_<tên-khu>`
- `tutien_afk_linhthach_<tên-khu>`

Các region AFK được khóa bằng WorldGuard: **không đập block, không đặt block, không TNT, không nổ, không lan lửa**. Phần thưởng chỉ được tính khi người chơi thực sự đứng trong region.

## Phần thưởng AFK
- Chu kỳ mặc định: 120 giây.
- Tiền mặc định: 700 × hệ số rank.
- Linh Thạch mặc định: 2 × hệ số rank.
- Có thể chỉnh trong `config.yml` → `afk`.

## Việt hóa
Các lệnh, hướng dẫn AFK và thông báo chính của bản 2.8.1 đã được Việt hóa; ID region, tên command và khóa config kỹ thuật vẫn giữ nguyên để tránh phá tương thích.


## 2.8.2
- Thêm GUI Đột Phá: Cửu Lôi và Đột Phá Nhanh.
- `/dotpha` mở GUI; `/dotpha nhanh` dùng chế độ nhanh không particle.
- Đột phá nhanh gây đúng 10 tim sát thương; Absorption/tim vàng được trừ trước.
- Mỗi đột phá thành công tiếp tục +2 máu tối đa, tốc độ, tốc độ bay, sát thương vật lý và Sức Mạnh II vĩnh viễn.
- Thêm GUI Tông Môn với thông tin, dịch chuyển, đóng góp, rời Tông Môn và Tàng Kinh Các Core.
- `/tuluyen` và `/donthuat` vẫn là command-only, không thêm GUI.
- AFK tiếp tục dùng WorldEdit + WorldGuard để khóa vùng và trả thưởng qua Vault.


## 2.8.2 – Fix IntelliJ WorldEdit API

Đã khai báo trực tiếp cả `worldedit-bukkit` và `worldedit-core` cùng version 7.4.5.
Nếu IntelliJ vẫn báo đỏ các import `com.sk89q.worldedit.*`: mở Maven → Reload All Maven Projects; sau đó Build → Rebuild Project.
Không đổi package WorldEdit trong source.


## 2.8.3 HOTFIX
- Sửa import ClipboardHolder theo WorldEdit 7.4.5: `com.sk89q.worldedit.session.ClipboardHolder`.
- `/setafk <ten>` và `/setafklinhthach <ten>` dùng selection WorldEdit và tạo WorldGuard ProtectedCuboidRegion, khóa BUILD/BLOCK_BREAK/BLOCK_PLACE/TNT/nổ/lửa.
- Khu AFK nhận thưởng theo đúng prefix `tutien_afk_money_` hoặc `tutien_afk_linhthach_`.
- Đột phá nhanh không tạo particle; gây đúng 10 tim sát thương và xử lý Absorption trước.
- Sau đột phá: +2 máu tối đa mỗi lần, Strength II vĩnh viễn, tăng tốc chạy và tốc độ bay.
- GUI Đột Phá và GUI Tông Môn được giữ; Tu Luyện và Độn Thuật vẫn command-only.
- Tông Môn GUI có thông tin, thành viên, kho, đóng góp, dịch chuyển, Core và Tàng Kinh Các Core.

## 2.8.4 build note
WorldEdit 7.4.5 is compiled for Java 21 (class file 69). This source therefore compiles with Maven compiler release 21. Use JDK 25 in IntelliJ/Maven. Paper 1.21.11 + WorldGuard 7.0.17 remain provided dependencies.


## 2.8.4 Java 21 fix

Maven compiler target is fixed to Java 21 so IntelliJ/Maven running on JDK 21 does not show `release version 25 not supported`. Paper 1.21.11 server may run on newer Java, but this plugin source is intentionally compiled for Java 21.


## 2.9.0 - Lục Phái / 72 Kỹ Năng
- Kiếm Tu, Ma Tu, Quỷ Tu, Phật Tu, Độc Tu, Tán Tu.
- Mỗi phái có 12 kỹ năng riêng.
- Sách kỹ năng chuột phải để học hoặc +1 cấp.
- `/phai`, `/phai chon <phái>`, `/phai skills`, `/phai skill <1-12>`, `/phai weapon`.
- Admin: `/tta phaiskillbook <phái> <1-12> [player]`.
- Admin: `/tta phaiweapon <phái> [player]`.


## Quest Update
- `/nhiemvu` mở GUI Nhiệm Vụ Tu Tiên, nhận thưởng ngày/tuần trực tiếp.
- `/autoquest` tạo NPC **Trưởng Lão** cách người chơi 2 block, có sẵn quest; click NPC mở GUI quest.
- `/autoquest remove` xóa Trưởng Lão quest gần người chơi.
