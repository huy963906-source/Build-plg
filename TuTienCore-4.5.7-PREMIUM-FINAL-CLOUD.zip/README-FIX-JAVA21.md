# TuTienCore 2.8.4 - Fix Java 21 / WorldEdit

Fix build error `class file has wrong version 69.0, should be 65.0`.

Cause: WorldEdit 7.4.5 was compiled for Java 25 (class 69), while this project compiles with Java 21 (class 65).

Build API dependency is pinned to WorldEdit 7.3.17 so Maven/IntelliJ can compile with Java 21.

The server can still run its installed WorldEdit version separately; this change only fixes the compile-time dependency.
