# Build TuTienCore 4.5.7 on Android using GitHub Actions

1. Create a private GitHub repository.
2. Extract this ZIP. Upload the **contents of this project root** (including `.github`, `pom.xml`, `src`, and `scripts`) directly into the repository root. Do not upload an extra enclosing folder.
3. Open the repository's Actions tab and run **Build TuTienCore Premium** using **Run workflow**.
4. Wait for `mvn -B -ntp clean package` to finish successfully.
5. Open the successful workflow run and download the artifact named `TuTienCore-4.5.7-PREMIUM-JAR`.

A JAR is not included in this source ZIP. If the Maven step fails, download/copy the build log so the compile error can be fixed before using it on a live server.
