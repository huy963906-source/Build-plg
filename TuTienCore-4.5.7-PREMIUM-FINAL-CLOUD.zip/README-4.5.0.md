# TuTienCore 4.4.0 — Đại Bổ Tu Tiên

## Thay đổi trong bản source này
- Đồng bộ Maven artifact/version và plugin.yml lên 4.4.0.
- `/phai` mở GUI chọn phái gồm Kiếm Tu, Ma Tu, Quỷ Tu, Phật Tu, Độc Tu và Tán Tu.
- GUI hiển thị mô tả phái, phái hiện tại và số kỹ năng đã học; click chọn dùng lại ClassSkillSystem.chooseClass hiện có.
- `/phai info`, `/phai skills`, `/phai chon <id>`, `/phai skill <1-12>` và `/phai weapon` vẫn được giữ.
- Thêm script kiểm tra tĩnh source và báo cáo build.

## Build
Yêu cầu JDK 21 và Maven. Chạy `python scripts/validate_source.py` rồi `mvn clean package`.

## Trạng thái xác minh
ZIP integrity và kiểm tra cấu trúc source có thể thực hiện offline. Build Maven chỉ được xem là thành công khi lệnh Maven hoàn tất với exit code 0 trong môi trường có đủ dependency. Không có JAR build sẵn trong gói này.


## TuTienCore 4.5.0 — Vũ khí theo phái
- Khi người chơi chọn phái bằng GUI `/phai` hoặc lệnh `/phai chon`, plugin cấp vũ khí riêng của phái đó.
- Khi đổi phái, chỉ vũ khí do TuTienCore cấp (được đánh dấu PDC) bị thu hồi; vũ khí thường của người chơi không bị xóa.
- Vũ khí mới được cấp sau khi thu hồi, tránh nhân bản kể cả khi chọn lại cùng phái. Nếu túi đầy, vật phẩm được thả cạnh người chơi.
- Tán Tu dùng nỏ làm vật phẩm vũ khí đại diện.
