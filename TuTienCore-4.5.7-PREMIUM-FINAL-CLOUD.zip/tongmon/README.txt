TONG MON CORE

Dat file tongmon.schematic vao: plugins/TuTienCoreCultivationCore/tongmon/tongmon.schematic

Dat BEACON sau khi file ton tai -> beacon se tro thanh Core Tông Môn, paste schematic va luu toa do.
Neu thieu file schematic: Chua co file schematic, vui long lien he discord admin :qhuy963906

Lenh:
/tongmon thongtin
/tongmon truyentong
/tongmon tao <ten>
