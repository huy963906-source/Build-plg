# TuTienCore 4.5.7 PREMIUM — consolidated gameplay patch

- `/tongmon disband` / `giaitan` / `huy`: Tông Chủ giải tán tông môn; members lose sect association, known Core blocks and WorldGuard claim are cleaned where available.
- `/linhthu` and `/pet` open the pet GUI with no arguments. Existing summon/dismiss subcommands remain.
- `/kinang` now lets the player select one of four key slots, then click a learned skill to equip it: `M1`, `M2`, `SHIFT_M2`, `SHIFT_M1`.
- Class weapon: M1 and Shift+M1 use the main-hand swing animation; M2 and Shift+M2 use right click. Normal vanilla melee hit is retained, with added slash particles and sound.
- Class skill cooldown is 3000 ms. Existing class-specific particle rings, streaks, sound cues, damage patterns, and breakthrough health/speed modifiers remain.
- Ngu Kiem strafe math in `DefaultMovementController` uses separate right/left vectors; Paper input maps `isLeft()` to A and `isRight()` to D.

## Verification status
Static source validation is run locally. Maven build and live Paper 1.21.11 test still must pass in GitHub Actions/server before treating the JAR as release-ready. This patch does not claim a compiled JAR until the workflow succeeds.
