#!/usr/bin/env python3
from pathlib import Path
import sys, xml.etree.ElementTree as ET
root = Path(__file__).resolve().parents[1]
errors=[]
pom=root/'pom.xml'; plugin=root/'src/main/resources/plugin.yml'
try:
    tree=ET.parse(pom)
    ns={'m':'http://maven.apache.org/POM/4.0.0'}
    version=tree.findtext('m:version', namespaces=ns)
    artifact=tree.findtext('m:artifactId', namespaces=ns)
    if version != '4.5.7-PREMIUM': errors.append(f'pom version expected 4.5.7-PREMIUM, got {version}')
    if not artifact: errors.append('pom artifactId missing')
except Exception as e: errors.append(f'pom.xml invalid: {e}')
try:
    text=plugin.read_text(encoding='utf-8')
    if 'version: 4.5.7-PREMIUM' not in text: errors.append('plugin.yml version is not 4.5.7-PREMIUM')
    if 'main: com.tcgame.tutiencore.TuTienCore' not in text: errors.append('plugin main class missing')
except Exception as e: errors.append(f'plugin.yml unreadable: {e}')
java=list((root/'src/main/java').rglob('*.java'))
if not java: errors.append('no Java source files found')
for f in java:
    data=f.read_text(encoding='utf-8', errors='replace')
    if ';\\nimport ' in data: errors.append(f'escaped newline before import: {f.relative_to(root)}')
if errors:
    print('STATIC VALIDATION: FAIL')
    print('\n'.join('- '+e for e in errors)); sys.exit(1)
print('STATIC VALIDATION: PASS')
print(f'Java source files: {len(java)}')
print('POM/plugin version: 4.5.7-PREMIUM')
print('Note: this does not replace mvn clean package.')
