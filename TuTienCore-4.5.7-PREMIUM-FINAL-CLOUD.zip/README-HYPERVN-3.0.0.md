# TuTienCore 3.0.0 — HYPERVN TU TIÊN

Bản 3.0.0 tổng hợp hệ thống Tu Tiên/MMORPG hiện có trong source, giữ Java 21 + Paper 1.21.11.

## Điểm chính
- 6 phái: Kiếm Tu, Ma Tu, Quỷ Tu, Phật Tu, Độc Tu, Tán Tu.
- 72 kỹ năng (12/phái), Combo Chain và Thần Thức.
- Pháp Tướng / Thần Thông tối thượng qua `/phaptuong` (alias cũ vẫn giữ).
- Đột Phá + Độ Kiếp, có chế độ nhanh tối ưu particle.
- Ngự Kiếm phi hành tự do, WASD + Space, Shift xuống kiếm.
- Phi Không / Độn Thuật.
- Tông Môn, claim 300 block, Linh Mạch.
- Bí Cảnh, Nhiệm Vụ, Luyện Đan, Pháp Bảo, Công Pháp, Tâm Pháp.
- Linh Thú, Rank, PlayerPoints cosmetics.
- GUI `/tutien`, `/cuahang`, `/kinang`, `/linhcan`, `/congduc`, `/luanhoi`.
- Staff/Admin tools, chống dupe, anti-cheat và hệ thống HUD.
- Hook Vault, WorldEdit, WorldGuard; soft-depend PlaceholderAPI, LuckPerms, PlayerPoints, BetonQuest, GSit, Geyser.

## Nguyên tắc gameplay
- Không dùng “Tu Vi” làm một chỉ số tích lũy riêng: người chơi hấp thụ **Linh Khí**, còn Cảnh Giới + tầng là trạng thái.
- Cosmetics không tăng Damage/Armor/Cảnh Giới/PvP.
- Ngự Kiếm dành cho khám phá thế giới mở.
- `/phaptuong` là lệnh chính cho Pháp Tướng; `/thanthuc` và `/thongthan` là alias tương thích.

# HyperVN TuTienCore 3.0.0

## Blueprint implemented in this source
- Minecraft Survival remains open: mining, building, Tông Môn, Long Mạch and Ngự Kiếm.
- Six paths / 72 class skills are retained from the existing ClassSkillSystem.
- HyperVN 3.0 combo meter with 1.2s combo window and Thần Thức 0-100%.
- Thần Thông: Pháp Thiên Tượng Địa / Thân Phật / U Minh / Vạn Độc / Thiên Diễn visual states.
- Light 12% counter advantage between the six path pairs.
- Catch-up: Thiên Địa Đồng Tâm, 20 cultivation-level gap, +50% training, max 14 days, removed when caught up.
- Weekly Linh Mạch Triều Tịch event: local 40-block area, x2 Linh Khí training.
- `/shop` is the `/cuahang` GUI and now contains the HyperVN 3.0 cosmetic shop.
- All cosmetics are exactly 10 PlayerPoints. Rank is the only pricing exception.
- Phi Kiếm skins are also switched to 10 PlayerPoints.
- Cosmetics never modify damage, armor, realm, cultivation speed or PvP power directly.

## Commands
- `/phaptuong` — kích hoạt Pháp Tướng / Thần Thông tối thượng khi Thần Thức đạt 100%.
- `/hyper430` — show the 3.0 feature summary.
- `/shop` or `/cuahang` — open the unified shop.

## Build
- Java 21
- Paper 1.21.11
- Maven project

The environment used to assemble this archive does not contain Maven, so this ZIP was source-assembled and statically checked (YAML + Java brace scan + ZIP integrity). Build it with your IntelliJ/Maven setup before deployment.


## Quest Update
- `/nhiemvu` mở GUI Nhiệm Vụ Tu Tiên, nhận thưởng ngày/tuần trực tiếp.
- `/autoquest` tạo NPC **Trưởng Lão** cách người chơi 2 block, có sẵn quest; click NPC mở GUI quest.
- `/autoquest remove` xóa Trưởng Lão quest gần người chơi.
