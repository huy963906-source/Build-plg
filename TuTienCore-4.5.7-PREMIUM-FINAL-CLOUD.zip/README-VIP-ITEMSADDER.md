# TuTienCore 4.5.0 VIP — ItemsAdder edition

## Tích hợp đã thêm
- ItemsAdder là soft-dependency: server không cài ItemsAdder vẫn khởi động, vũ khí fallback về vanilla.
- Khi ItemsAdder hoạt động, `/phai` cấp vũ khí custom theo phái: `hypervn:kiem_tu`, `hypervn:ma_dao`, `hypervn:quy_liem`, `hypervn:truong_phat`, `hypervn:doc_nhan`, `hypervn:linh_no`.
- ID có thể đổi tại `itemsadder.weapons` trong `config.yml`.
- Vũ khí custom vẫn được gắn PDC của TuTienCore nên xử lý chọn phái/kỹ năng hiện có tiếp tục hoạt động.

## Cài đặt
1. Build plugin bằng JDK 21 và Maven: `mvn clean package`.
2. Cài ItemsAdder tương thích Paper/server của bạn.
3. Import gói `TuTienCore-4.5.0-ItemsAdder-Sigma67-Assets.zip` theo cấu trúc ItemsAdder, giữ namespace `hypervn`.
4. Chạy `/iareload` (nếu bản ItemsAdder của bạn hỗ trợ lệnh này), sau đó `/iazip` và cài resource pack trên client.
5. Cài JAR TuTienCore vào `plugins/`, restart server, kiểm tra `/phai` và nhận vũ khí.

## Lưu ý xác minh
Mã nguồn dùng reflection để tránh hard dependency vào API ItemsAdder. ZIP asset là gói riêng; cần import vào ItemsAdder và build/gửi resource pack để người chơi nhìn thấy model. Trong môi trường build hiện tại không có Maven executable và chưa thể xác nhận JAR đã compile thành công; không phát hành source ZIP này như JAR đã kiểm thử.


## VIP 4.5.2 hardening update
- Admin GUI receives a HYPERVN purple theme, clearer target profile and safer action labels.
- Anti-cheat movement sampling now waits for a meaningful time window, ignores recent teleports and strong server velocity, and removes the unreliable flat-air-movement FLY heuristic.
- Anti-cheat menu no longer kicks players based only on a click/VL threshold; staff can review and clear VL. Detection remains advisory, not proof of cheating.
- ItemsAdder remains optional and class weapons fall back to vanilla items when an ID is missing.

Build verification status: Java 21 is available in the packaging environment, but Maven and Paper API dependencies are not installed here. This source package has not been claimed as a successful compiled JAR or runtime-tested build. Test on a staging Paper 1.21.11 server before selling/deploying.
