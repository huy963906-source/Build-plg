# TuTienCore 3.0.0 - Build Fix

Fixed compile errors reported by IntelliJ/Maven on Paper API / Java 21:
- ClassSkillSystem: NamespacedKey initialized after plugin constructor assignment.
- ServerFeatureSystem: Player.playSound volume/pitch converted from double to float.
- StorageSystem: fixed InventoryView getView() usage.
- StaffFeatureSystem: fixed FilenameFilter String variable usage.
- TuTienAdminCommand: added ProtectedRegion import.
- TuTienCore: added getStaffFeatureSystem() and getCuaHangMenu().
- CoreListener: removed duplicate local Player variable.

Build in IntelliJ Maven: clean -> package.
