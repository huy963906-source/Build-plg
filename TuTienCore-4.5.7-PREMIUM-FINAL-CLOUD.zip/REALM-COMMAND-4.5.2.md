# Tạo/thay tên cảnh giới theo số rank

Lệnh quản trị (cần `tutien.admin`):

`/tta create realm <số-rank> <tên cảnh giới>`

Có hỗ trợ typo alias: `/tta create reaml <số-rank> <tên cảnh giới>`.

- Rank 1 = Luyện Khí, rank 2 = Trúc Cơ, ... rank 19 = Thiên Đạo Chủ Tể.
- Dùng số rank để chọn chính xác slot cần đặt tên. Chạy lại cùng số để thay tên hiển thị.
- Tên lưu ở `custom-realms.names` trong `config.yml`, được nạp khi khởi động và khi `/tta reload`.
- Không thay đổi ID enum, cấp độ, yêu cầu đột phá hay dữ liệu nhân vật; đây là tùy chỉnh tên hiển thị cho các rank hiện có, không phải thêm slot progression mới ngoài hệ thống hiện tại.
