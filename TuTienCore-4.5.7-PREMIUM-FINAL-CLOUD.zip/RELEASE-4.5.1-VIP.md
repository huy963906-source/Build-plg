# TuTienCore 4.5.2 VIP — ItemsAdder + GUI + AntiCheat hardening

## Changes in this source update
- Reworked Admin GUI visual hierarchy and HYPERVN purple theme, clearer target profile and safer action descriptions.
- AntiCheat movement sample now uses a minimum sample window, ignores a short period after teleport, ignores strong server velocity bursts, and removes the unreliable flat-air movement heuristic.
- AntiCheat menu is advisory only: clicking a flagged player no longer kicks them; it reports and clears VL. Staff should review logs and other plugins before taking action.
- ItemsAdder integration remains optional and falls back to vanilla weapons when the configured custom item is unavailable.
- Version metadata: 4.5.2, Java release 21, Paper API 1.21.11.

## Verification
- ZIP integrity: verified during packaging.
- Static source validation: PASS (104 Java source files; POM/plugin metadata match 4.5.2).
- Maven compilation: NOT RUN. Maven executable and Paper API dependencies are unavailable in the packaging environment.
- Paper server runtime testing: NOT RUN.

Do not advertise this as a compiled/runtime-tested JAR until `mvn clean package` succeeds and the plugin has been tested on a staging Paper 1.21.11 server with the target ItemsAdder pack. Keep a backup of the server and player data before upgrading.
