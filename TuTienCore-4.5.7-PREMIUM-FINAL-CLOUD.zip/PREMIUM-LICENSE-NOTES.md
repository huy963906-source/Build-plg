# TuTienCore 4.5.3-PRE — Premium licensing notes

This is a pre-release source package based on 4.5.2. It preserves the prior realm-name customization and updates the Maven/plugin version.

## Key policy supplied by zyas
- Contact: zyas / Discord `qhuy963906`.
- One activation per key; reset requests are handled by admin through Discord.
- Five commercial keys maximum; admin key `TTCPLG-ZYAS-DEPTRAI` is separate.

## Important implementation status
This PRE package does **not** yet enforce key activation in the plugin. A list of strings embedded in a plugin cannot reliably prevent reuse across different servers, and this package has no remote license service endpoint. To enforce single-use activation and admin reset reliably, implement a license API and keep the issued-key registry server-side. Do not ship `PREMIUM-KEYS-ADMIN-ONLY.txt` to customers.

## Build
Requires Java 21 and Maven; run `mvn clean package`. Expected artifact: `target/TuTienCore-4.5.3-PRE.jar`. This environment has no Maven, so no JAR build or Paper runtime test was completed.
