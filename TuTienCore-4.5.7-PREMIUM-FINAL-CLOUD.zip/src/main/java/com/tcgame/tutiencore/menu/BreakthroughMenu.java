package com.tcgame.tutiencore.menu;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/** GUI for breakthrough choices. Training and Don Thuat intentionally remain command-only. */
public final class BreakthroughMenu {
    public static final String TITLE = ChatColor.DARK_PURPLE + "Đột Phá • Cảnh Giới";
    private final TuTienCore plugin;
    public BreakthroughMenu(TuTienCore plugin) { this.plugin = plugin; }

    public void open(Player p) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        fill(inv, Material.BLACK_STAINED_GLASS_PANE, " ");
        inv.setItem(4, item(Material.NETHER_STAR, "§d§lĐỘT PHÁ CẢNH GIỚI", List.of(
                "§7Cảnh giới hiện tại: §f" + d.realmDisplay(),
                "§7Linh Khí: §b" + String.format("%.0f", d.linhKhi()) + "§7/§f" + d.nextLinhKhiStageThreshold(),
                "§7Căn Cốt: §f" + String.format("%.1f", d.canCot()) + " §7| Ngộ Tính: §f" + String.format("%.1f", d.ngoTinh()),
                "§7Đột phá thành công: §e" + d.breakthroughCount() + " lần")));
        inv.setItem(11, item(Material.LIGHTNING_ROD, "§5§lĐỘT PHÁ CỬU LÔI", List.of(
                "§7Đột phá theo hệ thống Thiên Kiếp hiện tại.",
                "§7Có hiệu ứng sét/particle.",
                "§eClick để bắt đầu")));
        inv.setItem(15, item(Material.FEATHER, "§b§lĐỘT PHÁ NHANH", List.of(
                "§7Bỏ qua toàn bộ particle Thiên Kiếp.",
                "§7Đột phá ngay nếu đủ điều kiện.",
                "§cKhi thành công: chịu §f10 tim §cdamage.",
                "§7Tim vàng/Absorption có thể hấp thụ sát thương.",
                "§eClick để đột phá nhanh")));
        inv.setItem(22, item(Material.BARRIER, "§cĐóng", List.of("§7Đóng giao diện")));
        p.openInventory(inv);
    }

    private static ItemStack item(Material m, String name, List<String> lore) {
        ItemStack i = new ItemStack(m);
        ItemMeta meta = i.getItemMeta();
        if (meta != null) { meta.setDisplayName(name); meta.setLore(lore); i.setItemMeta(meta); }
        return i;
    }
    private static void fill(Inventory inv, Material m, String name) {
        ItemStack i = item(m, name, List.of());
        for (int x = 0; x < inv.getSize(); x++) inv.setItem(x, i.clone());
    }
}
