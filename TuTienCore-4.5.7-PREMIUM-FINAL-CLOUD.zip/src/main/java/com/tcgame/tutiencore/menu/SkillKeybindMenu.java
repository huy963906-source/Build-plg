package com.tcgame.tutiencore.menu;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.skill.ClassSkillSystem;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** /kinang GUI: select a destination key, then click a learned skill to equip it. */
public final class SkillKeybindMenu implements Listener {
    public static final String TITLE = ChatColor.DARK_PURPLE + "Kỹ Năng • /kinang";
    private static final int[] KEY_SLOTS = {28, 30, 32, 34};
    private static final String[] KEY_NAMES = {"M1", "M2", "SHIFT_M2", "SHIFT_M1"};
    private final TuTienCore plugin;
    private final Map<UUID, Integer> selectedSlot = new ConcurrentHashMap<>();
    public SkillKeybindMenu(TuTienCore plugin){this.plugin=plugin;}

    public void open(Player p){
        PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId());
        List<ClassSkillSystem.Skill> list=plugin.getClassSkillSystem().skills(d.cultivationClass());
        Inventory inv=Bukkit.createInventory(null,54,TITLE);
        for(int i=0;i<Math.min(12,list.size());i++){
            var s=list.get(i); int lv=d.classSkillLevel(s.id());
            inv.setItem(i+10,item(lv>0?Material.ENCHANTED_BOOK:Material.BOOK,"§d"+(i+1)+". §f"+s.name(),List.of("§7Cấp: §e"+lv,lv>0?"§aClick để trang bị vào ô đang chọn":"§cChưa học kỹ năng này")));
        }
        inv.setItem(4,item(Material.NETHER_STAR,"§6§lBẢNG GÁN KỸ NĂNG",List.of("§7Phái: §f"+plugin.getClassSkillSystem().className(d.cultivationClass()),"§eBước 1: Chọn một ô phím bên dưới","§eBước 2: Click kỹ năng đã học để gán","§7Đòn đánh thường vẫn hoạt động cùng kỹ năng.")));
        for(int i=0;i<KEY_SLOTS.length;i++){
            String equipped=plugin.getClassSkillSystem().equippedSkill(p,i);
            var skill=equipped.isBlank()?null:plugin.getClassSkillSystem().skill(equipped);
            String name=skill==null?"§7Chưa gán": "§f"+skill.name();
            inv.setItem(KEY_SLOTS[i],item(i==selectedSlot.getOrDefault(p.getUniqueId(),0)?Material.LIME_DYE:Material.TRIPWIRE_HOOK,
                    "§b§l"+KEY_NAMES[i].replace('_','+') ,List.of("§7Kỹ năng: "+name,"§eClick để chọn ô này")));
        }
        inv.setItem(49,item(Material.BARRIER,"§cĐóng",List.of()));
        p.openInventory(inv);
    }

    @EventHandler public void click(InventoryClickEvent e){
        if(!TITLE.equals(e.getView().getTitle())) return;
        e.setCancelled(true);
        if(!(e.getWhoClicked() instanceof Player p)) return;
        int slot=e.getRawSlot();
        if(slot<0 || slot>=e.getView().getTopInventory().getSize()) return;
        if(slot==49){p.closeInventory();return;}
        for(int i=0;i<KEY_SLOTS.length;i++) if(slot==KEY_SLOTS[i]){
            selectedSlot.put(p.getUniqueId(),i); p.playSound(p.getLocation(),org.bukkit.Sound.UI_BUTTON_CLICK,.7f,1.4f); open(p); return;
        }
        if(slot<10 || slot>21) return;
        int idx=slot-10;
        PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId());
        var list=plugin.getClassSkillSystem().skills(d.cultivationClass());
        if(idx<0||idx>=list.size()) return;
        var skill=list.get(idx);
        if(d.classSkillLevel(skill.id())<=0){p.sendMessage("§cBạn chưa học kỹ năng này.");return;}
        int key=selectedSlot.getOrDefault(p.getUniqueId(),0);
        if(plugin.getClassSkillSystem().equipSkill(p,KEY_NAMES[key],skill.id())) open(p);
    }
    private static ItemStack item(Material m,String n,List<String> lore){ItemStack i=new ItemStack(m);ItemMeta meta=i.getItemMeta();if(meta!=null){meta.setDisplayName(n);meta.setLore(lore);i.setItemMeta(meta);}return i;}
}
