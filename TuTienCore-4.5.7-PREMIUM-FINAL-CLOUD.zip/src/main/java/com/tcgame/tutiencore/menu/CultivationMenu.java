package com.tcgame.tutiencore.menu;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public final class CultivationMenu implements Listener {
    public static final String TITLE = ChatColor.DARK_PURPLE + "Tu Tiên • Tổng Quan";
    private final TuTienCore plugin;
    public CultivationMenu(TuTienCore plugin) { this.plugin = plugin; }

    public void open(Player p) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        Inventory inv = Bukkit.createInventory(null, 54, TITLE);
        fill(inv, Material.BLACK_STAINED_GLASS_PANE, " ");
        inv.setItem(4, item(Material.NETHER_STAR, "§6§lLinh Khí", List.of(
                "§7Cảnh giới: §f" + d.realmDisplay(),
                "§7Cấp tu vi: §f" + d.cultivationLevel() + " / 100",
                "§7Linh Khí: §f" + String.format("%.0f", d.linhKhi()) + " / " + d.nextLinhKhiStageThreshold(),
                "§7Tiến độ: §f" + String.format("%.1f%%", (Math.min(d.linhKhi(), d.nextLinhKhiStageThreshold()) / (double) d.nextLinhKhiStageThreshold()) * 100),
                "§7Mốc Linh Khí tầng: §b" + d.nextLinhKhiStageThreshold())));
        inv.setItem(10, item(Material.AMETHYST_SHARD, "§bLinh Khí", List.of("§f" + String.format("%.1f", d.linhKhi()), "§7Linh Khí tầng tiếp theo: §f" + d.nextLinhKhiStageThreshold())));
        inv.setItem(11, item(Material.BLAZE_POWDER, "§dLinh Căn", List.of(d.spiritRootDisplay(), "§7Số linh căn: §f" + d.spiritRoots().size(), "§7Lượt roll: §e" + d.spiritRootRolls(), "§f/linhcan để mở menu roll")));
        inv.setItem(12, item(Material.ENCHANTED_BOOK, "§5Công Pháp", List.of("§7Cấp: §f" + d.techniqueLevel(), "§7Thiên phú: §f" + d.techniqueTalent())));
        inv.setItem(13, item(Material.BOOK, "§3Tâm Pháp", List.of("§7Cấp: §f" + d.tamPhapLevel(), "§7Passive tăng tốc tu luyện")));
        inv.setItem(14, item(Material.NETHERITE_INGOT, "§eCăn Cốt / Ngộ Tính", List.of("§7Căn Cốt: §f" + fmt(d.canCot()), "§7Ngộ Tính: §f" + fmt(d.ngoTinh()))));
        inv.setItem(15, item(Material.EMERALD, "§6Tông Môn", List.of("§7Trạng thái: §f" + (d.sectId().isBlank() ? "Chưa gia nhập" : "Đã gia nhập"), "§7Đóng góp: §f" + d.sectContribution())));
        inv.setItem(16, item(Material.DRAGON_BREATH, "§5Độ Kiếp", List.of("§7" + (plugin.getTribulationSystem().isInTribulation(p.getUniqueId()) ? "Đang độ kiếp" : "Sẵn sàng"), "§7Luyện Khí Tầng 10 + full Linh Khí → /dokiep Trúc Cơ")));
        inv.setItem(19, item(Material.CLOCK, "§bTu Luyện", List.of("§7/tuluyen • GSit", "§7Chu kỳ cơ bản: 320s", "§7Rank giảm thời gian")));
        inv.setItem(20, item(Material.ENDER_EYE, "§dBí Cảnh", List.of("§7Lượt vào + wave + thưởng")));
        inv.setItem(21, item(Material.BREWING_STAND, "§cLuyện Đan", List.of("§7Buff tu luyện / đột phá")));
        inv.setItem(22, item(Material.SMITHING_TABLE, "§6Pháp Bảo", List.of("§7Tinh luyện / phẩm chất")));
        inv.setItem(23, item(Material.WOLF_SPAWN_EGG, "§aLinh Thú", List.of("§7Level / tiến hóa / skill")));
        inv.setItem(24, item(Material.WRITABLE_BOOK, "§eNhiệm Vụ", List.of("§7Daily / weekly / tông môn")));
        inv.setItem(25, item(Material.GOLD_INGOT, "§6Rank", List.of("§7Hiện tại: §f" + plugin.getRankSystem().name(d.rankLevel()), "§7Mở hiện tại: §f" + plugin.getRankSystem().visibleMaxRank() + " rank", "§7/rank để mua rank kế tiếp bằng PlayerPoints")));
        inv.setItem(26, item(Material.ARMOR_STAND, "§d§lPháp Tướng", List.of("§7Thần Thức: §f" + (int)d.thanThuc() + "%", "§7Kích hoạt Thần Thông tối thượng", "§e/phaptuong", "§8Có thể dùng khi Thần Thức đạt 100%.")));
        inv.setItem(40, item(Material.NETHER_STAR, "§6Đột Phá", List.of("§7Đủ Linh Khí → thử đột phá")));
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!e.getView().getTitle().equals(TITLE)) return;
        e.setCancelled(true);
        if (e.getRawSlot() == 26) {
            p.closeInventory();
            plugin.getHyperVN430System().useUltimate(p);
        }
    }

    private static String fmt(double v) { return String.format("%.1f", v); }
    private static ItemStack item(Material m, String n, List<String> lore) { ItemStack i = new ItemStack(m); ItemMeta meta = i.getItemMeta(); if (meta != null) { meta.setDisplayName(n); meta.setLore(lore); i.setItemMeta(meta); } return i; }
    private static void fill(Inventory inv, Material m, String n) { ItemStack i = item(m, n, List.of()); for (int x = 0; x < inv.getSize(); x++) inv.setItem(x, i.clone()); }
}
