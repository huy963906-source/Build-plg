package com.tcgame.tutiencore.menu;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.quest.QuestSystem;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public final class QuestMenu implements Listener {
    public static final String TITLE = "§5§l✦ NHIỆM VỤ TU TIÊN ✦";
    private final TuTienCore plugin;

    public QuestMenu(TuTienCore plugin) { this.plugin = plugin; }

    public void open(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        QuestSystem q = plugin.getQuestSystem();
        var d = plugin.getCultivationService().getPlayerData(p.getUniqueId());

        inv.setItem(10, item(Material.CLOCK, "§e§lNhiệm Vụ Ngày", List.of(
                "§7Tu luyện: §f" + Math.min(600, d.dailyTrainingSeconds()) + "§7/§f600 giây",
                "§7Thưởng: §a+250 Linh Khí",
                d.dailyQuestClaim() == q.dayKeyPublic() ? "§a✓ Đã nhận hôm nay" :
                        d.dailyTrainingSeconds() >= 600 ? "§e▶ Nhấn để nhận thưởng" : "§8Chưa hoàn thành"
        )));
        inv.setItem(13, item(Material.BOOK, "§d§lNhiệm Vụ Tuần", List.of(
                "§7Tu luyện: §f" + Math.min(3600, d.weeklyTrainingSeconds()) + "§7/§f3600 giây",
                "§7Thưởng: §a+3000 Linh Khí",
                d.weeklyQuestClaim() == q.weekKeyPublic() ? "§a✓ Đã nhận tuần này" :
                        d.weeklyTrainingSeconds() >= 3600 ? "§e▶ Nhấn để nhận thưởng" : "§8Chưa hoàn thành"
        )));
        inv.setItem(16, item(Material.VILLAGER_SPAWN_EGG, "§6§lTrưởng Lão", List.of(
                "§7NPC nhiệm vụ tự động",
                "§7Dùng: §f/autoquest",
                "§8Tạo Trưởng Lão cách bạn 2 block."
        )));
        inv.setItem(22, item(Material.BARRIER, "§c§lĐóng", List.of("§7Đóng giao diện")));
        p.openInventory(inv);
    }

    private ItemStack item(Material m, String name, List<String> lore) {
        ItemStack i = new ItemStack(m);
        ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        i.setItemMeta(meta);
        return i;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!TITLE.equals(e.getView().getTitle())) return;
        e.setCancelled(true);
        int slot = e.getRawSlot();
        if (slot == 10) {
            plugin.getQuestSystem().claim(p, "daily");
            Bukkit.getScheduler().runTask(plugin, () -> open(p));
        } else if (slot == 13) {
            plugin.getQuestSystem().claim(p, "weekly");
            Bukkit.getScheduler().runTask(plugin, () -> open(p));
        } else if (slot == 16) {
            plugin.getAutoQuestSystem().spawnQuestElder(p);
            p.closeInventory();
        } else if (slot == 22) p.closeInventory();
    }
}
