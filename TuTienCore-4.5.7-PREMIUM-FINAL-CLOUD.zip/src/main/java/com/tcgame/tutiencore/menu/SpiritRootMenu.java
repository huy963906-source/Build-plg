package com.tcgame.tutiencore.menu;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.spiritroot.SpiritRootQuality;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Animated Bagua-style Spirit Root GUI.
 *
 * The animation is deliberately inventory-based so it works with a vanilla
 * client and does not require a resource pack. The scheduler is lightweight:
 * one task per player while this menu is open and it is cancelled immediately
 * when the menu closes.
 */
public final class SpiritRootMenu {
    public static final String TITLE = ChatColor.DARK_PURPLE + "✦ BÁT QUÁI LINH CĂN ✦";

    private final TuTienCore plugin;
    private final Map<UUID, BukkitTask> animations = new ConcurrentHashMap<>();
    private final Map<UUID, BukkitTask> rolls = new ConcurrentHashMap<>();

    // 16 positions around the center slot 22. Visually this forms an oval/circle.
    private static final int[] RING = {
            11, 12, 13, 14, 15, 16, 17,
            26, 35, 34, 33, 32, 31, 30, 29,
            20
    };

    // Eight elemental/trigram symbols.
    private static final Material[] BAGUA_MATERIALS = {
            Material.GOLD_INGOT,
            Material.OAK_SAPLING,
            Material.WATER_BUCKET,
            Material.BLAZE_POWDER,
            Material.BRICK,
            Material.AMETHYST_SHARD,
            Material.NETHER_STAR,
            Material.ECHO_SHARD
    };

    private static final String[] BAGUA_NAMES = {
            "☰ CÀN • KIM",
            "☷ KHÔN • MỘC",
            "☵ KHẢM • THỦY",
            "☲ LY • HỎA",
            "☴ TỐN • THỔ",
            "☳ CHẤN • LINH",
            "☶ CẤN • DỊ",
            "☱ ĐOÀI • NGUYÊN"
    };

    public SpiritRootMenu(TuTienCore plugin) {
        this.plugin = plugin;
    }

    public void open(Player p) {
        stopAnimation(p);
        stopRoll(p);

        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        Inventory inv = Bukkit.createInventory(null, 45, TITLE);
        drawStatic(inv, d);
        drawRing(inv, 0, false);
        p.openInventory(inv);

        final int[] rotation = {0};
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline() || !p.getOpenInventory().getTitle().equals(TITLE)) {
                stopAnimation(p);
                return;
            }
            // During a roll, the roll task controls the ring speed.
            if (!rolls.containsKey(p.getUniqueId())) {
                rotation[0] = (rotation[0] + 1) % RING.length;
                drawRing(p.getOpenInventory().getTopInventory(), rotation[0], false);
            }
        }, 2L, 3L);
        animations.put(p.getUniqueId(), task);
    }

    /** Starts the full accelerate -> spin -> slow -> result animation. */
    public void startRoll(Player p) {
        UUID uuid = p.getUniqueId();
        if (rolls.containsKey(uuid)) return;

        PlayerData d = plugin.getCultivationService().getPlayerData(uuid);
        if (!d.takeSpiritRootRoll()) {
            p.sendMessage("§cBạn không còn lượt roll Linh Căn. §7Đột phá thành công để nhận thêm 1 lượt.");
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.7f, 0.6f);
            return;
        }

        stopAnimation(p);
        final int[] rotation = {0};
        final int[] tick = {0};
        final int totalTicks = 72; // ~3.6 seconds at 1 tick per step
        final int[] interval = {1};
        final BukkitTask[] holder = new BukkitTask[1];

        p.playSound(p.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 0.8f, 1.15f);
        p.sendActionBar("§d✦ Bát Quái đang khai trận... §7Đừng chạm vào vòng xoay!");

        holder[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline() || !p.getOpenInventory().getTitle().equals(TITLE)) {
                if (holder[0] != null) holder[0].cancel();
                rolls.remove(uuid);
                d.addSpiritRootRolls(1); // menu closed: return the consumed roll
                startNormalAnimation(p);
                return;
            }

            tick[0]++;
            rotation[0] = (rotation[0] + 1) % RING.length;
            drawRing(p.getOpenInventory().getTopInventory(), rotation[0], true);

            // The ring becomes more energetic during the middle of the roll.
            float pitch = 0.75f + (float) Math.min(1.0, tick[0] / 50.0);
            p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.28f, pitch);
            spawnRollParticles(p, tick[0]);

            if (tick[0] >= totalTicks) {
                holder[0].cancel();
                rolls.remove(uuid);

                var q = plugin.getInitiationSystem().getReroller().reroll(d);
                plugin.getCultivationService().save(uuid);

                p.sendTitle("§d§l✦ LINH CĂN GIÁNG THẾ ✦", "§f" + q.displayName(), 8, 45, 12);
                p.sendActionBar("§d✦ Kết quả: §f" + d.spiritRootDisplay());
                p.sendMessage("§a✦ Bát Quái đã định mệnh: §f" + d.spiritRootDisplay());
                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.25f);
                spawnResultParticles(p);

                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (p.isOnline() && p.getOpenInventory().getTitle().equals(TITLE)) open(p);
                }, 12L);
            }
        }, 1L, 1L);

        rolls.put(uuid, holder[0]);
    }

    private void drawStatic(Inventory inv, PlayerData d) {
        fill(inv, Material.BLACK_STAINED_GLASS_PANE, " ");

        int[] frame = {0,1,2,3,4,5,6,7,8,9,17,18,26,27,35,36,37,38,39,40,41,42,43,44};
        for (int slot : frame) {
            inv.setItem(slot, item(Material.PURPLE_STAINED_GLASS_PANE, "§5✦", List.of()));
        }

        // Decorative four corners of the inner formation.
        inv.setItem(10, item(Material.PURPLE_STAINED_GLASS_PANE, "§d✦", List.of("§8Bát Quái Thiên Địa")));
        inv.setItem(16, item(Material.PURPLE_STAINED_GLASS_PANE, "§d✦", List.of("§8Bát Quái Thiên Địa")));
        inv.setItem(28, item(Material.PURPLE_STAINED_GLASS_PANE, "§d✦", List.of("§8Bát Quái Thiên Địa")));
        inv.setItem(34, item(Material.PURPLE_STAINED_GLASS_PANE, "§d✦", List.of("§8Bát Quái Thiên Địa")));

        // Center = roll button. IMPORTANT: listener uses slot 22.
        inv.setItem(22, item(Material.NETHER_STAR, "§d§l☯ ROLL LINH CĂN ☯", List.of(
                "§7Lượt roll còn lại: §e" + d.spiritRootRolls(),
                "",
                "§e✦ Bấm để khai mở Bát Quái",
                "§7Vòng trận sẽ tăng tốc rồi dừng",
                "§7ở kết quả Linh Căn của ngươi.",
                "",
                "§f✦ §dBẤM ĐỂ ROLL §f✦"
        )));

        inv.setItem(4, item(Material.AMETHYST_SHARD, "§d§lLINH CĂN HIỆN TẠI", List.of(
                "§f" + d.spiritRootDisplay(),
                "§7Số linh căn: §f" + d.spiritRoots().size(),
                "§7Lượt roll: §e" + d.spiritRootRolls()
        )));

        List<String> rates = new ArrayList<>();
        rates.add("§8━━━━━━━━━━━━━━━━");
        for (SpiritRootQuality q : SpiritRootQuality.values()) {
            rates.add("§f" + q.displayName() + " §7• §e" +
                    String.format(Locale.ROOT, "%.2f%%", plugin.getInitiationSystem().getReroller().weightPercent(q)));
        }
        inv.setItem(40, item(Material.BOOK, "§b§lTỈ LỆ LINH CĂN", rates));
        inv.setItem(44, item(Material.BARRIER, "§c§lĐÓNG", List.of("§7Bấm để đóng menu.")));
    }

    private void drawRing(Inventory inv, int rotation, boolean rolling) {
        for (int slot : RING) {
            inv.setItem(slot, item(Material.BLACK_STAINED_GLASS_PANE, "§0 ", List.of()));
        }

        // Eight symbols are separated by one slot each, creating a rotating wheel.
        for (int i = 0; i < BAGUA_MATERIALS.length; i++) {
            int ringIndex = Math.floorMod((i * 2) + rotation, RING.length);
            int slot = RING[ringIndex];
            Material material = BAGUA_MATERIALS[i];
            String name = (rolling ? "§d§l✦ " : "§5§l✦ ") + BAGUA_NAMES[i];
            List<String> lore = List.of(
                    "§8━━━━━━━━━━━━━━━━",
                    rolling ? "§d✦ Linh khí đang xoay chuyển..." : "§7Trận nhãn Bát Quái",
                    "§8━━━━━━━━━━━━━━━━"
            );
            inv.setItem(slot, item(material, name, lore));
        }

        for (int i = 0; i < RING.length; i++) {
            ItemStack current = inv.getItem(RING[i]);
            if (current == null || current.getType() == Material.BLACK_STAINED_GLASS_PANE) {
                boolean glow = Math.floorMod(i - rotation, RING.length) < 2;
                inv.setItem(RING[i], item(
                        glow ? Material.YELLOW_STAINED_GLASS_PANE : Material.PURPLE_STAINED_GLASS_PANE,
                        glow ? "§e✦" : "§5✦",
                        List.of()
                ));
            }
        }
    }

    private void spawnRollParticles(Player p, int tick) {
        if (tick % 2 != 0) return;
        Location l = p.getLocation().clone().add(0, 1.0, 0);
        p.spawnParticle(Particle.ENCHANT, l, 5, 0.7, 0.7, 0.7, 0.1);
        if (tick % 8 == 0) p.spawnParticle(Particle.END_ROD, l, 3, 0.4, 0.5, 0.4, 0.02);
    }

    private void spawnResultParticles(Player p) {
        Location l = p.getLocation().clone().add(0, 1.0, 0);
        p.spawnParticle(Particle.END_ROD, l, 30, 0.8, 1.0, 0.8, 0.05);
        p.spawnParticle(Particle.TOTEM_OF_UNDYING, l, 18, 0.6, 0.8, 0.6, 0.1);
    }

    private void startNormalAnimation(Player p) {
        if (!p.isOnline() || !p.getOpenInventory().getTitle().equals(TITLE)) return;
        final int[] rotation = {0};
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!p.isOnline() || !p.getOpenInventory().getTitle().equals(TITLE)) {
                stopAnimation(p);
                return;
            }
            rotation[0] = (rotation[0] + 1) % RING.length;
            drawRing(p.getOpenInventory().getTopInventory(), rotation[0], false);
        }, 2L, 3L);
        animations.put(p.getUniqueId(), task);
    }

    public void stopAnimation(Player p) {
        BukkitTask task = animations.remove(p.getUniqueId());
        if (task != null) task.cancel();
    }

    public void stopRoll(Player p) {
        BukkitTask task = rolls.remove(p.getUniqueId());
        if (task != null) task.cancel();
    }

    private static ItemStack item(Material m, String name, List<String> lore) {
        ItemStack i = new ItemStack(m);
        ItemMeta meta = i.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(lore);
            i.setItemMeta(meta);
        }
        return i;
    }

    private static void fill(Inventory inv, Material m, String name) {
        ItemStack i = item(m, name, List.of());
        for (int x = 0; x < inv.getSize(); x++) inv.setItem(x, i.clone());
    }
}
