package com.tcgame.tutiencore.menu;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** GUI for Karma/Con đức and Reincarnation. */
public final class KarmaMenu implements Listener {
    public static final String KARMA_TITLE = ChatColor.GOLD + "✦ NHÂN QUẢ • CÔNG ĐỨC ✦";
    public static final String REINCARNATION_TITLE = ChatColor.DARK_PURPLE + "✦ LUÂN HỒI • THẦN LỰC ✦";
    private final TuTienCore plugin;

    public KarmaMenu(TuTienCore plugin) { this.plugin = plugin; }

    public void openKarma(Player p) {
        PlayerData d = data(p);
        Inventory inv = Bukkit.createInventory(null, 45, KARMA_TITLE);
        fill(inv, Material.BLACK_STAINED_GLASS_PANE, " ");
        frame(inv);
        inv.setItem(4, item(Material.BOOK, "§6§l✦ BẢNG NHÂN QUẢ ✦", List.of(
                "§7Mỗi hành động đều ảnh hưởng đến Nhân Quả.",
                "§7Công Đức hỗ trợ độ kiếp/đột phá.",
                "§7Nghiệp Lực làm Thiên Kiếp nguy hiểm hơn.")));
        inv.setItem(20, item(Material.EMERALD, "§a§lCÔNG ĐỨC", List.of(
                "§7Điểm hiện tại: §a§l" + d.congDuc(),
                "§7Tác dụng: tăng tỷ lệ đột phá",
                "§7và bảo hộ khi thất bại Thiên Kiếp.")));
        inv.setItem(24, item(Material.REDSTONE, "§c§lNGHIỆP LỰC", List.of(
                "§7Điểm hiện tại: §c§l" + d.nghiepLuc(),
                "§7Nghiệp cao khiến Lôi Kiếp nguy hiểm hơn.",
                "§7Hãy cân bằng Nhân Quả.")));
        inv.setItem(31, item(Material.NETHER_STAR, "§d§lLUÂN HỒI", List.of(
                "§7Thần Lực: §d" + d.thanLucLuanHoi(),
                "§7Số lần: §f" + d.luanHoiCount(),
                "",
                "§eClick để mở Bảng Luân Hồi.")));
        inv.setItem(40, item(Material.BARRIER, "§c§lĐÓNG", List.of("§7Đóng giao diện.")));
        p.openInventory(inv);
    }

    public void openReincarnation(Player p) {
        PlayerData d = data(p);
        Inventory inv = Bukkit.createInventory(null, 45, REINCARNATION_TITLE);
        fill(inv, Material.BLACK_STAINED_GLASS_PANE, " ");
        frame(inv);
        boolean ready = d.realm().name().equals("THIEN_DAO_CHU_TE") && d.finalTribulationPassed();
        long preview = Math.max(1L, 100L + d.congDuc() / 100L - d.nghiepLuc() / 200L);
        double previewDamage = Math.min(25D, (d.thanLucLuanHoi() + preview) * 0.05D);
        double previewCd = Math.min(30D, (d.thanLucLuanHoi() + preview) * 0.03D);

        inv.setItem(4, item(Material.NETHER_STAR, "§d§l✦ BẢNG LUÂN HỒI ✦", List.of(
                "§7Luân hồi đưa cảnh giới về Luyện Khí Tầng 1.",
                "§7Giữ phái, linh căn và kỹ năng đã học.",
                "§7Đổi lại nhận Thần Lực Luân Hồi.")));
        inv.setItem(19, item(Material.AMETHYST_SHARD, "§dTHẦN LỰC HIỆN TẠI", List.of(
                "§f" + d.thanLucLuanHoi(), "§7Lần luân hồi: §f" + d.luanHoiCount())));
        inv.setItem(21, item(Material.EXPERIENCE_BOTTLE, "§eTHẦN LỰC NHẬN ĐƯỢC", List.of(
                "§7Dự kiến: §e+" + preview,
                "§8Công Đức: +" + d.congDuc() / 100L,
                "§8Nghiệp Lực: -" + d.nghiepLuc() / 200L)));
        inv.setItem(23, item(Material.DIAMOND_SWORD, "§cTHIÊN PHÚ ẨN", List.of(
                "§7Sau luân hồi:",
                "§c+" + String.format(Locale.ROOT, "%.2f", previewDamage) + "% sát thương",
                "§b-" + String.format(Locale.ROOT, "%.2f", previewCd) + "% hồi chiêu")));
        inv.setItem(29, item(Material.LIME_DYE, ready ? "§a§l☯ XÁC NHẬN LUÂN HỒI" : "§c§lCHƯA ĐỦ ĐIỀU KIỆN", ready
                ? List.of("§7Click để xác nhận.", "§cCảnh giới và Linh Khí sẽ được reset.")
                : List.of("§7Cần đạt §fThiên Đạo Chủ Tể", "§7và vượt qua đại kiếp cuối.")));
        inv.setItem(33, item(Material.BARRIER, "§c§lHỦY", List.of("§7Quay lại Bảng Nhân Quả.")));
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String title = e.getView().getTitle();
        if (!title.equals(KARMA_TITLE) && !title.equals(REINCARNATION_TITLE)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getRawSlot() >= e.getView().getTopInventory().getSize()) return;
        int slot = e.getRawSlot();
        if (title.equals(KARMA_TITLE)) {
            if (slot == 31) openReincarnation(p);
            else if (slot == 40) p.closeInventory();
            return;
        }
        if (slot == 29) {
            PlayerData d = data(p);
            if (d.realm().name().equals("THIEN_DAO_CHU_TE") && d.finalTribulationPassed()) {
                p.closeInventory();
                plugin.getWorldRpgV3System().reincarnate(p);
            } else {
                p.sendMessage("§cChưa đủ điều kiện để Luân Hồi.");
            }
        } else if (slot == 33) openKarma(p);
    }

    private PlayerData data(Player p) { return plugin.getCultivationService().getPlayerData(p.getUniqueId()); }
    private static ItemStack item(Material m, String name, List<String> lore) {
        ItemStack i = new ItemStack(m); ItemMeta meta = i.getItemMeta();
        if (meta != null) { meta.setDisplayName(name); meta.setLore(lore); i.setItemMeta(meta); }
        return i;
    }
    private static void fill(Inventory inv, Material m, String name) {
        ItemStack i = item(m, name, List.of()); for (int x=0;x<inv.getSize();x++) inv.setItem(x,i.clone());
    }
    private static void frame(Inventory inv) {
        int[] slots={0,1,2,3,5,6,7,8,9,17,27,35,36,37,38,39,41,42,43,44};
        for(int s:slots) inv.setItem(s,item(Material.PURPLE_STAINED_GLASS_PANE,"§5✦",List.of()));
    }
}
