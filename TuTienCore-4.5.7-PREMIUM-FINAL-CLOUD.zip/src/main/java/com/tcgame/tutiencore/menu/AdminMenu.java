package com.tcgame.tutiencore.menu;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.*;

public final class AdminMenu {
    public static final String TITLE = ChatColor.DARK_PURPLE + "✦ HYPERVN • QUẢN TRỊ VIP ✦";
    public static final String SELECT_TITLE = ChatColor.DARK_PURPLE + "✦ QUẢN LÝ NGƯỜI CHƠI ✦";
    public enum InputType { LINHKHI_SET, LINHTHACH_SET, CANCOT_SET, NGOTINH_SET }
    private final TuTienCore plugin;
    private final Map<UUID, InputType> waiting = new HashMap<>();
    private final Map<UUID, Player> targets = new HashMap<>();
    private final Map<UUID, Map<Integer, UUID>> selectorSlots = new HashMap<>();

    public AdminMenu(TuTienCore plugin) { this.plugin = plugin; }

    public void openSelector(Player admin) {
        Inventory inv = Bukkit.createInventory(null, 54, SELECT_TITLE);
        fill(inv, Material.PURPLE_STAINED_GLASS_PANE, " ");
        Map<Integer, UUID> slots = new HashMap<>();
        int slot = 0;
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (slot >= 45) break;
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            if (meta != null) {
                meta.setOwningPlayer(player);
                meta.setDisplayName("§e" + player.getName());
                meta.setLore(List.of("§8────────────────", "§7Mở bảng quản trị người chơi", "§eClick để xem và chỉnh sửa", "§8UUID: " + player.getUniqueId().toString().substring(0, 8)));
                head.setItemMeta(meta);
            }
            inv.setItem(slot, head);
            slots.put(slot, player.getUniqueId());
            slot++;
        }
        selectorSlots.put(admin.getUniqueId(), slots);
        admin.openInventory(inv);
    }

    public Player select(Player admin, int slot) {
        UUID uuid = selectorSlots.getOrDefault(admin.getUniqueId(), Map.of()).get(slot);
        if (uuid == null) return null;
        Player target = Bukkit.getPlayer(uuid);
        if (target != null) targets.put(admin.getUniqueId(), target);
        selectorSlots.remove(admin.getUniqueId());
        return target;
    }

    public void open(Player admin, Player target) {
        targets.put(admin.getUniqueId(), target);
        PlayerData d = plugin.getCultivationService().getPlayerData(target.getUniqueId());
        Inventory inv = Bukkit.createInventory(null, 54, TITLE);
        fill(inv, Material.BLACK_STAINED_GLASS_PANE, " ");
        inv.setItem(4, item(Material.NETHER_STAR, "§d§l✦ HỒ SƠ TU TIÊN ✦", List.of(
                "§8────────────────────",
                "§7Người chơi: §f" + target.getName(),
                "§7Cảnh giới: §f" + d.realmDisplay(),
                "§7Linh Khí: §b" + fmt(d.linhKhi()) + "/" + d.nextLinhKhiStageThreshold(),
                "§7Linh Thạch: §e" + plugin.getAlchemySystem().countLinhThach(target),
                "§7Rank: §f" + plugin.getRankSystem().name(d.rankLevel()),
                "§8────────────────────")));
        inv.setItem(7, item(Material.PLAYER_HEAD, "§e§l♙ Chọn người chơi khác", List.of("§7Mở danh sách người chơi online.", "§eClick để đổi mục tiêu")));
        inv.setItem(8, item(Material.BOOK, "§b§lHướng dẫn quản trị", List.of("§7Chọn mục bên dưới để thao tác.", "§7Thay đổi tài nguyên sẽ tự lưu.", "§cHãy kiểm tra đúng mục tiêu trước khi sửa.")));
        for (int slot : new int[]{9,17,18,19,27,28,29,34,35,36,37,38,39,41,42,43,44,45,46,47,48,49,50,51,52,53}) {
            inv.setItem(slot, item(Material.PURPLE_STAINED_GLASS_PANE, "§5✦", List.of()));
        }
        inv.setItem(10, item(Material.AMETHYST_SHARD, "§b§lLinh Khí +100", List.of("§7Cộng 100 Linh Khí cho mục tiêu", "§eClick để áp dụng")));
        inv.setItem(11, item(Material.AMETHYST_CLUSTER, "§b§lLinh Khí +1.000", List.of("§7Cộng 1.000 Linh Khí cho mục tiêu", "§eClick để áp dụng")));
        inv.setItem(12, item(Material.AMETHYST_BLOCK, "§b§lĐặt Linh Khí", List.of("§7Nhập số nguyên không âm trong chat")));
        inv.setItem(14, item(Material.ENCHANTED_BOOK, "§5Công Pháp +1 cấp", List.of("Click")));
        inv.setItem(15, item(Material.EXPERIENCE_BOTTLE, "§5Công Pháp +1.000 EXP", List.of("Click")));
        inv.setItem(16, item(Material.BOOK, "§3Tâm Pháp +1 cấp", List.of("Click")));
        inv.setItem(20, item(Material.GOLD_NUGGET, "§e§lLinh Thạch +1.000", List.of("§7Cấp 1.000 Linh Thạch vật phẩm", "§eClick để áp dụng")));
        inv.setItem(21, item(Material.GOLD_BLOCK, "§e§lĐặt Linh Thạch", List.of("§7Nhập số nguyên không âm trong chat")));
        inv.setItem(23, item(Material.EXPERIENCE_BOTTLE, "§aCăn Cốt +1", List.of("Click")));
        inv.setItem(24, item(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE, "§d§lĐột Phá", List.of("§7Thử đột phá cho mục tiêu", "§cCó thể kích hoạt sự kiện đột phá")));
        inv.setItem(25, item(Material.DRAGON_BREATH, "§5§lThiên Kiếp", List.of("§7Khởi chạy kiếp kế tiếp cho mục tiêu")));
        inv.setItem(26, item(Material.NETHER_STAR, "§d§lThiên Kiếp Cuối", List.of("§7Chỉ dùng khi đạt Độ Kiếp tầng cuối")));
        inv.setItem(30, item(Material.IRON_INGOT, "§fCăn Cốt +1", List.of("Click")));
        inv.setItem(31, item(Material.QUARTZ, "§fNgộ Tính +1", List.of("Click")));
        inv.setItem(32, item(Material.AMETHYST_SHARD, "§bLuyện Khí Tầng 1 FREE", List.of("Mở khóa reward cho BetonQuest")));
        inv.setItem(33, item(Material.NETHER_STAR, "§d§lTăng Cảnh Giới", List.of("§7Admin: tăng 1 Tầng", "§7Đủ Tầng → chuyển Đại Cảnh Giới", "§cKhông cần điều kiện tu luyện")));
        inv.setItem(40, item(Material.BARRIER, "§c§lĐóng bảng quản trị", List.of("§7Không thay đổi dữ liệu")));
        admin.openInventory(inv);
    }

    public void input(Player admin, InputType type) { waiting.put(admin.getUniqueId(), type); admin.closeInventory(); admin.sendMessage("§eNhập giá trị vào chat. Gõ §c\\cancel §eđể hủy."); }
    public InputType waiting(Player p) { return waiting.get(p.getUniqueId()); }
    public Player target(Player admin) { return targets.getOrDefault(admin.getUniqueId(), admin); }
    public void clear(Player p) { waiting.remove(p.getUniqueId()); }

    private static String fmt(double v) { return String.format("%,.0f", v); }
    private static ItemStack item(Material m, String n, List<String> lore) { ItemStack i = new ItemStack(m); ItemMeta meta = i.getItemMeta(); if (meta != null) { meta.setDisplayName(n); meta.setLore(lore); i.setItemMeta(meta); } return i; }
    private static void fill(Inventory inv, Material m, String n) { for (int x = 0; x < inv.getSize(); x++) inv.setItem(x, item(m, n, List.of())); }
}
