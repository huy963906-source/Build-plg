package com.tcgame.tutiencore.menu;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.Map;

/** GUI chọn phái cho TuTienCore 4.4.0. */
public final class ClassSelectMenu implements Listener {
    public static final String TITLE = "§5§l✦ ĐẠO LỘ TU TIÊN ✦";
    private static final Map<String, Material> ICONS = Map.of(
            "KIEM_TU", Material.NETHERITE_SWORD,
            "MA_TU", Material.NETHERITE_AXE,
            "QUY_TU", Material.WITHER_SKELETON_SKULL,
            "PHAT_TU", Material.GOLDEN_APPLE,
            "DOC_TU", Material.SPIDER_EYE,
            "TAN_TU", Material.ENDER_EYE);
    private static final Map<String, String> LORE = Map.of(
            "KIEM_TU", "§7Lấy kiếm nhập đạo, sát phạt chính diện.",
            "MA_TU", "§7Ma khí cuồn cuộn, đánh đổi để lấy sức mạnh.",
            "QUY_TU", "§7Điều khiển âm khí và sức mạnh u minh.",
            "PHAT_TU", "§7Phật quang hộ thể, công thủ cân bằng.",
            "DOC_TU", "§7Dùng độc thuật, bào mòn đối thủ.",
            "TAN_TU", "§7Tự do tu luyện, có thể học bí kỹ đặc biệt.");
    private final TuTienCore plugin;
    public ClassSelectMenu(TuTienCore plugin) { this.plugin = plugin; }

    public void open(Player p) {
        Inventory inv = Bukkit.createInventory(null, 45, TITLE);
        ItemStack filler = item(Material.PURPLE_STAINED_GLASS_PANE, "§0 ", List.of());
        for (int i=0;i<45;i++) inv.setItem(i, filler);
        PlayerData data = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        var cs = plugin.getClassSkillSystem();
        int[] slots = {10, 12, 14, 20, 22, 24};
        for (int i=0;i<cs.classIds().size();i++) {
            String id = cs.classIds().get(i);
            boolean selected = data.cultivationClass().equalsIgnoreCase(id);
            int learned = 0;
            for (var skill : cs.skills(id)) if (data.classSkillLevel(skill.id()) > 0) learned++;
            inv.setItem(slots[i], item(ICONS.getOrDefault(id, Material.BOOK),
                    (selected ? "§a§l✓ " : "§d§l✦ ") + cs.className(id),
                    List.of(LORE.getOrDefault(id, "§7Con đường tu luyện riêng."),
                            "§7Kỹ năng đã học: §f" + learned + "§7/12",
                            selected ? "§aPhái hiện tại của bạn" : "§eNhấn để chọn phái này",
                            "§8ID: " + id)));
        }
        inv.setItem(40, item(Material.BOOK, "§b§lKỸ NĂNG CỦA PHÁI", List.of(
                "§7Xem danh sách 12 kỹ năng của phái hiện tại.", "§eNhấn để xem trong chat: /phai skills")));
        inv.setItem(44, item(Material.BARRIER, "§cĐóng", List.of("§7Đóng giao diện này.")));
        p.openInventory(inv);
    }

    @EventHandler public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || e.getView().getTitle().equals(TITLE) == false) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot=e.getRawSlot();
        if(slot==44){p.closeInventory();return;}
        if(slot==40){p.closeInventory();p.performCommand("phai skills");return;}
        int[] slots={10,12,14,20,22,24};
        for(int i=0;i<slots.length;i++) if(slot==slots[i]) {
            var cs=plugin.getClassSkillSystem();
            String id=cs.classIds().get(i);
            PlayerData data=plugin.getCultivationService().getPlayerData(p.getUniqueId());
            if(data.cultivationClass().equalsIgnoreCase(id)) {p.sendMessage("§eBạn đã thuộc phái §f"+cs.className(id)+"§e rồi.");return;}
            if(cs.chooseClass(p,id)) {
                p.sendMessage("§d✦ §aĐã chọn phái: §f"+cs.className(id)+"§a. Đạo lộ mới đã mở ra!");
                p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1.25f);
                p.closeInventory();
            }
            return;
        }
    }

    private ItemStack item(Material material, String name, List<String> lore) {
        ItemStack stack=new ItemStack(material); ItemMeta meta=stack.getItemMeta();
        if(meta!=null){meta.setDisplayName(name);meta.setLore(lore);stack.setItemMeta(meta);} return stack;
    }
}
