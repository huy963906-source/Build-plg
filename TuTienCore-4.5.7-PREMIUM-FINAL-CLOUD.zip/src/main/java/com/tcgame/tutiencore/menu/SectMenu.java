package com.tcgame.tutiencore.menu;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.sect.Sect;
import com.tcgame.tutiencore.sect.SectRank;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class SectMenu {
    public static final String TITLE = ChatColor.GOLD + "Tông Môn • Quản Lý";
    private final TuTienCore plugin;
    public SectMenu(TuTienCore plugin) { this.plugin = plugin; }

    public void open(Player p) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        Inventory inv = Bukkit.createInventory(null, 54, TITLE);
        fill(inv, Material.GRAY_STAINED_GLASS_PANE, " ");
        if (d.sectId().isBlank()) {
            inv.setItem(22, item(Material.EMERALD_BLOCK, "§a§lTÔNG MÔN", List.of(
                    "§7Bạn chưa gia nhập Tông Môn.",
                    "§eDùng /tongmon tao <tên>",
                    "§eDùng /tongmon join <tên>")));
            inv.setItem(49, item(Material.BARRIER, "§cĐóng", List.of()));
            p.openInventory(inv);
            return;
        }
        Sect s = plugin.getSectSystem().get(d.sectId());
        if (s == null) {
            inv.setItem(22, item(Material.BARRIER, "§cDữ liệu Tông Môn lỗi", List.of("§7Liên hệ quản trị viên.")));
            p.openInventory(inv);
            return;
        }
        SectRank rank = s.members().getOrDefault(p.getUniqueId(), SectRank.NGOAI_MON);
        inv.setItem(4, item(Material.EMERALD_BLOCK, "§6§l" + s.name(), List.of(
                "§7Cấp bậc: §f" + rank.displayName(),
                "§7Thành viên: §f" + s.members().size(),
                "§7Kho Tông Môn: §e" + String.format("%.0f", s.storage()),
                "§7Đóng góp cá nhân: §e" + d.sectContribution())));
        inv.setItem(19, item(Material.ENDER_PEARL, "§a§lVề Tông Môn", List.of("§7Dịch chuyển về Core Tông Môn.")));
        inv.setItem(21, item(Material.BOOK, "§e§lThành Viên", memberLore(s)));
        inv.setItem(23, item(Material.GOLD_INGOT, "§6§lĐóng Góp 100", List.of("§7Trừ 100 tiền Vault và cộng vào kho.")));
        inv.setItem(24, item(Material.GOLD_BLOCK, "§6§lĐóng Góp 1.000", List.of("§7Trừ 1.000 tiền Vault và cộng vào kho.")));
        inv.setItem(25, item(Material.DIAMOND, "§b§lKho Tông Môn", List.of("§7Số dư hiện tại: §e" + String.format("%.0f", s.storage()), "§7Đóng góp cá nhân: §e" + d.sectContribution())));
        inv.setItem(30, item(Material.ENCHANTING_TABLE, "§5§lTàng Kinh Các Core", List.of(
                "§7Trạng thái: §f" + (s.hasLibraryCore() ? "Đã đặt" : "Chưa đặt"),
                rank == SectRank.TONG_CHU ? "§eClick để nhận Core" : "§cChỉ Tông Chủ được nhận Core")));
        inv.setItem(31, item(Material.BEACON, "§d§lTâm Tông Môn", List.of(
                "§7Trạng thái: §f" + (s.hasCore() ? "Đã đặt" : "Chưa đặt"),
                "§7Core dùng làm điểm về Tông Môn.", "§eClick để dịch chuyển về Core")));
        inv.setItem(32, item(Material.RED_DYE, "§c§lRời Tông Môn", List.of("§7Tông Chủ không thể tự rời.", "§eClick để rời nếu đủ điều kiện.")));
        inv.setItem(40, item(Material.PAPER, "§b§lHướng Dẫn Tông Môn", List.of(
                "§f/tongmon tao <tên>", "§f/tongmon join <tên>", "§f/tongmon donggop <số>", "§f/tongmon truyentong", "§f/tongmon tangkinhcac")));
        inv.setItem(49, item(Material.BARRIER, "§cĐóng", List.of()));
        p.openInventory(inv);
    }

    private List<String> memberLore(Sect s) {
        List<String> lore = new ArrayList<>();
        lore.add("§7Danh sách thành viên:");
        int shown = 0;
        for (var e : s.members().entrySet()) {
            if (shown++ >= 12) { lore.add("§8... còn thành viên khác"); break; }
            Player p = Bukkit.getPlayer(e.getKey());
            String name = p == null ? e.getKey().toString().substring(0, 8) : p.getName();
            lore.add("§f• " + name + " §7- §e" + e.getValue().displayName());
        }
        return lore;
    }

    private static ItemStack item(Material m, String name, List<String> lore) {
        ItemStack i = new ItemStack(m); ItemMeta meta = i.getItemMeta();
        if (meta != null) { meta.setDisplayName(name); meta.setLore(lore); i.setItemMeta(meta); }
        return i;
    }
    private static void fill(Inventory inv, Material m, String name) { ItemStack i=item(m,name,List.of()); for(int x=0;x<inv.getSize();x++) inv.setItem(x,i.clone()); }
}
