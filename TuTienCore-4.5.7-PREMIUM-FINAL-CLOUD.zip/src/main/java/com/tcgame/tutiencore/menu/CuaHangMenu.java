package com.tcgame.tutiencore.menu;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.pet.PetSystem;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** One shop hub for Linh Thú and Rank. */
public final class CuaHangMenu implements Listener {
    public static final String TITLE = "§d§l✦ CỬA HÀNG TU TIÊN ✦";
    private static final String PET_TITLE = "§a§l✦ LINH THÚ ✦";
    private static final String PET_SHOP_TITLE = "§6§l✦ SHOP LINH THÚ ✦";
    private static final String RANK_TITLE = "§6§l✦ SHOP RANK ✦";
    private static final String FLIGHT_TITLE = "§b§l✦ SHOP PHI KIẾM ✦";
    private static final String COSMETIC_TITLE = "§d§l✦ HYPERVN 3.0 COSMETIC ✦";
    private final TuTienCore plugin;

    public CuaHangMenu(TuTienCore plugin) { this.plugin = plugin; }

    public void open(Player p) {
        PlayerData d = data(p);
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        fill(inv, Material.GRAY_STAINED_GLASS_PANE, " ");
        inv.setItem(11, item(Material.WOLF_SPAWN_EGG, "§a§lLinh Thú", List.of(
                "§7Đang chọn: §f" + (d.activePetId().isBlank() ? "Không có" : plugin.getPetSystem().petName(d.activePetId())),
                "§7Sở hữu: §f" + d.ownedPets().size(),
                "§eClick để quản lý / cưỡi")));
        inv.setItem(13, item(Material.EMERALD, "§6§lShop Linh Thú", List.of(
                "§7Mua Linh Thú bằng §eLinh Thạch", "§eClick để mở shop")));
        inv.setItem(15, item(Material.GOLD_INGOT, "§e§lShop Rank", List.of(
                "§7Rank hiện tại: §f" + plugin.getRankSystem().name(d.rankLevel()),
                "§7Thanh toán bằng §dPlayerPoints", "§eClick để mở shop")));
        inv.setItem(16, item(Material.DIAMOND_SWORD, "§b§lSkin Phi Kiếm", List.of(
                "§7Skin hiện tại: §f" + d.flightSkin(), "§7Chỉ thay đổi ngoại hình", "§eClick để mở shop")));
        inv.setItem(18, item(Material.NETHER_STAR, "§d§lSkin / VFX HyperVN 3.0", List.of(
                "§7Pháp Tướng • Phi Kiếm • Aura • Thiên Kiếp", "§dTất cả: 10 PlayerPoints / skin", "§eClick để mở")));
        inv.setItem(22, item(Material.NETHER_STAR, "§b§lTài Sản", List.of(
                "§7Linh Thạch: §e" + plugin.getLinhThachBankService().balance(p.getUniqueId()),
                "§7PlayerPoints: §d" + plugin.getRankSystem().playerPoints().balance(p))));
        inv.setItem(26, item(Material.BARRIER, "§cĐóng", List.of("§7Đóng cửa hàng")));
        p.openInventory(inv);
    }

    public void openPet(Player p) {
        PlayerData d = data(p);
        Inventory inv = Bukkit.createInventory(null, 27, PET_TITLE);
        fill(inv, Material.GREEN_STAINED_GLASS_PANE, " ");
        inv.setItem(4, item(Material.WOLF_SPAWN_EGG, "§a§lLinh Thú đang dùng", List.of(
                "§7" + (d.activePetId().isBlank() ? "Chưa cưỡi" : plugin.getPetSystem().petName(d.activePetId())),
                "§7Level: §f" + d.petLevel(),
                "§eClick Linh Thú bên dưới để cưỡi / thu hồi")));
        List<String> owned = new ArrayList<>(d.ownedPets());
        int slot = 10;
        for (String id : owned) {
            if (slot >= 17) break;
            inv.setItem(slot++, plugin.getPetSystem().shopItem(id, d));
        }
        inv.setItem(20, item(Material.EMERALD, "§6Shop Linh Thú", List.of("§eMua Linh Thú mới")));
        inv.setItem(22, item(Material.ARROW, "§bQuay lại", List.of("§7Về Cửa Hàng")));
        inv.setItem(24, item(Material.BARRIER, "§cĐóng", List.of("§7Đóng")));
        p.openInventory(inv);
    }

    public void openPetShop(Player p) {
        PlayerData d = data(p);
        Inventory inv = Bukkit.createInventory(null, 54, PET_SHOP_TITLE);
        fill(inv, Material.BROWN_STAINED_GLASS_PANE, " ");
        int slot = 10;
        for (String id : plugin.getPetSystem().petIds()) {
            if (slot >= 44) break;
            if (slot % 9 == 8) slot++;
            inv.setItem(slot++, plugin.getPetSystem().shopItem(id, d));
        }
        inv.setItem(49, item(Material.ARROW, "§bQuay lại", List.of("§7Về Cửa Hàng")));
        inv.setItem(53, item(Material.BARRIER, "§cĐóng", List.of("§7Đóng")));
        p.openInventory(inv);
    }

    public void openFlightShop(Player p) {
        PlayerData d = data(p);
        Inventory inv = Bukkit.createInventory(null, 27, FLIGHT_TITLE);
        fill(inv, Material.LIGHT_BLUE_STAINED_GLASS_PANE, " ");
        int slot = 10;
        for (String id : plugin.getConfig().getConfigurationSection("flight.sword-skins").getKeys(false)) {
            if (slot >= 17) break;
            String matName = plugin.getConfig().getString("flight.sword-skins." + id + ".material", "WOODEN_SWORD");
            Material mat = Material.matchMaterial(matName); if (mat == null) mat = Material.WOODEN_SWORD;
            int price = 10;
            boolean owned = d.ownsFlightSkin(id);
            List<String> lore = new ArrayList<>();
            lore.add(owned ? "§aĐã sở hữu" : "§7Giá: §d10 PlayerPoints");
            lore.add("§7Chỉ thay đổi ngoại hình — §aNON-P2W");
            lore.add(d.flightSkin().equalsIgnoreCase(id) ? "§bĐang dùng" : "§eClick để mua/chọn");
            inv.setItem(slot++, item(mat, "§b§lPhi Kiếm " + id, lore));
        }
        inv.setItem(22, item(Material.ARROW, "§bQuay lại", List.of("§7Về Cửa Hàng")));
        inv.setItem(26, item(Material.BARRIER, "§cĐóng", List.of("§7Đóng")));
        p.openInventory(inv);
    }

    public void openCosmeticShop(Player p) {
        PlayerData d = data(p);
        Inventory inv = Bukkit.createInventory(null, 54, COSMETIC_TITLE);
        fill(inv, Material.PURPLE_STAINED_GLASS_PANE, " ");
        int slot = 10;
        for (String id : com.tcgame.tutiencore.feature.HyperVN430System.cosmeticIds()) {
            if (slot >= 44) break;
            if (slot % 9 == 8) slot++;
            boolean owned = d.ownsCosmetic(id);
            Material mat = id.startsWith("PHAP_TUONG") ? Material.GOLD_BLOCK : id.startsWith("PHI_KIEM") ? Material.DIAMOND_SWORD : id.startsWith("AURA") ? Material.NETHER_STAR : Material.LIGHTNING_ROD;
            inv.setItem(slot++, item(mat, "§d§l" + id, List.of(owned ? "§aĐã sở hữu" : "§7Giá: §d10 PlayerPoints", d.activeCosmetic().equalsIgnoreCase(id) ? "§bĐang dùng" : "§eClick để mua/chọn", "§8P2S • Không tăng sức mạnh")));
        }
        inv.setItem(49, item(Material.ARROW, "§bQuay lại", List.of("§7Về Cửa Hàng")));
        inv.setItem(53, item(Material.BARRIER, "§cĐóng", List.of("§7Đóng")));
        p.openInventory(inv);
    }

    public void openRank(Player p) {
        PlayerData d = data(p);
        Inventory inv = Bukkit.createInventory(null, 54, RANK_TITLE);
        fill(inv, Material.BLACK_STAINED_GLASS_PANE, " ");
        int current = d.rankLevel();
        int max = plugin.getRankSystem().visibleMaxRank();
        inv.setItem(4, item(Material.NETHER_STAR, "§e§lRank hiện tại", List.of(
                "§f" + plugin.getRankSystem().name(current),
                "§7Cấp: §f" + current + " / " + max,
                "§7PlayerPoints: §d" + plugin.getRankSystem().playerPoints().balance(p))));
        int slot = 10;
        for (int level = 1; level <= max && slot < 44; level++) {
            if (slot % 9 == 8) slot++;
            Material mat = level <= current ? Material.LIME_DYE : (level == current + 1 ? Material.GOLD_INGOT : Material.GRAY_DYE);
            String status = level < current ? "§aĐã mở" : level == current ? "§aĐang dùng" : level == current + 1 ? "§eClick để mua" : "§8Chưa đến lượt";
            List<String> lore = new ArrayList<>();
            lore.add("§7Cấp: §f" + level);
            lore.add("§7Tên: §f" + plugin.getRankSystem().name(level));
            if (level > current) lore.add("§7Giá: §d" + plugin.getRankSystem().costForNext(level - 1) + " PlayerPoints");
            lore.add(status);
            inv.setItem(slot++, item(mat, "§6§lRank " + level, lore));
        }
        inv.setItem(49, item(Material.ARROW, "§bQuay lại", List.of("§7Về Cửa Hàng")));
        inv.setItem(53, item(Material.BARRIER, "§cĐóng", List.of("§7Đóng")));
        p.openInventory(inv);
    }

    @EventHandler
    public void click(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String title = e.getView().getTitle();
        if (!title.equals(TITLE) && !title.equals(PET_TITLE) && !title.equals(PET_SHOP_TITLE) && !title.equals(RANK_TITLE) && !title.equals(FLIGHT_TITLE) && !title.equals(COSMETIC_TITLE)) return;
        e.setCancelled(true);
        if (e.getRawSlot() >= e.getView().getTopInventory().getSize()) return;

        if (title.equals(TITLE)) {
            switch (e.getRawSlot()) {
                case 11 -> openPet(p);
                case 13 -> openPetShop(p);
                case 15 -> openRank(p);
                case 16 -> openFlightShop(p);
                case 18 -> openCosmeticShop(p);
                case 26 -> p.closeInventory();
                default -> { }
            }
            return;
        }
        if (title.equals(PET_TITLE)) {
            if (e.getRawSlot() == 20) openPetShop(p);
            else if (e.getRawSlot() == 22) open(p);
            else if (e.getRawSlot() == 24) p.closeInventory();
            else if (e.getRawSlot() >= 10 && e.getRawSlot() <= 16) {
                PlayerData d = data(p);
                List<String> owned = new ArrayList<>(d.ownedPets());
                int idx = e.getRawSlot() - 10;
                if (idx >= 0 && idx < owned.size()) {
                    plugin.getPetSystem().toggleRide(p, owned.get(idx));
                    openPet(p);
                }
            }
            return;
        }
        if (title.equals(PET_SHOP_TITLE)) {
            if (e.getRawSlot() == 49) { open(p); return; }
            if (e.getRawSlot() == 53) { p.closeInventory(); return; }
            String id = petIdAtSlot(e.getRawSlot());
            if (id != null) { plugin.getPetSystem().buy(p, id); openPetShop(p); }
            return;
        }
        if (title.equals(FLIGHT_TITLE)) {
            if (e.getRawSlot() == 22) { open(p); return; }
            if (e.getRawSlot() == 26) { p.closeInventory(); return; }
            int slot = 10;
            for (String id : plugin.getConfig().getConfigurationSection("flight.sword-skins").getKeys(false)) {
                if (slot >= 17) break;
                if (slot == e.getRawSlot()) {
                    PlayerData d = data(p);
                    int price = 10;
                    if (!d.ownsFlightSkin(id)) {
                        if (!plugin.getRankSystem().playerPoints().take(p, price)) { p.sendMessage("§cCần §d10 PlayerPoints§c."); openFlightShop(p); return; }
                        d.addOwnedFlightSkin(id);
                    }
                    d.flightSkin(id); plugin.getCultivationService().save(p.getUniqueId());
                    p.sendMessage("§a✦ Đã chọn Skin Phi Kiếm: §f" + id);
                    openFlightShop(p); return;
                }
                slot++;
            }
            return;
        }
        if (title.equals(COSMETIC_TITLE)) {
            if (e.getRawSlot() == 49) { open(p); return; }
            if (e.getRawSlot() == 53) { p.closeInventory(); return; }
            int slot = 10;
            for (String id : com.tcgame.tutiencore.feature.HyperVN430System.cosmeticIds()) {
                if (slot >= 44) break;
                if (slot % 9 == 8) slot++;
                if (slot == e.getRawSlot()) { plugin.getHyperVN430System().buyCosmetic(p, id); openCosmeticShop(p); return; }
                slot++;
            }
            return;
        }
        if (title.equals(RANK_TITLE)) {
            if (e.getRawSlot() == 49) { open(p); return; }
            if (e.getRawSlot() == 53) { p.closeInventory(); return; }
            int level = rankAtSlot(e.getRawSlot());
            PlayerData d = data(p);
            if (level == d.rankLevel() + 1) plugin.getRankSystem().purchase(p);
            else if (level > 0) p.sendMessage("§7Bạn phải mua rank theo thứ tự. Rank kế tiếp là §f" + plugin.getRankSystem().name(d.rankLevel() + 1));
            openRank(p);
        }
    }

    private String petIdAtSlot(int target) {
        int slot = 10;
        for (String id : plugin.getPetSystem().petIds()) {
            if (slot >= 44) break;
            if (slot % 9 == 8) slot++;
            if (slot == target) return id;
            slot++;
        }
        return null;
    }

    private int rankAtSlot(int target) {
        int slot = 10;
        for (int level = 1; level <= plugin.getRankSystem().visibleMaxRank() && slot < 44; level++) {
            if (slot % 9 == 8) slot++;
            if (slot == target) return level;
            slot++;
        }
        return -1;
    }

    @EventHandler public void drag(InventoryDragEvent e) {
        String title = e.getView().getTitle();
        if (title.equals(TITLE) || title.equals(PET_TITLE) || title.equals(PET_SHOP_TITLE) || title.equals(RANK_TITLE) || title.equals(FLIGHT_TITLE) || title.equals(COSMETIC_TITLE)) e.setCancelled(true);
    }

    private PlayerData data(Player p) { return plugin.getCultivationService().getPlayerData(p.getUniqueId()); }
    private static ItemStack item(Material m, String name, List<String> lore) {
        ItemStack i = new ItemStack(m); ItemMeta meta = i.getItemMeta();
        if (meta != null) { meta.setDisplayName(name); meta.setLore(lore); i.setItemMeta(meta); }
        return i;
    }
    private static void fill(Inventory inv, Material m, String name) { ItemStack i = item(m, name, List.of()); for (int x = 0; x < inv.getSize(); x++) inv.setItem(x, i.clone()); }
}
