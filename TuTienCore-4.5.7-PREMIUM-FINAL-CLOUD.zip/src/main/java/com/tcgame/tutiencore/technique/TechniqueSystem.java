package com.tcgame.tutiencore.technique;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.ChatColor;

import java.util.*;

/** Config-free starter technique system with real named techniques and passive effects. */
public final class TechniqueSystem {
    public record Technique(String id, String name, String element, double multiplier, double combatBonus, double tribulationReduction, int cost) {}

    private final Map<String, Technique> techniques = new LinkedHashMap<>();

    public TechniqueSystem(TuTienCore plugin) {
        add(new Technique("luyen_khi_quyet", "Luyện Khí Quyết", "Vo", 1.10, 0.00, 0.00, 0));
        add(new Technique("thanh_moc_tam_kinh", "Thanh Mộc Tâm Kinh", "Mộc", 1.18, 0.04, 0.00, 250));
        add(new Technique("hoa_van_chan_kinh", "Hỏa Vân Chân Kinh", "Hỏa", 1.14, 0.10, 0.00, 350));
        add(new Technique("cuu_thien_loi_quyet", "Cửu Thiên Lôi Quyết", "Lôi", 1.16, 0.08, 0.08, 500));
        add(new Technique("huyen_bang_tam_kinh", "Huyền Băng Tâm Kinh", "Thủy", 1.15, 0.02, 0.12, 450));
        add(new Technique("thai_hu_kinh", "Thái Hư Kinh", "Hỗn Độn", 1.28, 0.06, 0.10, 1000));
    }

    private void add(Technique t) { techniques.put(t.id(), t); }
    public Collection<Technique> all() { return Collections.unmodifiableCollection(techniques.values()); }
    public Technique get(String id) { return id == null ? null : techniques.get(id.toLowerCase(Locale.ROOT)); }

    public double cultivationMultiplier(PlayerData d) {
        Technique t = get(d.techniqueId());
        if (t == null) return 1D + (d.techniqueLevel() * 0.05D) + (d.techniqueTalent() * 0.01D);
        return t.multiplier() + (d.techniqueLevel() * 0.015D) + (d.techniqueTalent() * 0.01D);
    }

    public double combatBonus(PlayerData d) {
        Technique t = get(d.techniqueId());
        return t == null ? 0D : Math.min(0.50D, t.combatBonus() + d.techniqueLevel() * 0.005D);
    }

    public double tribulationReduction(PlayerData d) {
        Technique t = get(d.techniqueId());
        return t == null ? 0D : Math.min(0.35D, t.tribulationReduction() + d.techniqueLevel() * 0.006D);
    }

    public boolean learn(PlayerData d, String id) {
        Technique t = get(id);
        if (t == null || d.techniqueLevel() > 0 && Objects.equals(d.techniqueId(), t.id())) return false;
        d.techniqueId(t.id());
        if (d.techniqueLevel() <= 0) d.techniqueLevel(1);
        return true;
    }

    public void addExp(PlayerData d, long amount) {
        d.addTechniqueExp(amount);
        long needed = expToNext(d);
        while (d.techniqueExp() >= needed) {
            d.techniqueExp(d.techniqueExp() - needed);
            d.techniqueLevel(d.techniqueLevel() + 1);
            needed = expToNext(d);
        }
    }

    public long expToNext(PlayerData d) { return Math.max(100L, (long) (100L * Math.pow(1.35D, d.techniqueLevel()))); }

    public String pretty(PlayerData d) {
        Technique t = get(d.techniqueId());
        if (t == null) return ChatColor.GRAY + "Chưa học công pháp";
        return ChatColor.LIGHT_PURPLE + t.name() + ChatColor.GRAY + " | Cap " + ChatColor.WHITE + d.techniqueLevel()
                + ChatColor.GRAY + " | EXP " + ChatColor.WHITE + d.techniqueExp() + "/" + expToNext(d);
    }
}
