package com.tcgame.tutiencore.artifact;

import com.tcgame.tutiencore.api.PlayerData;

public final class ArtifactSystem {
    public double cultivationMultiplier(PlayerData d) {
        double quality = switch (d.artifactQuality().toUpperCase()) {
            case "THUONG" -> 0.05D; case "CUC" -> 0.10D; case "THIEN" -> 0.20D; default -> 0D;
        };
        return 1D + quality + d.artifactLevel() * 0.02D;
    }
    public void refine(PlayerData d) { d.artifactLevel(d.artifactLevel() + 1); }
}
