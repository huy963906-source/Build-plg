package com.tcgame.tutiencore.command;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.skill.ClassSkillSystem;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.*;
import java.math.BigInteger;

public final class TuTienUserCommand implements CommandExecutor, TabCompleter {
    private final TuTienCore plugin;

    public TuTienUserCommand(TuTienCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("§cChỉ người chơi mới dùng được lệnh này.");
            return true;
        }

        String name = command.getName().toLowerCase(Locale.ROOT);
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());

        switch (name) {
            case "tutien" -> plugin.getCultivationMenu().open(p);
            case "cuahang" -> plugin.getCuaHangMenu().open(p);
            case "tuluyen" -> toggleTraining(p);
            case "dotpha" -> {
                if (args.length > 0 && args[0].equalsIgnoreCase("nhanh")) plugin.getBreakthroughService().quickAttempt(p);
                else if (args.length == 0) plugin.getBreakthroughMenu().open(p);
                else p.sendMessage("§7/dotpha §8| §7/dotpha nhanh");
            }
            case "dokiep" -> {
                if (!plugin.getTribulationSystem().startTrucCo(p))
                    p.sendMessage("§cBạn phải đạt Luyện Khí Tầng 10 và đầy Linh Khí để Độ Kiếp Trúc Cơ.");
            }
            case "rank" -> handleRank(p, args);
            case "thongtin" -> info(p, d);
            case "tongmon", "sect" -> {
                if (args.length == 0) plugin.getSectMenu().open(p);
                else sect(p, args);
            }
            case "bicanh", "dungeon" -> dungeon(p, args);
            case "nhiemvu", "quest" -> quest(p, args);
            case "autoquest" -> autoQuest(p, args);
            case "luyendan", "alchemy" -> alchemy(p, args);
            case "phapbao", "artifact" -> artifact(p, d, args);
            case "linhthu", "pet" -> pet(p, args);
            case "congphap", "technique" -> technique(p, d, args);
            case "tamphap" -> p.sendMessage("§3Tâm Pháp cấp §f" + d.tamPhapLevel() + " §7(tăng tốc tu luyện thụ động)");
            case "linhmach" -> linhMach(p, args);
            case "donthuat" -> donThuat(p, args);
            case "kinang" -> plugin.getSkillKeybindMenu().open(p);
            case "phaptuong" -> plugin.getHyperVN430System().useUltimate(p);
            case "phikhong" -> plugin.getPhiKhongService().toggle(p);
            case "bakhi", "aura" -> plugin.getAuraSystem().toggle(p);
            case "tuvi" -> plugin.getCultivationMenu().open(p);
            case "linhcan" -> plugin.getSpiritRootMenu().open(p);
            case "phai" -> phai(p, args);
            case "hothe" -> plugin.getServerFeatureSystem().handleHothe(p);
            case "loidai" -> plugin.getServerFeatureSystem().handleLoiDai(p, args);
            case "nhacnen" -> plugin.getServerFeatureSystem().toggleMusic(p);
            case "catlinhthach" -> catLinhThach(p);
            case "autocatlt" -> toggleAutoCatLinhThach(p);
            case "truvat", "tuitruvat" -> plugin.getStorageSystem().open(p);
            case "luanhoi" -> plugin.getKarmaMenu().openReincarnation(p);
            case "congduc" -> plugin.getKarmaMenu().openKarma(p);
            case "huyettelinhthu" -> plugin.getWorldRpgV3System().bloodSacrifice(p);
            default -> p.sendMessage("§cLệnh không hợp lệ.");
        }
        return true;
    }


    private void donThuat(Player p, String[] args) {
        PlayerData data = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (data.realm().ordinal() < com.tcgame.tutiencore.cultivation.Realm.KIM_DAN.ordinal()) {
            p.sendMessage("§cĐộn Thuật yêu cầu tối thiểu §dKim Đan Tầng 1§c.");
            return;
        }
        if (args.length == 0) { plugin.getNguKiemService().toggle(p); return; }
        if (args[0].equalsIgnoreCase("skill") && args.length >= 2) { plugin.getNguKiemService().useSkill(p, args[1]); return; }
        if (args[0].equalsIgnoreCase("skills") || args[0].equalsIgnoreCase("list")) { plugin.getNguKiemService().sendSkills(p); return; }
        if (args[0].equalsIgnoreCase("stop")) { if (plugin.getNguKiemService().isFlying(p)) plugin.getNguKiemService().stop(p); else p.sendMessage("§7Độn Thuật hiện không hoạt động."); return; }
        p.sendMessage("§b/donthuat §7| §f/donthuat skills §7| §f/donthuat skill <tên>");
    }


    private void phai(Player p, String[] args) {
        var cs = plugin.getClassSkillSystem();
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (args.length == 0) { plugin.getClassSelectMenu().open(p); return; }
        if (args[0].equalsIgnoreCase("info")) {
            p.sendMessage("§d§l✦ PHÁI TU LUYỆN ✦");
            p.sendMessage("§7Phái hiện tại: §f" + cs.className(d.cultivationClass()));
            p.sendMessage("§7Chọn phái: §f/phai chon <kiem_tu|ma_tu|quy_tu|phat_tu|doc_tu|tan_tu>");
            p.sendMessage("§7Xem skill: §f/phai skills");
            return;
        }
        if (args[0].equalsIgnoreCase("chon") && args.length >= 2) {
            String id=args[1].toUpperCase(Locale.ROOT);
            if (!cs.classIds().contains(id)) { p.sendMessage("§cPhái không hợp lệ. §7Dùng /phai để xem danh sách."); return; }
            if (cs.chooseClass(p,id)) p.sendMessage("§a✦ Đã chọn phái: §f"+cs.className(id));
            return;
        }
        if (args[0].equalsIgnoreCase("skills")) {
            p.sendMessage("§d§l✦ 12 KỸ NĂNG - "+cs.className(d.cultivationClass()));
            int i=1; for (var sk:cs.skills(d.cultivationClass())) p.sendMessage("§e"+i+". §f"+sk.name()+" §7(Cấp "+d.classSkillLevel(sk.id())+")");
            if(d.cultivationClass().equals("TAN_TU") && !d.stolenSkills().isEmpty()){ p.sendMessage("§dBí kỹ học lỏm:"); for(String id:d.stolenSkills()) p.sendMessage("§5- §f"+id+" §7(Cấp "+d.classSkillLevel(id)+")"); }
            p.sendMessage("§7Chọn skill: §f/phai skill <1-12> §7| Tán Tu: §f/phai skill stolen <skill-id>"); return;
        }
        if (args[0].equalsIgnoreCase("skill") && args.length >= 2) {
            if (args[1].equalsIgnoreCase("stolen") && args.length >= 3) { cs.selectSkillId(p,args[2]); return; }
            try { cs.selectSkill(p,Integer.parseInt(args[1])); } catch(NumberFormatException ex){p.sendMessage("§cNhập số 1-12 hoặc /phai skill stolen <id>.");} return;
        }
        if (args[0].equalsIgnoreCase("weapon")) { p.getInventory().addItem(cs.createClassWeapon(d.cultivationClass())); p.sendMessage("§aĐã nhận vũ khí của phái §f"+cs.className(d.cultivationClass())); return; }
        p.sendMessage("§7/phai | /phai chon <phái> | /phai skills | /phai skill <1-12> | /phai weapon");
    }

    private void toggleAutoCatLinhThach(Player p) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        boolean next = !d.autoCatLinhThach();
        d.autoCatLinhThach(next);
        plugin.getCultivationService().save(p.getUniqueId());
        if (next) {
            p.sendMessage("§e§l✦ AUTO CẤT LINH THẠCH: §aBẬT");
            p.sendMessage("§7Tự cất Linh Thạch trong túi và trong bán kính §f5 block§7.");
        } else {
            p.sendMessage("§e§l✦ AUTO CẤT LINH THẠCH: §cTẮT");
        }
    }

    private void catLinhThach(Player p) {
        int physical = plugin.getAlchemySystem().countLinhThach(p);
        if (physical <= 0) {
            p.sendMessage("§cBạn không có Linh Thạch vật phẩm để cất.");
            p.sendMessage("§7Linh Thạch trong không gian: §e" + plugin.getLinhThachBankService().balance(p.getUniqueId()));
            return;
        }
        int removed = 0;
        for (int slot = 0; slot < p.getInventory().getSize(); slot++) {
            org.bukkit.inventory.ItemStack item = p.getInventory().getItem(slot);
            if (plugin.getAlchemySystem().isLinhThach(item)) {
                removed += item.getAmount();
                p.getInventory().setItem(slot, null);
            }
        }
        BigInteger balance = plugin.getLinhThachBankService().deposit(p.getUniqueId(), BigInteger.valueOf(removed));
        plugin.getLinhThachBankService().save();
        p.sendMessage("§e✦ Đã cất §f" + removed + " §eLinh Thạch vào Không Gian Linh Thạch.");
        p.sendMessage("§7Số dư: §e" + balance);
    }

    private void toggleTraining(Player p) {
        if (plugin.getTrainingManager().isTraining(p.getUniqueId())) plugin.getTrainingManager().stop(p);
        else plugin.getTrainingManager().start(p);
    }

    private void handleRank(Player p, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("info")) showRank(p);
        else plugin.getRankSystem().purchase(p);
    }

    private void showRank(Player p) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        int rank = d.rankLevel();
        int max = plugin.getRankSystem().visibleMaxRank();
        if (rank >= max) {
            p.sendMessage("§6§lRank §7| §f" + plugin.getRankSystem().name(rank) + " §7(max hiện tại)");
            return;
        }
        int cost = plugin.getRankSystem().costForNext(rank);
        p.sendMessage("§6§lRank hiện tại: §f" + plugin.getRankSystem().name(rank));
        p.sendMessage("§7Rank kế tiếp: §f" + plugin.getRankSystem().name(rank + 1) + " §7| Giá: §e" + cost + " PlayerPoints");
        p.sendMessage("§7Mua: §f/rank");
    }

    private void info(Player p, PlayerData d) {
        p.sendMessage("§5§lTu Tiên");
        p.sendMessage("§7❖ Cảnh Giới: §f" + d.realmDisplay());
        p.sendMessage("§7❖ Linh Khí: §f" + String.format(Locale.ROOT, "%.0f", d.linhKhi()) + "§7/§f" + d.nextLinhKhiStageThreshold());
        p.sendMessage("§7❖ Tiến Độ: §f" + String.format(Locale.ROOT, "%.1f%%", d.progress() * 100));
        p.sendMessage("§7❖ Linh Căn: §d" + d.spiritRootDisplay());
        p.sendMessage("§7❖ Căn Cốt: §f" + d.canCot() + " §7| Ngộ Tính: §f" + d.ngoTinh());
        p.sendMessage("§7❖ Rank: §f" + plugin.getRankSystem().name(d.rankLevel()));
        p.sendMessage(plugin.getSectSystem().info(p));
    }

    private void sect(Player p, String[] a) {
        if (a.length == 0 || a[0].equalsIgnoreCase("thongtin")) { p.sendMessage(plugin.getSectSystem().info(p)); return; }
        String action = a[0].toLowerCase(Locale.ROOT);
        switch (action) {
            case "tao", "create" -> {
                if (a.length < 2) { p.sendMessage("§c/tongmon tao <ten>"); return; }
                String name = String.join(" ", Arrays.copyOfRange(a, 1, a.length));
                p.sendMessage(plugin.getSectSystem().create(p, name) ? "§aDa thanh lap tong mon." : "§cKhong the thanh lap.");
            }
            case "join" -> {
                if (a.length < 2) { p.sendMessage("§c/tongmon join <ten>"); return; }
                String name = String.join(" ", Arrays.copyOfRange(a, 1, a.length));
                p.sendMessage(plugin.getSectSystem().join(p, name) ? "§aDa gia nhap tong mon." : "§cKhong the gia nhap.");
            }
            case "leave", "roi" -> p.sendMessage(plugin.getSectSystem().leave(p) ? "§eĐã rời Tông Môn." : "§cKhông thể rời. Tông Chủ cần dùng disband để giải tán tông môn.");
            case "disband", "giaitan", "huy" -> plugin.getSectSystem().disband(p);
            case "contribute", "donggop" -> {
                if (a.length < 2) { p.sendMessage("§c/tongmon donggop <linhthach>"); return; }
                try { p.sendMessage(plugin.getSectSystem().contribute(p, Integer.parseInt(a[1])) ? "§aDa dong gop." : "§cDong gop that bai."); }
                catch (NumberFormatException ex) { p.sendMessage("§cSo khong hop le."); }
            }
            case "truyentong" -> p.sendMessage(plugin.getSectSystem().teleportHome(p) ? "§aDa truyen tong ve Tam Tong Mon." : "§cTong mon chua co Core Beacon.");
            case "tangkinhcac" -> { p.getInventory().addItem(plugin.getSectSystem().createLibraryCoreItem()); p.sendMessage("§5✦ Đã nhận §fTàng Kinh Các Core§5. Đặt xuống tại vị trí muốn đăng ký."); }
            default -> p.sendMessage("§6/tongmon thongtin | tao <ten> | join <ten> | roi | disband | donggop <so> | truyentong | tangkinhcac");
        }
    }

    private void dungeon(Player p, String[] a) {
        if (a.length > 0 && a[0].equalsIgnoreCase("enter")) plugin.getDungeonSystem().enter(p);
        else p.sendMessage("§5/bicanh enter");
    }

    private void quest(Player p, String[] a) {
        if (a.length >= 2 && a[0].equalsIgnoreCase("claim")) {
            plugin.getQuestSystem().claim(p, a[1]);
        } else {
            plugin.getQuestMenu().open(p);
        }
    }

    private void autoQuest(Player p, String[] a) {
        if (a.length > 0 && a[0].equalsIgnoreCase("remove")) {
            plugin.getAutoQuestSystem().removeNearbyQuestElders(p);
        } else {
            plugin.getAutoQuestSystem().spawnQuestElder(p);
        }
    }

    private void alchemy(Player p, String[] a) {
        if (a.length > 0 && a[0].equalsIgnoreCase("pill")) plugin.getAlchemySystem().useCultivationPill(p);
        else plugin.getAlchemySystem().open(p);
    }

    private void artifact(Player p, PlayerData d, String[] a) {
        if (a.length > 0 && a[0].equalsIgnoreCase("refine")) {
            plugin.getArtifactSystem().refine(d);
            p.sendMessage("§6✦ Pháp bảo đã tinh luyện lên cấp " + d.artifactLevel());
        } else {
            p.sendMessage("§6Pháp bảo: §f" + d.artifactQuality() + " §7cấp §f" + d.artifactLevel());
        }
    }

    private void pet(Player p, String[] a) {
        if (a.length == 0 || a[0].equalsIgnoreCase("gui") || a[0].equalsIgnoreCase("menu")) { plugin.getPetSystem().openMenu(p); return; }
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (a.length > 0 && a[0].equalsIgnoreCase("summon")) {
            plugin.getPetSystem().summon(d, a.length > 1 ? String.join(" ", Arrays.copyOfRange(a, 1, a.length)) : "Linh Thú");
            p.sendMessage("§aĐã triệu hồi linh thú: §f" + d.petName());
        } else if (a.length > 0 && a[0].equalsIgnoreCase("dismiss")) {
            plugin.getPetSystem().dismiss(d);
            p.sendMessage("§7Đã thu hồi linh thú.");
        } else {
            p.sendMessage("§aLinh Thú: §f" + (d.petName().isBlank() ? "Chưa có" : d.petName()) + " §7Level §f" + d.petLevel());
        }
    }

    private void technique(Player p, PlayerData d, String[] args) {
        var ts = plugin.getTechniqueSystem();
        if (args.length == 0 || args[0].equalsIgnoreCase("thongtin")) {
            p.sendMessage("§5§l✦ CONG PHAP ✦");
            p.sendMessage(ts.pretty(d));
            p.sendMessage("§7Thiên phú: §f" + d.techniqueTalent() + " §7| Hieu qua tu luyen: §f" + String.format(Locale.ROOT, "%.0f%%", ts.cultivationMultiplier(d) * 100));
            return;
        }
        if (args[0].equalsIgnoreCase("danhsach")) {
            p.sendMessage("§5§l✦ DANH SACH CONG PHAP");
            for (var t : ts.all()) p.sendMessage("§d" + t.id() + " §7- §f" + t.name() + " §8[" + t.element() + "] §7x" + String.format(Locale.ROOT, "%.2f", t.multiplier()));
            return;
        }
        if (args[0].equalsIgnoreCase("hoc") && args.length >= 2) {
            var t = ts.get(args[1]);
            if (t == null) { p.sendMessage("§cKhong tim thay cong phap."); return; }
            if (t.id().equalsIgnoreCase(d.techniqueId())) { p.sendMessage("§cBạn đã đang dùng công pháp này."); return; }
            if (t.cost() > 0 && d.linhKhi() < t.cost()) { p.sendMessage("§cCần " + t.cost() + " Linh Khí để học công pháp này."); return; }
            if (t.cost() > 0) d.linhKhi(d.linhKhi() - t.cost());
            if (ts.learn(d, t.id())) {
                plugin.getCultivationService().save(p.getUniqueId());
                p.sendTitle("§5§lCONG PHAP KHAI MO", "§f" + t.name(), 8, 45, 12);
                p.sendMessage("§a✦ Da hoc: §f" + t.name() + " §7(" + t.element() + ")");
            } else p.sendMessage("§cKhông thể học công pháp này.");
            return;
        }
        p.sendMessage("§7/congphap thongtin");
        p.sendMessage("§7/congphap danhsach");
        p.sendMessage("§7/congphap hoc <id>");
    }

    private void linhMach(Player p, String[] a) {
        if (a.length >= 3 && a[0].equalsIgnoreCase("create")) {
            try {
                double bonus = Double.parseDouble(a[2]);
                p.sendMessage(plugin.getLinhMachService().createFromSelection(p, a[1], bonus)
                        ? "§aĐã tạo Linh Mạch §f" + a[1] + " §7bonus §f" + (bonus * 100) + "%"
                        : "§cKhông thể tạo Linh Mạch. Hãy chọn vùng bằng WorldEdit.");
            } catch (NumberFormatException ex) { p.sendMessage("§cBonus không hợp lệ."); }
        } else if (a.length >= 1 && a[0].equalsIgnoreCase("list")) {
            p.sendMessage("§6Linh Mạch: §f" + plugin.getLinhMachService().all().size() + " vùng");
        } else {
            p.sendMessage("§6/linhmach create <tên> <thưởng> | list");
        }
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (name.equals("rank")) return args.length == 1 ? filter(List.of("info", "buy"), args[0]) : List.of();
        return switch (name) {
            case "tongmon", "sect" -> args.length == 1 ? filter(List.of("tao", "join", "leave", "disband", "contribute", "truyentong", "tangkinhcac", "thongtin"), args[0]) : List.of();
            case "bicanh", "dungeon" -> args.length == 1 ? filter(List.of("enter"), args[0]) : List.of();
            case "nhiemvu", "quest" -> args.length == 1 ? filter(List.of("claim"), args[0]) : List.of();
            case "autoquest" -> args.length == 1 ? filter(List.of("remove"), args[0]) : List.of();
            case "luyendan", "alchemy" -> args.length == 1 ? filter(List.of("pill"), args[0]) : List.of();
            case "phapbao", "artifact" -> args.length == 1 ? filter(List.of("refine"), args[0]) : List.of();
            case "linhthu", "pet" -> args.length == 1 ? filter(List.of("summon", "dismiss"), args[0]) : List.of();
            case "linhmach" -> args.length == 1 ? filter(List.of("create", "list"), args[0]) : List.of();
            case "congphap", "technique" -> args.length == 1 ? filter(List.of("thongtin", "danhsach", "hoc"), args[0]) : List.of();
            case "donthuat" -> args.length == 1 ? filter(List.of("skills", "stop", "skill"), args[0]) : (args.length == 2 && args[0].equalsIgnoreCase("skill") ? filter(List.of("phi-hanh", "luu-quang", "thang-thien", "hoan-luu", "phong-ba", "thien-mon", "tinh-van"), args[1]) : List.of());
            case "loidai" -> args.length == 1 ? filter(List.of("accept", "deny", "surrender", "info", "set1", "set2", "setlobby"), args[0]) : List.of();
            default -> List.of();
        };
    }

    private List<String> filter(List<String> in, String prefix) {
        return in.stream().filter(x -> x.toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))).toList();
    }
}
