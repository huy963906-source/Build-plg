package com.tcgame.tutiencore.command;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.cultivation.Realm;
import com.tcgame.tutiencore.spiritroot.SpiritRootQuality;
import com.tcgame.tutiencore.spiritroot.SpiritRootType;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.inventory.ItemStack;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.Location;
import com.sk89q.worldedit.IncompleteRegionException;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.bukkit.WorldEditPlugin;
import com.sk89q.worldedit.regions.Region;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public final class TuTienAdminCommand implements CommandExecutor, TabCompleter {
    private final TuTienCore plugin;
    public TuTienAdminCommand(TuTienCore plugin) { this.plugin = plugin; }

    @Override public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                                       @NotNull String label, @NotNull String[] args) {
        if (label.equalsIgnoreCase("lichsuchat") || label.equalsIgnoreCase("smute") || label.equalsIgnoreCase("giaodichlog") || label.equalsIgnoreCase("baohiem")) {
            if (!(sender instanceof Player staff)) { sender.sendMessage("§cLệnh Staff cần người chơi."); return true; }
            return plugin.getStaffFeatureSystem().handleCommand(staff, label, args);
        }
        if (!sender.hasPermission("tutien.admin")) { sender.sendMessage("§cKhông có quyền. Cần tutien.admin."); return true; }

        // Basic name-ban management through Bukkit's native ban list.
        if ((label.equalsIgnoreCase("tutienad") || label.equalsIgnoreCase("tta"))
                && args.length >= 1 && (args[0].equalsIgnoreCase("ban") || args[0].equalsIgnoreCase("unban"))) {
            boolean ban = args[0].equalsIgnoreCase("ban");
            if (args.length < 2 || args[1].isBlank()) {
                sender.sendMessage(ban ? "§eDùng: /tta ban <player> [lý do]" : "§eDùng: /tta unban <player>");
                return true;
            }
            String targetName = args[1].trim();
            org.bukkit.BanList<String> banList = Bukkit.getBanList(org.bukkit.BanList.Type.NAME);
            if (ban) {
                String reason = args.length > 2 ? String.join(" ", Arrays.copyOfRange(args, 2, args.length)) : "Bị quản trị viên cấm khỏi máy chủ";
                if (banList.isBanned(targetName)) {
                    sender.sendMessage("§eNgười chơi §f" + targetName + " §eđã bị ban rồi.");
                    return true;
                }
                banList.addBan(targetName, reason, null, sender.getName());
                Player online = Bukkit.getPlayerExact(targetName);
                if (online != null) online.kickPlayer("§cBạn đã bị cấm khỏi máy chủ.\n§7Lý do: §f" + reason);
                sender.sendMessage("§aĐã ban §f" + targetName + "§a. Lý do: §f" + reason);
            } else {
                if (!banList.isBanned(targetName)) {
                    sender.sendMessage("§eNgười chơi §f" + targetName + " §echưa bị ban.");
                    return true;
                }
                banList.pardon(targetName);
                sender.sendMessage("§aĐã unban §f" + targetName + "§a.");
            }
            return true;
        }

        // Emergency recovery for players stuck floating after a broken/interrupted tribulation.
        if ((label.equalsIgnoreCase("tutienad") || label.equalsIgnoreCase("tta"))
                && args.length >= 1 && args[0].equalsIgnoreCase("gravity")) {
            if (args.length < 3 || !args[2].equalsIgnoreCase("reset")) {
                sender.sendMessage("§e/tta gravity <player> reset");
                return true;
            }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage("§cKhông tìm thấy player đang online: §f" + args[1]);
                return true;
            }
            plugin.getTribulationSystem().forceRestorePlayer(target);
            sender.sendMessage("§a✓ Đã reset gravity + trạng thái Đột Phá/Độ Kiếp cho §f" + target.getName());
            return true;
        }

        if (label.equalsIgnoreCase("anticheat")) {
            if (!(sender instanceof org.bukkit.entity.Player p)) { sender.sendMessage("§cLệnh này cần đứng trong game."); return true; }
            if (!p.hasPermission("tutien.admin")) { p.sendMessage("§cBạn không có quyền."); return true; }
            plugin.getAntiCheatMenu().open(p);
            return true;
        }

        if (label.equalsIgnoreCase("setafk") || label.equalsIgnoreCase("setafklinhthach")) {
            String[] merged = new String[args.length + 1];
            merged[0] = label.equalsIgnoreCase("setafk") ? "setafk" : "setafklinhthach";
            System.arraycopy(args, 0, merged, 1, args.length);
            return handleAfk(sender, merged);
        }

        if ((label.equalsIgnoreCase("tutienad") || label.equalsIgnoreCase("tta")) && args.length >= 1 && args[0].equalsIgnoreCase("kiem")) {
            if (!(sender instanceof Player admin)) { sender.sendMessage("§cLệnh này cần người chơi hoặc thêm target."); return true; }
            String skill = args.length >= 2 ? args[1].toLowerCase(Locale.ROOT) : "liet-hoa-tram";
            Player target = args.length >= 3 ? Bukkit.getPlayerExact(args[2]) : admin;
            if (target == null) { sender.sendMessage("§cKhông tìm thấy player."); return true; }
            if (!plugin.getCultivationService().getPlayerData(target.getUniqueId()).cultivationClass().equalsIgnoreCase("KIEM_TU")) { sender.sendMessage("§cChỉ có thể cấp Kiếm Kỹ cho người chơi thuộc phái §fKiếm Tu§c."); return true; }
            if (!plugin.getSkillSwordSystem().skills().contains(skill)) { sender.sendMessage("§cSkill không hợp lệ: §f" + String.join(", ", plugin.getSkillSwordSystem().skills())); return true; }
            target.getInventory().addItem(plugin.getSkillSwordSystem().createSword(skill));
            sender.sendMessage("§aĐã cấp Kiếm Kỹ §f" + plugin.getSkillSwordSystem().skillName(skill) + " §acho §f" + target.getName());
            return true;
        }
        if ((label.equalsIgnoreCase("tutienad") || label.equalsIgnoreCase("tta")) && args.length >= 1 && args[0].equalsIgnoreCase("sachskill")) {
            if (!(sender instanceof Player admin)) { sender.sendMessage("§cLệnh này cần người chơi hoặc thêm target."); return true; }
            String skill = args.length >= 2 ? args[1].toLowerCase(Locale.ROOT) : "liet-hoa-tram";
            Player target = args.length >= 3 ? Bukkit.getPlayerExact(args[2]) : admin;
            if (target == null) { sender.sendMessage("§cKhông tìm thấy player."); return true; }
            if (!plugin.getCultivationService().getPlayerData(target.getUniqueId()).cultivationClass().equalsIgnoreCase("KIEM_TU")) { sender.sendMessage("§cChỉ có thể cấp Kiếm Kỹ cho người chơi thuộc phái §fKiếm Tu§c."); return true; }
            if (!plugin.getSkillSwordSystem().skills().contains(skill)) { sender.sendMessage("§cSkill không hợp lệ: §f" + String.join(", ", plugin.getSkillSwordSystem().skills())); return true; }
            target.getInventory().addItem(plugin.getSkillSwordSystem().createSkillBook(skill));
            sender.sendMessage("§aĐã cấp Sách Kiếm Kỹ §f" + plugin.getSkillSwordSystem().skillName(skill) + " §acho §f" + target.getName());
            return true;
        }

        if ((label.equalsIgnoreCase("tutienad") || label.equalsIgnoreCase("tta")) && args.length >= 1 && args[0].equalsIgnoreCase("phaiskillbook")) {
            if (!(sender instanceof Player admin)) { sender.sendMessage("§cLệnh này cần người chơi."); return true; }
            if (args.length < 3) { sender.sendMessage("§e/tta phaiskillbook <phái> <1-12> [player]"); return true; }
            String cls=args[1].toUpperCase(Locale.ROOT); int index; try { index=Integer.parseInt(args[2]); } catch(NumberFormatException ex){sender.sendMessage("§cSkill phải từ 1-12."); return true;}
            if (!plugin.getClassSkillSystem().classIds().contains(cls) || index<1 || index>12) { sender.sendMessage("§cPhái hoặc skill không hợp lệ."); return true; }
            Player target=args.length>=4?Bukkit.getPlayerExact(args[3]):admin; if(target==null){sender.sendMessage("§cKhông tìm thấy player.");return true;}
            target.getInventory().addItem(plugin.getClassSkillSystem().createSkillBook(cls,index)); sender.sendMessage("§aĐã cấp sách skill §f"+index+" §acho §f"+target.getName()); return true;
        }

        if ((label.equalsIgnoreCase("tutienad") || label.equalsIgnoreCase("tta")) && args.length >= 1 && args[0].equalsIgnoreCase("phaiweapon")) {
            if (!(sender instanceof Player admin)) { sender.sendMessage("§cLệnh này cần người chơi."); return true; }
            String cls=args.length>=2?args[1].toUpperCase(Locale.ROOT):plugin.getCultivationService().getPlayerData(admin.getUniqueId()).cultivationClass();
            if(!plugin.getClassSkillSystem().classIds().contains(cls)){sender.sendMessage("§cPhái không hợp lệ.");return true;}
            Player target=args.length>=3?Bukkit.getPlayerExact(args[2]):admin; if(target==null){sender.sendMessage("§cKhông tìm thấy player.");return true;}
            target.getInventory().addItem(plugin.getClassSkillSystem().createClassWeapon(cls)); sender.sendMessage("§aĐã cấp vũ khí phái §f"+plugin.getClassSkillSystem().className(cls)+" §acho §f"+target.getName()); return true;
        }

        if (label.equalsIgnoreCase("tutiencore") && args.length > 0 && args[0].equalsIgnoreCase("admin")) {
            if (!(sender instanceof Player admin)) { sender.sendMessage("§cGUI quản trị chỉ dùng bởi người chơi."); return true; }
            if (args.length <= 1) { plugin.getAdminMenu().openSelector(admin); return true; }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { admin.sendMessage("§cKhông tìm thấy người chơi đang online."); return true; }
            plugin.getAdminMenu().open(admin, target);
            return true;
        }

        // Numbered custom realm display slots. Supports the requested typo alias "reaml" too.
        if ((label.equalsIgnoreCase("tutienad") || label.equalsIgnoreCase("tta"))
                && args.length >= 1 && args[0].equalsIgnoreCase("create")
                && args.length >= 2 && (args[1].equalsIgnoreCase("realm") || args[1].equalsIgnoreCase("reaml"))) {
            if (args.length < 4) {
                sender.sendMessage("§eDùng: /tta create realm <số-rank> <tên cảnh giới>");
                sender.sendMessage("§7Rank 1 = Luyện Khí, 2 = Trúc Cơ, ...; nhập lại số để thay tên rank đó.");
                return true;
            }
            int index;
            try { index = Integer.parseInt(args[2]); }
            catch (NumberFormatException ex) { sender.sendMessage("§cSố rank phải là số nguyên."); return true; }
            Realm targetRealm = Realm.byRankIndex(index);
            if (targetRealm == null) {
                sender.sendMessage("§cRank không hợp lệ. Hãy chọn số từ 1 đến " + (Realm.values().length - 1) + ".");
                return true;
            }
            String display = String.join(" ", Arrays.copyOfRange(args, 3, args.length)).trim()
                    .replaceAll("[§&][0-9a-fk-orA-FK-OR]", "");
            if (display.isBlank() || display.length() > 64) {
                sender.sendMessage("§cTên cảnh giới phải dài 1-64 ký tự."); return true;
            }
            String path = "custom-realms.names." + targetRealm.name();
            String previous = plugin.getConfig().getString(path, targetRealm.name());
            plugin.getConfig().set(path, display);
            plugin.saveConfig();
            Realm.loadCustomDisplayNames(plugin.getConfig().getConfigurationSection("custom-realms.names"));
            sender.sendMessage("§a✦ Đã " + (previous.equals(targetRealm.name()) ? "tạo tên tùy chỉnh" : "thay tên")
                    + " cho rank §f#" + index + " §8(" + targetRealm.name() + ")§a: §e" + display);
            sender.sendMessage("§7Dùng lại /tta create realm " + index + " <tên mới> để thay tên. ID rank và dữ liệu người chơi được giữ nguyên.");
            return true;
        }

        // /tta is the short alias of /tutienad.
        // Reload only the TuTienCore config so admins do not need to restart the server.
        if ((label.equalsIgnoreCase("tutienad") || label.equalsIgnoreCase("tta"))
                && args.length >= 1 && args[0].equalsIgnoreCase("reload")) {
            plugin.reloadConfig();
            Realm.loadCustomDisplayNames(plugin.getConfig().getConfigurationSection("custom-realms.names"));
            sender.sendMessage("§a✦ TuTienCore đã reload config thành công.");
            sender.sendMessage("§7Âm-Dương, tốc độ tu luyện, LinhZone và các giá trị config đọc động đã được áp dụng ngay.");
            return true;
        }

        // /tta is the short alias of /tutienad. With no arguments it opens the
        // admin GUI directly; resource subcommands remain available.
        if ((label.equalsIgnoreCase("tutienad") || label.equalsIgnoreCase("tta")) && args.length == 0) {
            if (!(sender instanceof Player admin)) { sender.sendMessage("§cGUI quản trị chỉ dùng bởi người chơi."); return true; }
            plugin.getAdminMenu().openSelector(admin);
            return true;
        }

        if (args.length < 1) { help(sender); return true; }
        String resource = args[0].toLowerCase(Locale.ROOT);

        if (resource.equals("stage") && args.length >= 3 && args[1].equalsIgnoreCase("unlock")) {
            try {
                int stage = Integer.parseInt(args[2]);
                OfflinePlayer target = resolveTarget(sender, args, 3);
                if (target == null) return true;
                if (stage != 1) { sender.sendMessage("§cHiện hệ thống nhiệm vụ miễn phí chỉ mở Luyện Khí Tầng 1."); return true; }
                if (!(target instanceof Player online)) { sender.sendMessage("§cNgười chơi phải online để hoàn tất mở khóa nhập môn."); return true; }
                boolean unlocked = plugin.getInitiationSystem().unlock(online, true);
                sender.sendMessage(unlocked ? "§aĐã mở khóa §fLuyện Khí Tầng 1 §amiễn phí cho §f" + target.getName() + "§a." : "§ePlayer này đã mở khóa tu luyện rồi.");
            } catch (NumberFormatException ex) { sender.sendMessage("§cTầng không hợp lệ."); }
            return true;
        }

        if (resource.equals("rank") && args.length >= 3 && args[1].equalsIgnoreCase("set")) {
            try {
                int level = Integer.parseInt(args[2]);
                if (level < 1 || level > 30) throw new NumberFormatException();
                OfflinePlayer target = resolveTarget(sender, args, 3);
                if (target == null) return true;
                PlayerData d = plugin.getCultivationService().getPlayerData(target.getUniqueId());
                d.rankLevel(level); plugin.getCultivationService().save(target.getUniqueId());
                sender.sendMessage("§aĐã đặt rank " + level + " (§f" + plugin.getRankSystem().name(level) + "§a) cho §f" + target.getName());
            } catch (NumberFormatException ex) { sender.sendMessage("§c/rank set <1-30> [người chơi]"); }
            return true;
        }

        if (args.length >= 1 && args[0].equalsIgnoreCase("addlinhzone")) {
            if (!(sender instanceof Player p)) { sender.sendMessage("§cLệnh này cần đứng trong game."); return true; }
            double radius = plugin.getConfig().getDouble("linhzone.default-radius", 20D);
            if (args.length >= 2) {
                try { radius = Double.parseDouble(args[1]); }
                catch (NumberFormatException ex) { sender.sendMessage("§cBán kính không hợp lệ. Ví dụ: /addlinhzone 25"); return true; }
            }
            if (radius <= 0 || radius > 500) { sender.sendMessage("§cBán kính phải từ 1 đến 500 block."); return true; }
            plugin.getLinhZoneManager().addZone(p.getLocation(), radius);
            sender.sendMessage("§a✦ Đã thêm LinhZone §f#" + plugin.getLinhZoneManager().zoneCount() + " §avới bán kính §f" + radius + "§a block.");
            sender.sendMessage("§7Người chơi trong vùng nhận §b×1.2 Linh Khí§7 khi tu luyện.");
            return true;
        }

        if (args.length >= 1 && (args[0].equalsIgnoreCase("setafk") || args[0].equalsIgnoreCase("setafklinhthach"))) return handleAfk(sender, args);
        if (args.length < 3) { help(sender); return true; }
        String action = args[1].toLowerCase(Locale.ROOT);
        OfflinePlayer target = resolveTarget(sender, args, 3);
        if (target == null) return true;
        PlayerData d = plugin.getCultivationService().getPlayerData(target.getUniqueId());
        try {
            switch (resource) {
                case "congduc" -> { long amount=Long.parseLong(args[2]); if(action.equals("set")) d.congDuc(amount); else if(action.equals("add")) d.addCongDuc(amount); else throw new NumberFormatException(); sender.sendMessage("§aCông Đức của §f"+target.getName()+" §a= §e"+d.congDuc()); }
                case "nghiepluc" -> { long amount=Long.parseLong(args[2]); if(action.equals("set")) d.nghiepLuc(amount); else if(action.equals("add")) d.addNghiepLuc(amount); else throw new NumberFormatException(); sender.sendMessage("§aNghiệp Lực của §f"+target.getName()+" §a= §c"+d.nghiepLuc()); }
                case "thanlucluanhoi" -> { long amount=Long.parseLong(args[2]); if(action.equals("set")) d.thanLucLuanHoi(amount); else if(action.equals("add")) d.addThanLucLuanHoi(amount); else throw new NumberFormatException(); sender.sendMessage("§aThần Lực Luân Hồi của §f"+target.getName()+" §a= §d"+d.thanLucLuanHoi()); }

                case "linhkhi" -> { double amount = Double.parseDouble(args[2]); if (action.equals("set")) plugin.getCultivationService().setLinhKhi(target.getUniqueId(), amount); else if (action.equals("add")) plugin.getCultivationService().addLinhKhi(target.getUniqueId(), amount); else throw new NumberFormatException(); sender.sendMessage("§aLinh Khí §f" + target.getName() + " §a= §b" + d.linhKhi()); }
                case "linhthach" -> { int amount = Integer.parseInt(args[2]); if (!(target.getPlayer() instanceof org.bukkit.entity.Player online)) { sender.sendMessage("§cLinh Thạch là vật phẩm, player phải online."); return true; } if (action.equals("set")) { removeAllLinhThach(online); if (amount > 0) giveLinhThach(online, amount); } else if (action.equals("add")) { if (amount <= 0) throw new NumberFormatException(); giveLinhThach(online, amount); } else throw new NumberFormatException(); sender.sendMessage("§aLinh Thạch vật phẩm của §f" + target.getName() + " §a= §e" + plugin.getAlchemySystem().countLinhThach(online)); }
                case "realm", "canhgioi" -> { if (!action.equals("set")) { sender.sendMessage("§cDùng realm set <REALM> [player]"); return true; } Realm r = Realm.byName(args[2]); if (r == null) { sender.sendMessage("§cCảnh giới không hợp lệ."); return true; } d.realm(r); d.realmStage(1); d.linhKhi(0); sender.sendMessage("§aĐã đặt cảnh giới: §f" + d.realmDisplay()); }
                case "linhcan", "spiritroot" -> { SpiritRootType type = SpiritRootType.byName(args[2]); if (type == null) { sender.sendMessage("§cLinh căn không hợp lệ."); return true; } SpiritRootQuality q = args.length >= 4 ? SpiritRootQuality.byName(args[3]) : d.spiritRootQuality(); d.spiritRoot(type); d.spiritRootQuality(q == null ? SpiritRootQuality.TRUNG_PHAM : q); sender.sendMessage("§aĐã đặt linh căn cho §f" + target.getName()); }
                case "cancot" -> { d.canCot(Double.parseDouble(args[2])); sender.sendMessage("§aĐã đặt Căn Cốt."); }
                case "ngotinh" -> { d.ngoTinh(Double.parseDouble(args[2])); sender.sendMessage("§aĐã đặt Ngộ Tính."); }
                case "congphap", "technique" -> { if (action.equals("exp")) plugin.getTechniqueSystem().addExp(d, Long.parseLong(args[2])); else if (action.equals("level")) d.techniqueLevel(Integer.parseInt(args[2])); else if (action.equals("talent")) d.techniqueTalent(Integer.parseInt(args[2])); else { sender.sendMessage("§c/tutienad congphap exp|level|talent <số> [player]"); return true; } sender.sendMessage("§aĐã chỉnh Công Pháp."); }
                case "tamphap" -> { d.tamPhapLevel(Integer.parseInt(args[2])); sender.sendMessage("§aĐã đặt Tâm Pháp."); }
                case "petxp" -> { plugin.getPetSystem().addXp(d, Long.parseLong(args[2])); sender.sendMessage("§aĐã cộng EXP linh thú."); }
                case "stage" -> { int stage = Integer.parseInt(args[2]); d.realmStage(stage); sender.sendMessage("§aĐã đặt Tầng: §f" + d.realmDisplay()); }
                default -> { sender.sendMessage("§cTài nguyên không hợp lệ."); return true; }
            }
            plugin.getCultivationService().save(target.getUniqueId());
        } catch (NumberFormatException ex) { sender.sendMessage("§cSố không hợp lệ."); }
        return true;
    }

    private boolean handleAfk(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage("§cLệnh này cần đứng trong game."); return true; }
        if (!plugin.getServer().getPluginManager().isPluginEnabled("WorldEdit") || !plugin.getServer().getPluginManager().isPluginEnabled("WorldGuard")) {
            sender.sendMessage("§cKhu AFK yêu cầu cả WorldEdit và WorldGuard."); return true;
        }
        String type = args[0].equalsIgnoreCase("setafk") ? "money" : "linhthach";
        String display = type.equals("money") ? "AFK Tiền" : "AFK Linh Thạch";
        String rawName = args.length >= 2 ? args[1] : type;
        String name = rawName.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "_");
        if (name.isBlank()) name = type;
        try {
            WorldEditPlugin we = (WorldEditPlugin) plugin.getServer().getPluginManager().getPlugin("WorldEdit");
            Region selection = we.getWorldEdit().getSessionManager().get(BukkitAdapter.adapt(p)).getSelection(BukkitAdapter.adapt(p.getWorld()));
            if (selection == null) { sender.sendMessage("§cHãy dùng //wand chọn 2 điểm trước."); return true; }
            RegionManager manager = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(p.getWorld()));
            if (manager == null) { sender.sendMessage("§cKhông lấy được RegionManager."); return true; }
            String regionId = "tutien_afk_" + type + "_" + name;
            BlockVector3 min = selection.getMinimumPoint(), max = selection.getMaximumPoint();
            ProtectedRegion old = manager.getRegion(regionId); if (old != null) manager.removeRegion(regionId);
            ProtectedCuboidRegion region = new ProtectedCuboidRegion(regionId, min, max);
            region.setPriority(50);
            region.setFlag(Flags.BUILD, StateFlag.State.DENY); region.setFlag(Flags.BLOCK_BREAK, StateFlag.State.DENY); region.setFlag(Flags.BLOCK_PLACE, StateFlag.State.DENY);
            region.setFlag(Flags.TNT, StateFlag.State.DENY); region.setFlag(Flags.CREEPER_EXPLOSION, StateFlag.State.DENY); region.setFlag(Flags.OTHER_EXPLOSION, StateFlag.State.DENY);
            region.setFlag(Flags.FIRE_SPREAD, StateFlag.State.DENY); region.setFlag(Flags.LIGHTER, StateFlag.State.DENY); region.setFlag(Flags.LAVA_FIRE, StateFlag.State.DENY);
            manager.addRegion(region); manager.save();
            plugin.getConfig().set("afk.regions." + regionId + ".type", type);
            plugin.getConfig().set("afk.regions." + regionId + ".world", p.getWorld().getName());
            plugin.getConfig().set("afk.regions." + regionId + ".display-name", name);
            plugin.saveConfig();
            sender.sendMessage("§a✦ Đã tạo " + display + " §f" + regionId + " §aở §f" + p.getWorld().getName());
            sender.sendMessage("§7Đứng trong vùng đủ " + plugin.getConfig().getInt("afk.interval-seconds",120) + "s sẽ nhận thưởng.");
            return true;
        } catch (IncompleteRegionException ex) { sender.sendMessage("§cWorldEdit chưa chọn đủ 2 điểm."); return true; }
          catch (Exception ex) { plugin.getLogger().warning("Không thể tạo region AFK: " + ex.getMessage()); sender.sendMessage("§cKhông thể tạo khu AFK. Xem console."); return true; }
    }

    private void giveLinhThach(org.bukkit.entity.Player player, int amount) {
        int left = amount;
        while (left > 0) {
            int stack = Math.min(64, left);
            for (ItemStack leftover : player.getInventory().addItem(plugin.getAlchemySystem().createLinhThachItem(stack)).values()) player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            left -= stack;
        }
    }

    private void removeAllLinhThach(org.bukkit.entity.Player player) {
        for (int slot = 0; slot < player.getInventory().getSize(); slot++) {
            ItemStack item = player.getInventory().getItem(slot);
            if (plugin.getAlchemySystem().isLinhThach(item)) player.getInventory().setItem(slot, null);
        }
    }

    private OfflinePlayer resolveTarget(CommandSender sender, String[] args, int playerIndex) {
        if (args.length > playerIndex) return Bukkit.getOfflinePlayer(args[playerIndex]);
        if (sender instanceof Player p) return p;
        sender.sendMessage("§cConsole phải chỉ định người chơi.");
        return null;
    }

    private void help(CommandSender sender) {
        sender.sendMessage("§6§lQuản trị Tu Tiên");
        sender.sendMessage("§e/tutiencore admin [player] §7| §e/tta §7(mở GUI)");
        sender.sendMessage("§e/tta ban <player> [lý do] §7| §e/tta unban <player>");
        sender.sendMessage("§e/tutienad reload §7- reload config không cần restart");
        sender.sendMessage("§e/tta create realm <số-rank> <tên> §7- tạo/thay tên cảnh giới theo số rank");
        sender.sendMessage("§e/tutienad linhkhi add|set <số> [player]");
        sender.sendMessage("§e/tutienad linhthach add|set <số> [player]");
        sender.sendMessage("§e/tutienad stage unlock 1 [player]");
        sender.sendMessage("§e/tutienad rank set <1-30> [player]");
        sender.sendMessage("§e/setafk §7| §e/setafklinhthach §7| §e/addlinhzone [radius] §8(admin)");
    }

    @Override public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] a) {
        if (alias.equalsIgnoreCase("tutiencore")) return a.length == 1 ? List.of("admin") : List.of();
        if (a.length == 1) return filter(List.of("ban", "unban", "gravity", "create", "setafk", "setafklinhthach", "addlinhzone", "linhkhi", "linhthach", "realm", "linhcan", "cancot", "ngotinh", "congphap", "tamphap", "petxp", "stage", "rank", "kiem", "sachskill", "phaiskillbook", "phaiweapon"), a[0]);
        if (a.length == 2 && a[0].equalsIgnoreCase("create")) return filter(List.of("realm", "reaml"), a[1]);
        if (a.length == 3 && a[0].equalsIgnoreCase("create") && (a[1].equalsIgnoreCase("realm") || a[1].equalsIgnoreCase("reaml"))) {
            List<String> indexes = new ArrayList<>(); for (int i = 1; i < Realm.values().length; i++) indexes.add(Integer.toString(i)); return filter(indexes, a[2]);
        }
        if (a.length == 2 && a[0].equalsIgnoreCase("ban")) return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), a[1]);
        if (a.length == 2 && a[0].equalsIgnoreCase("unban")) {
            List<String> names = new ArrayList<>();
            for (org.bukkit.BanEntry<String> entry : Bukkit.getBanList(org.bukkit.BanList.Type.NAME).getBanEntries()) names.add(entry.getTarget());
            return filter(names, a[1]);
        }
        if (a.length == 2 && a[0].equalsIgnoreCase("gravity")) return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        if (a.length == 3 && a[0].equalsIgnoreCase("gravity")) return List.of("reset");
        if (a.length == 2 && (a[0].equalsIgnoreCase("linhkhi") || a[0].equalsIgnoreCase("linhthach"))) return filter(List.of("add", "set"), a[1]);
        if (a.length == 2 && a[0].equalsIgnoreCase("stage")) return filter(List.of("unlock"), a[1]);
        if (a.length == 2 && a[0].equalsIgnoreCase("rank")) return filter(List.of("set"), a[1]);
        if (a.length == 3 && a[0].equalsIgnoreCase("realm")) { List<String> out = new ArrayList<>(); for (Realm r : Realm.values()) out.add(r.name()); return filter(out, a[2]); }
        if (a.length == 3 && a[0].equalsIgnoreCase("stage") && a[1].equalsIgnoreCase("unlock")) return List.of("1");
        if (a.length == 3 && a[0].equalsIgnoreCase("rank") && a[1].equalsIgnoreCase("set")) return List.of("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30");
        return List.of();
    }
    private List<String> filter(List<String> in, String prefix) { return in.stream().filter(x -> x.toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))).toList(); }
}
