package com.tcgame.tutiencore.afk;

import com.tcgame.tutiencore.TuTienCore;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.bukkit.WorldEditPlugin;
import com.sk89q.worldedit.regions.Region;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/** AFK regions use the WorldEdit selection as the WorldGuard reward boundary. */
public final class AfkRegionService {
    public static final String MONEY_REGION = "tutien_afk_money";
    public static final String LINH_THACH_REGION = "tutien_afk_linhthach";
    private final TuTienCore plugin;

    public AfkRegionService(TuTienCore plugin) { this.plugin = plugin; }

    public boolean available() {
        return Bukkit.getPluginManager().isPluginEnabled("WorldEdit")
                && Bukkit.getPluginManager().isPluginEnabled("WorldGuard");
    }

    public String createFromSelection(Player player, boolean money) {
        if (!available()) return "§cCần bật WorldEdit và WorldGuard trước.";
        WorldEditPlugin we = (WorldEditPlugin) Bukkit.getPluginManager().getPlugin("WorldEdit");
        if (we == null) return "§cKhông tìm thấy WorldEdit.";
        try {
            var weWorld = BukkitAdapter.adapt(player.getWorld());
            Region selection = we.getWorldEdit().getSessionManager()
                    .get(BukkitAdapter.adapt(player)).getSelection(weWorld);
            if (selection == null) return "§cChưa chọn vùng. Dùng WorldEdit //wand để chọn 2 góc trước.";

            var min = selection.getMinimumPoint();
            var max = selection.getMaximumPoint();
            String id = regionId(money);
            RegionManager manager = WorldGuard.getInstance().getPlatform().getRegionContainer().get(weWorld);
            if (manager == null) return "§cWorldGuard chưa tải vùng cho thế giới này.";

            ProtectedRegion old = manager.getRegion(id);
            if (old != null) manager.removeRegion(id);

            ProtectedCuboidRegion region = new ProtectedCuboidRegion(id, min, max);
            region.setPriority(50);
            region.setFlag(Flags.BUILD, StateFlag.State.DENY);
            region.setFlag(Flags.BLOCK_BREAK, StateFlag.State.DENY);
            region.setFlag(Flags.BLOCK_PLACE, StateFlag.State.DENY);
            region.setFlag(Flags.TNT, StateFlag.State.DENY);
            region.setFlag(Flags.CREEPER_EXPLOSION, StateFlag.State.DENY);
            region.setFlag(Flags.OTHER_EXPLOSION, StateFlag.State.DENY);
            region.setFlag(Flags.LIGHTER, StateFlag.State.DENY);
            region.setFlag(Flags.LAVA_FIRE, StateFlag.State.DENY);
            manager.addRegion(region);
            manager.save();
            return "§aĐã tạo lại WorldGuard RG §f" + id + " §aở thế giới §f" + player.getWorld().getName()
                    + "§a. Vùng đã khóa phá/đặt block.";
        } catch (Exception ex) {
            plugin.getLogger().warning("Không thể tạo AFK WorldGuard region: " + ex.getMessage());
            return "§cKhông thể tạo vùng AFK. Kiểm tra quyền WorldEdit/WorldGuard và console.";
        }
    }

    public boolean isInside(Player player, boolean money) {
        if (!available()) return false;
        var weWorld = BukkitAdapter.adapt(player.getWorld());
        RegionManager manager = WorldGuard.getInstance().getPlatform().getRegionContainer().get(weWorld);
        if (manager == null) return false;
        var point = BukkitAdapter.asBlockVector(player.getLocation());
        String id = regionId(money);
        return manager.getApplicableRegions(point).getRegions().stream()
                .anyMatch(region -> region.getId().equalsIgnoreCase(id));
    }

    private String regionId(boolean money) {
        String path = money ? "afk.worldguard-regions.money" : "afk.worldguard-regions.linh-thach";
        return plugin.getConfig().getString(path, money ? MONEY_REGION : LINH_THACH_REGION);
    }

    public boolean isInsideNamedRegion(Player player, boolean money) {
        if (!available()) return false;
        var world = BukkitAdapter.adapt(player.getWorld());
        RegionManager manager = WorldGuard.getInstance().getPlatform().getRegionContainer().get(world);
        if (manager == null) return false;
        String prefix = (money ? "tutien_afk_money_" : "tutien_afk_linhthach_");
        var point = BukkitAdapter.asBlockVector(player.getLocation());
        return manager.getApplicableRegions(point).getRegions().stream()
                .anyMatch(r -> r.getId().toLowerCase(java.util.Locale.ROOT).startsWith(prefix));
    }
}
