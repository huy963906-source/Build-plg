package com.tcgame.tutiencore.sect;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Persistent Tông Môn data, including the main Core and Tàng Kinh Các Core. */
public final class Sect {
    private final String id;
    private final String name;
    private final UUID owner;
    private double storage;
    private final Map<UUID, SectRank> members = new LinkedHashMap<>();
    private final Map<UUID, Integer> contributions = new LinkedHashMap<>();

    private String coreWorld = "";
    private double coreX;
    private double coreY;
    private double coreZ;

    private String libraryWorld = "";
    private double libraryX;
    private double libraryY;
    private double libraryZ;

    public Sect(String id, String name, UUID owner) {
        this.id = id;
        this.name = name;
        this.owner = owner;
        members.put(owner, SectRank.TONG_CHU);
    }

    public String id() { return id; }
    public String name() { return name; }
    public UUID owner() { return owner; }

    public double storage() { return storage; }
    public void storage(double v) { storage = Math.max(0D, v); }
    public void addStorage(double v) { storage(Math.max(0D, storage + v)); }

    public Map<UUID, SectRank> members() { return members; }
    public Map<UUID, Integer> contributions() { return contributions; }

    public void core(Location l) {
        if (l == null || l.getWorld() == null) return;
        coreWorld = l.getWorld().getName();
        coreX = l.getX();
        coreY = l.getY();
        coreZ = l.getZ();
    }

    public boolean hasCore() { return !coreWorld.isBlank(); }

    public void clearCore() {
        coreWorld = ""; coreX = coreY = coreZ = 0D;
    }

    public Location core() {
        World w = Bukkit.getWorld(coreWorld);
        return w == null ? null : new Location(w, coreX, coreY, coreZ);
    }

    /** Tàng Kinh Các Core location. */
    public void libraryCore(Location l) {
        if (l == null || l.getWorld() == null) return;
        libraryWorld = l.getWorld().getName();
        libraryX = l.getX();
        libraryY = l.getY();
        libraryZ = l.getZ();
    }

    /** True when the sect has placed its Tàng Kinh Các Core. */
    public boolean hasLibraryCore() { return !libraryWorld.isBlank(); }

    /** Tàng Kinh Các Core location, or null if its world is unavailable. */
    public Location libraryCore() {
        World w = Bukkit.getWorld(libraryWorld);
        return w == null ? null : new Location(w, libraryX, libraryY, libraryZ);
    }
}
