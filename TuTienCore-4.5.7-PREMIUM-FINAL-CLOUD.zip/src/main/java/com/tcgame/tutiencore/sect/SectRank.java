package com.tcgame.tutiencore.sect;
public enum SectRank {
    TONG_CHU("Tông Chủ", 100), PHO_TONG_CHU("Phó Tông Chủ", 80), TRUONG_LAO("Trưởng Lão", 60), NOI_MON("Nội Môn", 40), NGOAI_MON("Ngoại Môn", 20);
    private final String displayName; private final int priority;
    SectRank(String n, int p) { displayName = n; priority = p; }
    public String displayName() { return displayName; } public int priority() { return priority; }
    public static SectRank byName(String s) { for (SectRank r: values()) if (r.name().equalsIgnoreCase(s)||r.displayName().equalsIgnoreCase(s)) return r; return NGOAI_MON; }
}
