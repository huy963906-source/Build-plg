package com.tcgame.tutiencore.sect;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.OfflinePlayer;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.session.ClipboardHolder;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion;
import java.io.FileInputStream;

public final class SectSystem {
    private final TuTienCore plugin;
    private final File file;
    private final Map<String,Sect> sects = new ConcurrentHashMap<>();
    public SectSystem(TuTienCore plugin) { this.plugin=plugin; file=new File(plugin.getDataFolder(),"sects.yml"); load(); }
    public Sect get(String id){ return sects.get(id); }
    public Sect getByName(String name){ for(Sect s:sects.values()) if(s.name().equalsIgnoreCase(name)) return s; return null; }
    public Collection<Sect> all(){return sects.values();}
    public boolean create(Player p,String name){
        if(name==null||name.isBlank()||getByName(name)!=null) return false;
        PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId()); if(!d.sectId().isBlank()) return false;
        String id=UUID.randomUUID().toString(); Sect s=new Sect(id,name,p.getUniqueId()); sects.put(id,s); d.sectId(id); save();
        p.getInventory().addItem(createSectCoreItem());
        p.sendMessage("§6✦ Tông Môn Core §fđã được trao cho bạn. §7Đặt Core để tạo Lãnh Địa Tông Môn.");
        return true;
    }
    public boolean join(Player p,String name){
        PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId()); if(!d.sectId().isBlank()) return false;
        Sect s=getByName(name); if(s==null)return false; s.members().put(p.getUniqueId(),SectRank.NGOAI_MON); d.sectId(s.id()); save(); return true;
    }
    public boolean leave(Player p){ PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId()); if(d.sectId().isBlank())return false; Sect s=get(d.sectId()); if(s==null){d.sectId("");return false;} if(s.owner().equals(p.getUniqueId()))return false; s.members().remove(p.getUniqueId()); d.sectId(""); save(); return true; }
    /** Tông Chủ giải tán tông môn; dọn claim/core và gỡ liên kết của mọi thành viên. */
    public boolean disband(Player p) {
        PlayerData data = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (data.sectId().isBlank()) { p.sendMessage("§cBạn chưa có Tông Môn."); return false; }
        Sect sect = get(data.sectId());
        if (sect == null || !sect.owner().equals(p.getUniqueId())) { p.sendMessage("§cChỉ Tông Chủ mới được giải tán Tông Môn."); return false; }
        for (UUID member : new ArrayList<>(sect.members().keySet())) {
            PlayerData md = plugin.getCultivationService().getPlayerData(member);
            md.sectId("");
            if (Bukkit.getPlayer(member) != null) Bukkit.getPlayer(member).sendMessage("§cTông Môn §f" + sect.name() + " §cđã bị giải tán.");
        }
        removeCoreBlock(sect.core(), Material.BEACON);
        removeCoreBlock(sect.libraryCore(), Material.ENCHANTING_TABLE);
        Location center = sect.core();
        if (center != null && center.getWorld() != null) {
            try {
                RegionManager rm = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(center.getWorld()));
                if (rm != null) { rm.removeRegion("tongmon_" + sect.id()); rm.save(); }
            } catch (Exception ex) { plugin.getLogger().warning("Không dọn được claim Tông Môn: " + ex.getMessage()); }
        }
        sects.remove(sect.id()); save();
        p.sendMessage("§c✦ Đã giải tán Tông Môn §f" + sect.name() + "§c.");
        return true;
    }
    private void removeCoreBlock(Location location, Material expected) {
        if (location == null || location.getWorld() == null) return;
        Block block = location.getBlock();
        if (block.getType() == expected) block.setType(Material.AIR);
    }

    public boolean contribute(Player p,int amount){ if(amount<=0)return false; PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId()); if(d.sectId().isBlank())return false; Sect s=get(d.sectId()); if(s==null)return false; if(!plugin.getEconomyService().withdraw(p,amount))return false; s.addStorage(amount); s.contributions().merge(p.getUniqueId(),amount,Integer::sum); d.addSectContribution(amount); save(); return true; }
    public String getNameFor(java.util.UUID uuid){ PlayerData d=plugin.getCultivationService().getPlayerData(uuid); if(d.sectId().isBlank()) return "Chưa gia nhập"; Sect s=get(d.sectId()); return s==null?"Chưa gia nhập":s.name(); }
    public String info(Player p){ PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId()); if(d.sectId().isBlank())return "§7Bạn chưa gia nhập tông môn."; Sect s=get(d.sectId()); if(s==null)return "§cTông môn dữ liệu lỗi."; SectRank r=s.members().getOrDefault(p.getUniqueId(),SectRank.NGOAI_MON); return "§6§l"+s.name()+" §7| Core: §f"+(s.hasCore()?"Đã đặt":"Chưa đặt")+" §7| Tàng Kinh Các: §f"+(s.hasLibraryCore()?"Đã đặt":"Chưa đặt")+" §7| Cấp bậc: §f"+r.displayName()+" §7| Thành viên: §f"+s.members().size()+" §7| Kho: §e"+String.format("%.0f",s.storage()); }
    public boolean setRank(OfflinePlayer target, String rank){ if(target==null)return false; PlayerData d=plugin.getCultivationService().getPlayerData(target.getUniqueId()); if(d.sectId().isBlank())return false; Sect s=get(d.sectId()); if(s==null)return false; s.members().put(target.getUniqueId(),SectRank.byName(rank)); save(); return true; }
    public boolean hasSchematic() { return new File(plugin.getDataFolder(), "tongmon/tongmon.schematic").isFile(); }

    public ItemStack createSectCoreItem() {
        ItemStack item = new ItemStack(Material.BEACON);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§6§lTông Môn Core");
            meta.setLore(List.of("§7Core trung tâm của Tông Môn", "§eĐặt xuống để tạo Lãnh Địa Tông Môn."));
            meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "sect_core"), PersistentDataType.BYTE, (byte) 1);
            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean isSectCoreItem(ItemStack item) {
        if (item == null || item.getType() != Material.BEACON || item.getItemMeta() == null) return false;
        return item.getItemMeta().getPersistentDataContainer().has(new NamespacedKey(plugin, "sect_core"), PersistentDataType.BYTE);
    }

    public boolean placeSectCore(Player p, Block block) {
        if (block == null || block.getType() != Material.BEACON) return false;
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (d.sectId().isBlank()) { p.sendMessage("§cBạn chưa có Tông Môn."); return false; }
        Sect s = get(d.sectId());
        if (s == null || !s.owner().equals(p.getUniqueId())) { p.sendMessage("§cChỉ Tông Chủ mới đặt Tông Môn Core."); return false; }
        if (s.hasCore()) { p.sendMessage("§cTông Môn đã có Core."); return false; }
        s.core(block.getLocation().add(0.5, 0, 0.5));
        if (!createSectClaim(s, block.getLocation())) {
            s.clearCore();
            p.sendMessage("§cKhông thể tạo Lãnh Địa Tông Môn. Kiểm tra WorldGuard hoặc khu vực bị trùng.");
            return false;
        }
        save();
        p.sendMessage("§6✦ §lTÔNG MÔN CORE §fđã kích hoạt!");
        p.sendMessage("§b✦ Phi Không §fchỉ có thể sử dụng bên trong Lãnh Địa Tông Môn.");
        return true;
    }

    public boolean isInOwnSectClaim(Player p) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (d.sectId().isBlank()) return false;
        return isInsideClaim(d.sectId(), p.getLocation());
    }

    private boolean isInsideClaim(String sectId, Location loc) {
        if (loc == null || loc.getWorld() == null) return false;
        RegionManager rm = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(loc.getWorld()));
        if (rm == null) return false;
        var region = rm.getRegion("tongmon_" + sectId);
        return region != null && region.contains(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
    }

    private boolean createSectClaim(Sect s, Location center) {
        if (center == null || center.getWorld() == null) return false;
        try {
            RegionManager rm = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(center.getWorld()));
            if (rm == null) return false;
            String id = "tongmon_" + s.id();
            if (rm.hasRegion(id)) return false;
            int radius = Math.max(8, plugin.getConfig().getInt("sect.claim-radius", 32));
            BlockVector3 min = BlockVector3.at(center.getBlockX() - radius, center.getWorld().getMinHeight(), center.getBlockZ() - radius);
            BlockVector3 max = BlockVector3.at(center.getBlockX() + radius, center.getWorld().getMaxHeight() - 1, center.getBlockZ() + radius);
            ProtectedCuboidRegion region = new ProtectedCuboidRegion(id, min, max);
            rm.addRegion(region);
            rm.save();
            return true;
        } catch (Exception ex) {
            plugin.getLogger().warning("Khong tao duoc claim Tong Mon: " + ex.getMessage());
            return false;
        }
    }

    public ItemStack createLibraryCoreItem() {
        ItemStack item = new ItemStack(Material.ENCHANTING_TABLE);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§5§lTàng Kinh Các Core");
            meta.setLore(List.of("§7Core riêng của Tông Môn", "§eĐặt xuống để đăng ký Tàng Kinh Các Core."));
            meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "sect_library_core"), PersistentDataType.BYTE, (byte) 1);
            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean isLibraryCoreItem(ItemStack item) {
        if (item == null || item.getType() != Material.ENCHANTING_TABLE || item.getItemMeta() == null) return false;
        return item.getItemMeta().getPersistentDataContainer().has(new NamespacedKey(plugin, "sect_library_core"), PersistentDataType.BYTE);
    }

    public boolean createLibraryCore(Player p, Block block) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (d.sectId().isBlank()) { p.sendMessage("§cBạn chưa gia nhập Tông Môn."); return false; }
        Sect s = get(d.sectId());
        if (s == null || !s.owner().equals(p.getUniqueId())) { p.sendMessage("§cChỉ Tông Chủ mới đặt Tàng Kinh Các Core."); return false; }
        s.libraryCore(block.getLocation().add(0.5, 0, 0.5));
        save();
        p.sendMessage("§5✦ Đã đặt §fTàng Kinh Các Core§5 cho Tông Môn.");
        return true;
    }

    public boolean isLibraryCore(Block b) {
        if (b == null) return false;
        for (Sect s : sects.values()) {
            Location l = s.libraryCore();
            if (l != null && l.getWorld().equals(b.getWorld()) && l.getBlockX() == b.getX() && l.getBlockY() == b.getY() && l.getBlockZ() == b.getZ()) return true;
        }
        return false;
    }

    public boolean createFromBeacon(Player p, Block beacon) {
        if (beacon == null || beacon.getType() != Material.BEACON) return false;
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (!d.sectId().isBlank()) { p.sendMessage("§cBạn đã thuộc một tông môn."); return false; }
        if (!hasSchematic()) { p.sendMessage("§cChưa có file schematic, vui lòng liên hệ Discord admin: qhuy963906"); return false; }
        String name = p.getName() + " Tong Mon";
        if (getByName(name) != null) return false;
        String id = UUID.randomUUID().toString(); Sect s = new Sect(id, name, p.getUniqueId()); s.core(beacon.getLocation().add(0.5, 0, 0.5));
        sects.put(id, s); d.sectId(id);
        if (!pasteSchematic(beacon.getLocation())) { sects.remove(id); d.sectId(""); p.sendMessage("§cDán schematic thất bại, không thể tạo tông môn."); return false; }
        save(); p.sendMessage("§6§l✦ TÔNG MÔN KHAI LẬP ✦ §f" + name); p.sendMessage("§7Đặt Beacon để làm Tâm Tiên Truyền Tông."); return true;
    }

    private boolean pasteSchematic(Location loc) {
        File f = new File(plugin.getDataFolder(), "tongmon/tongmon.schematic");
        try {
            ClipboardFormat format = ClipboardFormats.findByFile(f); if (format == null) return false;
            Clipboard clipboard; try (ClipboardReader reader = format.getReader(new FileInputStream(f))) { clipboard = reader.read(); }
            var weWorld = BukkitAdapter.adapt(loc.getWorld());
            try (EditSession edit = WorldEdit.getInstance().newEditSession(weWorld)) {
                Operation op = new ClipboardHolder(clipboard).createPaste(edit).to(BlockVector3.at(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ())).ignoreAirBlocks(false).build();
                Operations.complete(op);
            }
            return true;
        } catch (Exception ex) { plugin.getLogger().warning("Paste tongmon.schematic loi: " + ex.getMessage()); return false; }
    }

    public boolean isCore(Block b) { if(b==null) return false; for(Sect s:sects.values()){ Location l=s.core(); if(l!=null && l.getWorld().equals(b.getWorld()) && l.getBlockX()==b.getX() && l.getBlockY()==b.getY() && l.getBlockZ()==b.getZ()) return true; } return false; }
    public boolean teleportHome(Player p) { PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId()); Sect s=get(d.sectId()); if(s==null||s.core()==null)return false; Location l=s.core().clone().add(0,1,0); p.teleport(l); return true; }

    private void load(){ if(!file.exists())return; YamlConfiguration y=YamlConfiguration.loadConfiguration(file); for(String id:y.getStringList("ids")){ String path="sects."+id; String name=y.getString(path+".name",id); UUID owner=UUID.fromString(y.getString(path+".owner")); Sect s=new Sect(id,name,owner); s.storage(y.getDouble(path+".storage",0)); for(String u:y.getStringList(path+".members")){UUID uuid=UUID.fromString(u); s.members().put(uuid,SectRank.byName(y.getString(path+".ranks."+u,"NGOAI_MON"))); s.contributions().put(uuid,y.getInt(path+".contributions."+u,0));} if(y.contains(path+".core.world")){ org.bukkit.World w=org.bukkit.Bukkit.getWorld(y.getString(path+".core.world","")); if(w!=null) s.core(new Location(w,y.getDouble(path+".core.x"),y.getDouble(path+".core.y"),y.getDouble(path+".core.z"))); } if(y.contains(path+".library-core.world")){ org.bukkit.World w=org.bukkit.Bukkit.getWorld(y.getString(path+".library-core.world","")); if(w!=null) s.libraryCore(new Location(w,y.getDouble(path+".library-core.x"),y.getDouble(path+".library-core.y"),y.getDouble(path+".library-core.z"))); } sects.put(id,s); } }
    public void save(){ YamlConfiguration y=new YamlConfiguration(); List<String> ids=new ArrayList<>(sects.keySet()); y.set("ids",ids); for(Sect s:sects.values()){String p="sects."+s.id(); y.set(p+".name",s.name()); y.set(p+".owner",s.owner().toString()); y.set(p+".storage",s.storage()); if(s.hasCore()){ Location c=s.core(); y.set(p+".core.world",c.getWorld().getName()); y.set(p+".core.x",c.getX()); y.set(p+".core.y",c.getY()); y.set(p+".core.z",c.getZ()); } if(s.hasLibraryCore()){ Location c=s.libraryCore(); y.set(p+".library-core.world",c.getWorld().getName()); y.set(p+".library-core.x",c.getX()); y.set(p+".library-core.y",c.getY()); y.set(p+".library-core.z",c.getZ()); } List<String> members=new ArrayList<>(); for(var e:s.members().entrySet()){members.add(e.getKey().toString()); y.set(p+".ranks."+e.getKey(),e.getValue().name()); y.set(p+".contributions."+e.getKey(),s.contributions().getOrDefault(e.getKey(),0));} y.set(p+".members",members);} try{y.save(file);}catch(IOException e){plugin.getLogger().warning("Không lưu được sects.yml: "+e.getMessage());} }
}
