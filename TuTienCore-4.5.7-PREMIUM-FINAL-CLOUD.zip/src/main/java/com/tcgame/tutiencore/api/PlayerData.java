package com.tcgame.tutiencore.api;

import com.tcgame.tutiencore.cultivation.Realm;
import com.tcgame.tutiencore.spiritroot.SpiritRootQuality;
import com.tcgame.tutiencore.spiritroot.SpiritRootType;

import java.util.UUID;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.LinkedHashSet;

/** Persistent player-side cultivation data. Vanilla XP is never used. */
public final class PlayerData {
    private final UUID uuid;
    private Realm realm = Realm.PHAM_NHAN;
    private int realmStage = 1;
    private double linhKhi = 0D;
    private SpiritRootType spiritRoot = SpiritRootType.NGU_HANH;
    private SpiritRootQuality spiritRootQuality = SpiritRootQuality.NGUY_LINH_CAN;
    private final List<SpiritRootType> spiritRoots = new ArrayList<>(List.of(SpiritRootType.KIM, SpiritRootType.MOC, SpiritRootType.THUY, SpiritRootType.HOA, SpiritRootType.THO));
    private double canCot = 1D;
    private double ngoTinh = 1D;
    private int techniqueLevel = 0;
    private long techniqueExp = 0L;
    private int techniqueTalent = 0;
    private String techniqueId = "";
    private final Set<String> swordSkills = new LinkedHashSet<>();
    private final Map<String, Integer> swordSkillLevels = new LinkedHashMap<>();
    private String cultivationClass = "KIEM_TU";
    private final Map<String, Integer> classSkillLevels = new LinkedHashMap<>();
    private int tamPhapLevel = 0;
    private String sectId = "";
    private int sectContribution = 0;
    private String petName = "";
    private int petLevel = 1;
    private final List<String> ownedPets = new ArrayList<>();
    private String activePetId = "";
    private String flightSkin = "WOODEN";
    private final Set<String> ownedFlightSkins = new LinkedHashSet<>(Set.of("WOODEN"));
    private long petExp = 0L;
    private String artifactQuality = "PHAM";
    private int artifactLevel = 0;
    private double alchemyMultiplier = 1D;
    private long alchemyBuffUntil = 0L;
    private long dailyTrainingSeconds = 0L;
    private long weeklyTrainingSeconds = 0L;
    private long dailyProgressDay = -1L;
    private long weeklyProgressKey = -1L;
    private long dailyQuestClaim = 0L;
    private long weeklyQuestClaim = 0L;
    private long trainingSessionStarted = 0L;

    // Progression additions
    private int rankLevel = 1;
    private boolean luyenKhi1Unlocked = false;
    private boolean finalTribulationPassed = false;
    private int linhThao = 0;
    private int linhThach = 0;
    private boolean autoCatLinhThach = false;
    private int tribulationCount = 0;
    private int spiritRootRolls = 0;
    private int breakthroughCount = 0;
    private long congDuc = 0L;
    private long nghiepLuc = 0L;
    private long thanLucLuanHoi = 0L;
    private int luanHoiCount = 0;
    private double hiddenDamagePercent = 0D;
    private double hiddenCooldownReductionPercent = 0D;
    private final Set<String> stolenSkills = new LinkedHashSet<>();
    // HyperVN 3.0.0: ultimate meter + cosmetic ownership + catch-up lifecycle.
    private double thanThuc = 0D;
    private long catchupStartedAt = 0L;
    private final Set<String> ownedCosmetics = new LinkedHashSet<>();
    private String activeCosmetic = "";

    public PlayerData(UUID uuid) { this.uuid = uuid; }

    public UUID uuid() { return uuid; }
    public Realm realm() { return realm; }
    public void realm(Realm value) { this.realm = value == null ? Realm.PHAM_NHAN : value; clampStageOnly(); }

    public int realmStage() { return realmStage; }
    public void realmStage(int value) { realmStage = Math.max(1, Math.min(realm.maxStage(), value)); }
    public int cultivationLevel() { return realm.levelForStage(realmStage); }
    public String realmDisplay() {
        if (realm == Realm.PHAM_NHAN) return realm.displayName();
        if (realm.maxStage() == 1) return realm.displayName();
        return realm.displayName() + " Tầng " + realmStage;
    }

    public long maxLinhKhi() { return nextLinhKhiStageThreshold(); }
    public double progress() { return maxLinhKhi() <= 0 ? 1D : Math.min(1D, linhKhi / (double) maxLinhKhi()); }

    public double linhKhi() { return linhKhi; }
    public void linhKhi(double value) { linhKhi = Math.max(0D, value); }
    public void addLinhKhi(double amount) { linhKhi(this.linhKhi + Math.max(0D, amount)); }

    public SpiritRootType spiritRoot() { return spiritRoot; }
    public void spiritRoot(SpiritRootType value) { if (value != null) spiritRoot = value; }
    public SpiritRootQuality spiritRootQuality() { return spiritRootQuality; }
    public void spiritRootQuality(SpiritRootQuality value) { if (value != null) spiritRootQuality = value; }

    public List<SpiritRootType> spiritRoots() { return Collections.unmodifiableList(spiritRoots); }
    public void spiritRoots(List<SpiritRootType> values) {
        spiritRoots.clear();
        if (values != null) for (SpiritRootType value : values) {
            if (value != null && value != SpiritRootType.NGU_HANH && value != SpiritRootType.BIEN_DI && !spiritRoots.contains(value)) spiritRoots.add(value);
        }
    }
    public String spiritRootDisplay() {
        if (spiritRootQuality == SpiritRootQuality.BIEN_DI) return "Biến Dị §7(0 linh căn) §8x64";
        String roots = spiritRoots.stream().map(SpiritRootType::displayName).reduce((a,b) -> a + ", " + b).orElse("Không có");
        return spiritRootQuality.displayName() + " §7(" + roots + "§7) §8x" + trimMultiplier(spiritRootQuality.trainingMultiplier());
    }
    private static String trimMultiplier(double value) {
        return Math.rint(value) == value ? Long.toString((long)value) : String.format(java.util.Locale.ROOT, "%.2f", value);
    }

    public double canCot() { return canCot; }
    public void canCot(double value) { canCot = Math.max(1D, Math.min(100D, value)); }
    public double ngoTinh() { return ngoTinh; }
    public void ngoTinh(double value) { ngoTinh = Math.max(1D, Math.min(100D, value)); }

    public int techniqueLevel() { return techniqueLevel; }
    public void techniqueLevel(int value) { techniqueLevel = Math.max(0, value); }
    public long techniqueExp() { return techniqueExp; }
    public void techniqueExp(long value) { techniqueExp = Math.max(0, value); }
    public void addTechniqueExp(long amount) { techniqueExp(Math.max(0, techniqueExp + amount)); }
    public String techniqueId() { return techniqueId; }
    public void techniqueId(String value) { techniqueId = value == null ? "" : value; }
    public Set<String> swordSkills() { return Collections.unmodifiableSet(swordSkills); }
    public void swordSkills(List<String> values) {
        swordSkills.clear();
        if (values != null) for (String value : values) if (value != null && !value.isBlank()) swordSkills.add(value.toLowerCase(java.util.Locale.ROOT));
    }
    public boolean hasSwordSkill(String id) { return id != null && swordSkills.contains(id.toLowerCase(java.util.Locale.ROOT)); }
    public void learnSwordSkill(String id) { if (id != null && !id.isBlank()) swordSkills.add(id.toLowerCase(java.util.Locale.ROOT)); }
    public int swordSkillLevel(String id) { return id == null ? 0 : swordSkillLevels.getOrDefault(id.toLowerCase(java.util.Locale.ROOT), 0); }
    public void swordSkillLevel(String id, int level) { if (id != null && !id.isBlank()) swordSkillLevels.put(id.toLowerCase(java.util.Locale.ROOT), Math.max(0, level)); }
    public Map<String, Integer> swordSkillLevels() { return Collections.unmodifiableMap(swordSkillLevels); }
    public void swordSkillLevels(Map<String, Integer> values) {
        swordSkillLevels.clear();
        if (values != null) values.forEach((k,v) -> { if (k != null && !k.isBlank()) swordSkillLevels.put(k.toLowerCase(java.util.Locale.ROOT), Math.max(0, v == null ? 0 : v)); });
    }

    public String cultivationClass() { return cultivationClass; }
    public void cultivationClass(String value) { if (value != null && !value.isBlank()) cultivationClass = value.toUpperCase(java.util.Locale.ROOT); }
    public int classSkillLevel(String id) { return id == null ? 0 : classSkillLevels.getOrDefault(id.toLowerCase(java.util.Locale.ROOT), 0); }
    public void classSkillLevel(String id, int level) { if (id != null && !id.isBlank()) classSkillLevels.put(id.toLowerCase(java.util.Locale.ROOT), Math.max(0, level)); }
    public Map<String,Integer> classSkillLevels() { return Collections.unmodifiableMap(classSkillLevels); }
    public void classSkillLevels(Map<String,Integer> values) { classSkillLevels.clear(); if (values != null) values.forEach((k,v) -> { if (k != null && !k.isBlank()) classSkillLevels.put(k.toLowerCase(java.util.Locale.ROOT), Math.max(0, v == null ? 0 : v)); }); }

    public int techniqueTalent() { return techniqueTalent; }
    public void techniqueTalent(int value) { techniqueTalent = Math.max(0, Math.min(100, value)); }

    public int tamPhapLevel() { return tamPhapLevel; }
    public void tamPhapLevel(int value) { tamPhapLevel = Math.max(0, value); }

    public String sectId() { return sectId; }
    public void sectId(String value) { sectId = value == null ? "" : value; }
    public int sectContribution() { return sectContribution; }
    public void sectContribution(int value) { sectContribution = Math.max(0, value); }
    public void addSectContribution(int amount) { sectContribution(Math.max(0, sectContribution + amount)); }

    public String petName() { return petName; }
    public void petName(String value) { petName = value == null ? "" : value; }
    public List<String> ownedPets() { return Collections.unmodifiableList(ownedPets); }
    public void ownedPets(List<String> values) {
        ownedPets.clear();
        if (values != null) for (String value : values) if (value != null && !value.isBlank() && !ownedPets.contains(value)) ownedPets.add(value);
    }
    public boolean ownsPet(String id) { return id != null && ownedPets.contains(id); }
    public void addOwnedPet(String id) { if (id != null && !id.isBlank() && !ownedPets.contains(id)) ownedPets.add(id); }
    public String activePetId() { return activePetId; }
    public void activePetId(String value) { activePetId = value == null ? "" : value; }
    public String flightSkin() { return flightSkin; }
    public void flightSkin(String value) { flightSkin = value == null || value.isBlank() ? "WOODEN" : value.toUpperCase(java.util.Locale.ROOT); }
    public Set<String> ownedFlightSkins() { return Collections.unmodifiableSet(ownedFlightSkins); }
    public void ownedFlightSkins(List<String> values) { ownedFlightSkins.clear(); ownedFlightSkins.add("WOODEN"); if (values != null) for (String v : values) if (v != null && !v.isBlank()) ownedFlightSkins.add(v.toUpperCase(java.util.Locale.ROOT)); }
    public boolean ownsFlightSkin(String id) { return id != null && ownedFlightSkins.contains(id.toUpperCase(java.util.Locale.ROOT)); }
    public void addOwnedFlightSkin(String id) { if (id != null && !id.isBlank()) ownedFlightSkins.add(id.toUpperCase(java.util.Locale.ROOT)); }

    public int petLevel() { return petLevel; }
    public void petLevel(int value) { petLevel = Math.max(1, Math.min(100, value)); }
    public long petExp() { return petExp; }
    public void petExp(long value) { petExp = Math.max(0, value); }
    public void addPetExp(long amount) { petExp(Math.max(0, petExp + amount)); }

    public String artifactQuality() { return artifactQuality; }
    public void artifactQuality(String value) { artifactQuality = value == null ? "PHAM" : value; }
    public int artifactLevel() { return artifactLevel; }
    public void artifactLevel(int value) { artifactLevel = Math.max(0, Math.min(100, value)); }

    public double alchemyMultiplier() { return alchemyMultiplier; }
    public void alchemyMultiplier(double value) { alchemyMultiplier = Math.max(1D, value); }
    public long alchemyBuffUntil() { return alchemyBuffUntil; }
    public void alchemyBuffUntil(long value) { alchemyBuffUntil = Math.max(0L, value); }
    public boolean hasAlchemyBuff() { return alchemyBuffUntil > System.currentTimeMillis() && alchemyMultiplier > 1D; }

    public long dailyTrainingSeconds() { return dailyTrainingSeconds; }
    public void dailyTrainingSeconds(long v) { dailyTrainingSeconds = Math.max(0, v); }
    public long weeklyTrainingSeconds() { return weeklyTrainingSeconds; }
    public void weeklyTrainingSeconds(long v) { weeklyTrainingSeconds = Math.max(0, v); }
    public long dailyProgressDay() { return dailyProgressDay; }
    public void dailyProgressDay(long v) { dailyProgressDay = v; }
    public long weeklyProgressKey() { return weeklyProgressKey; }
    public void weeklyProgressKey(long v) { weeklyProgressKey = v; }
    public long dailyQuestClaim() { return dailyQuestClaim; }
    public void dailyQuestClaim(long v) { dailyQuestClaim = Math.max(0, v); }
    public long weeklyQuestClaim() { return weeklyQuestClaim; }
    public void weeklyQuestClaim(long v) { weeklyQuestClaim = Math.max(0, v); }
    public long trainingSessionStarted() { return trainingSessionStarted; }
    public void trainingSessionStarted(long v) { trainingSessionStarted = Math.max(0, v); }

    public int rankLevel() { return rankLevel; }
    public void rankLevel(int value) { rankLevel = Math.max(1, Math.min(30, value)); }

    public boolean luyenKhi1Unlocked() { return luyenKhi1Unlocked; }
    public void luyenKhi1Unlocked(boolean value) { luyenKhi1Unlocked = value; }

    public boolean finalTribulationPassed() { return finalTribulationPassed; }
    public void finalTribulationPassed(boolean value) { finalTribulationPassed = value; }

    public int linhThao() { return linhThao; }
    public void linhThao(int value) { linhThao = Math.max(0, value); }
    public void addLinhThao(int amount) { linhThao(Math.max(0, linhThao + amount)); }

    public int linhThach() { return linhThach; }
    public void linhThach(int value) { linhThach = Math.max(0, value); }
    public void addLinhThach(int amount) { linhThach(Math.max(0, linhThach + amount)); }
    public boolean takeLinhThao(int amount) { if (amount <= 0 || linhThao < amount) return false; linhThao -= amount; return true; }
    public boolean takeLinhThach(int amount) { if (amount <= 0 || linhThach < amount) return false; linhThach -= amount; return true; }
    public boolean autoCatLinhThach() { return autoCatLinhThach; }
    public void autoCatLinhThach(boolean value) { autoCatLinhThach = value; }

    /** Number of /dotpha attempts started; each attempt raises the next tribulation difficulty. */
    public int tribulationCount() { return tribulationCount; }
    public void tribulationCount(int value) { tribulationCount = Math.max(0, value); }
    public int incrementTribulationCount() { tribulationCount++; return tribulationCount; }

    public int spiritRootRolls() { return spiritRootRolls; }
    public void spiritRootRolls(int value) { spiritRootRolls = Math.max(0, value); }
    public void addSpiritRootRolls(int amount) { spiritRootRolls(Math.max(0, spiritRootRolls + amount)); }
    public boolean takeSpiritRootRoll() { if (spiritRootRolls <= 0) return false; spiritRootRolls--; return true; }

    public int breakthroughCount() { return breakthroughCount; }
    public void breakthroughCount(int value) { breakthroughCount = Math.max(0, value); }
    public int incrementBreakthroughCount() { breakthroughCount++; return breakthroughCount; }
    public long congDuc() { return congDuc; }
    public void congDuc(long v) { congDuc=Math.max(0L,v); }
    public void addCongDuc(long v) { congDuc(Math.max(0L,congDuc+v)); }
    public long nghiepLuc() { return nghiepLuc; }
    public void nghiepLuc(long v) { nghiepLuc=Math.max(0L,v); }
    public void addNghiepLuc(long v) { nghiepLuc(Math.max(0L,nghiepLuc+v)); }
    public long thanLucLuanHoi() { return thanLucLuanHoi; }
    public void thanLucLuanHoi(long v) { thanLucLuanHoi=Math.max(0L,v); }
    public void addThanLucLuanHoi(long v) { thanLucLuanHoi(Math.max(0L,thanLucLuanHoi+v)); }
    public int luanHoiCount() { return luanHoiCount; }
    public void luanHoiCount(int v) { luanHoiCount=Math.max(0,v); }
    public int incrementLuanHoiCount() { return ++luanHoiCount; }
    public double hiddenDamagePercent() { return hiddenDamagePercent; }
    public void hiddenDamagePercent(double v) { hiddenDamagePercent=Math.max(0D,Math.min(100D,v)); }
    public double hiddenCooldownReductionPercent() { return hiddenCooldownReductionPercent; }
    public void hiddenCooldownReductionPercent(double v) { hiddenCooldownReductionPercent=Math.max(0D,Math.min(80D,v)); }

    public double thanThuc() { return thanThuc; }
    public void thanThuc(double value) { thanThuc = Math.max(0D, Math.min(100D, value)); }
    public void addThanThuc(double value) { thanThuc(Math.min(100D, thanThuc + Math.max(0D, value))); }
    public long catchupStartedAt() { return catchupStartedAt; }
    public void catchupStartedAt(long value) { catchupStartedAt = Math.max(0L, value); }
    public Set<String> ownedCosmetics() { return Collections.unmodifiableSet(ownedCosmetics); }
    public void ownedCosmetics(List<String> values) { ownedCosmetics.clear(); if (values != null) for (String v : values) if (v != null && !v.isBlank()) ownedCosmetics.add(v.toUpperCase(java.util.Locale.ROOT)); }
    public boolean ownsCosmetic(String id) { return id != null && ownedCosmetics.contains(id.toUpperCase(java.util.Locale.ROOT)); }
    public void addCosmetic(String id) { if (id != null && !id.isBlank()) ownedCosmetics.add(id.toUpperCase(java.util.Locale.ROOT)); }
    public String activeCosmetic() { return activeCosmetic; }
    public void activeCosmetic(String value) { activeCosmetic = value == null ? "" : value.toUpperCase(java.util.Locale.ROOT); }

    public Set<String> stolenSkills() { return Collections.unmodifiableSet(stolenSkills); }
    public void stolenSkills(List<String> values) { stolenSkills.clear(); if(values!=null) for(String v:values) if(v!=null&&!v.isBlank()) stolenSkills.add(v.toLowerCase(java.util.Locale.ROOT)); }
    public boolean hasStolenSkill(String id) { return id!=null && stolenSkills.contains(id.toLowerCase(java.util.Locale.ROOT)); }
    public void addStolenSkill(String id) { if(id!=null&&!id.isBlank()) stolenSkills.add(id.toLowerCase(java.util.Locale.ROOT)); }



    public long nextLinhKhiStageThreshold() {
        if (realm == Realm.PHAM_NHAN) return 0L;
        return 1000L + ((long) Math.max(0, realmStage - 1) * 700L);
    }

    private void clampStageOnly() { realmStage = Math.max(1, Math.min(realm.maxStage(), realmStage)); }
}
