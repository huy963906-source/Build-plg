package com.tcgame.tutiencore.api;

import com.tcgame.tutiencore.cultivation.Realm;
import java.util.UUID;

/** Public bridge registered through Bukkit ServicesManager. */
public final class CultivationAPI {
    private final CultivationService service;
    public CultivationAPI(CultivationService service) { this.service = service; }
    public PlayerData getPlayerData(UUID uuid) { return service.getPlayerData(uuid); }
    public void addLinhKhi(UUID uuid, double amount) { service.addLinhKhi(uuid, amount); }
    public void setLinhKhi(UUID uuid, double amount) { service.setLinhKhi(uuid, amount); }
    public void setRealm(UUID uuid, Realm realm) { service.setRealm(uuid, realm); }
    public int getRealmStage(UUID uuid) { return getPlayerData(uuid).realmStage(); }
    public long getMaxLinhKhi(UUID uuid) { return getPlayerData(uuid).maxLinhKhi(); }
    public int getRankLevel(UUID uuid) { return getPlayerData(uuid).rankLevel(); }
    public CultivationService service() { return service; }
}
