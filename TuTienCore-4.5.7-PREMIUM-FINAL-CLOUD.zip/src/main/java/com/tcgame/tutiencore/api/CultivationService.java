package com.tcgame.tutiencore.api;

import com.tcgame.tutiencore.cultivation.Realm;
import com.tcgame.tutiencore.spiritroot.SpiritRootQuality;
import com.tcgame.tutiencore.spiritroot.SpiritRootType;
import java.util.UUID;

public interface CultivationService {
    PlayerData getPlayerData(UUID uuid);
    void addLinhKhi(UUID uuid, double amount);
    void setLinhKhi(UUID uuid, double amount);
    void setRealm(UUID uuid, Realm realm);
    void setSpiritRoot(UUID uuid, SpiritRootType type, SpiritRootQuality quality);
    void save(UUID uuid);
    void saveAll();
}
