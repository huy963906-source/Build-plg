package com.tcgame.tutiencore.pet;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.AbstractHorse;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.math.BigInteger;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Linh Thú shop + persistent ownership + real rideable Bukkit entities.
 * Pet purchases use the Linh Thạch bank. Active pets are mounted directly by the owner.
 */
public final class PetSystem implements Listener {
    private final TuTienCore plugin;
    private final NamespacedKey petIdKey;
    private final Map<UUID, UUID> activeEntities = new ConcurrentHashMap<>();
    private static final String MENU_TITLE = "§b§lLinh Thú • Linh Giới";

    public PetSystem(TuTienCore plugin) {
        this.plugin = plugin;
        this.petIdKey = new NamespacedKey(plugin, "pet_id");
    }

    public void openMenu(Player p) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        org.bukkit.inventory.Inventory inv = Bukkit.createInventory(null, 54, MENU_TITLE);
        ItemStack header = new ItemStack(Material.NETHER_STAR);
        ItemMeta hm = header.getItemMeta(); if (hm != null) { hm.setDisplayName("§b§l✦ LINH THÚ CỦA ĐẠO HỮU ✦"); hm.setLore(List.of("§7Linh Thạch: §e" + plugin.getLinhThachBankService().balance(p.getUniqueId()), "§7Click Linh Thú để mua hoặc triệu hồi.")); header.setItemMeta(hm); }
        inv.setItem(4, header);
        int slot = 10;
        for (String id : petIds()) {
            if (slot >= 44) break;
            inv.setItem(slot, shopItem(id, d)); slot++;
            if (slot % 9 == 8) slot += 2;
        }
        ItemStack close = new ItemStack(Material.BARRIER); ItemMeta cm=close.getItemMeta(); if(cm!=null){cm.setDisplayName("§cĐóng");close.setItemMeta(cm);} inv.setItem(49,close);
        p.openInventory(inv);
    }

    @EventHandler public void onPetMenuClick(InventoryClickEvent e) {
        if (!MENU_TITLE.equals(e.getView().getTitle())) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        int slot=e.getRawSlot(); if(slot<0 || slot>=e.getView().getTopInventory().getSize() || slot==4) return;
        if(slot==49){p.closeInventory();return;}
        ItemStack clicked=e.getCurrentItem(); if(clicked==null || !clicked.hasItemMeta()) return;
        String id=null;
        for(String candidate:petIds()) if(ChatColor.stripColor(petName(candidate)).equals(ChatColor.stripColor(clicked.getItemMeta().getDisplayName()))) { id=candidate; break; }
        if(id==null)return;
        PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if(!d.ownsPet(id)) buy(p,id); else toggleRide(p,id);
        openMenu(p);
    }

    public double cultivationMultiplier(PlayerData d){return d.petName().isBlank()?1D:1D+d.petLevel()*0.01D;}
    public void addXp(PlayerData d,long amount){d.addPetExp(amount);while(d.petLevel()<100){long need=100L+(d.petLevel()-1L)*100L;if(d.petExp()<need)break;d.petExp(d.petExp()-need);d.petLevel(d.petLevel()+1);}}

    /** Legacy summon command: summon the configured default pet if possible. */
    public void summon(PlayerData d,String name){d.petName(name==null||name.isBlank()?"Linh Thú":name);}
    public void dismiss(PlayerData d){d.petName(""); d.activePetId("");}

    public List<String> petIds() {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("pets.shop");
        if (sec == null) return List.of();
        return new ArrayList<>(sec.getKeys(false));
    }

    public String petName(String id) { return ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("pets.shop." + id + ".name", id)); }
    public String petEntity(String id) { return plugin.getConfig().getString("pets.shop." + id + ".entity", "HORSE"); }
    public long petPrice(String id) { return Math.max(0L, plugin.getConfig().getLong("pets.shop." + id + ".price", 0L)); }
    public Material petIcon(String id) {
        Material m = Material.matchMaterial(plugin.getConfig().getString("pets.shop." + id + ".icon", "HORSE_SPAWN_EGG"));
        return m == null ? Material.HORSE_SPAWN_EGG : m;
    }
    public List<String> petLore(String id) { return plugin.getConfig().getStringList("pets.shop." + id + ".lore").stream().map(x -> ChatColor.translateAlternateColorCodes('&', x)).toList(); }

    public boolean buy(Player p, String id) {
        if (!petIds().contains(id)) return false;
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (d.ownsPet(id)) { p.sendMessage("§eBạn đã sở hữu §f" + petName(id) + "§e."); return false; }
        long price = petPrice(id);
        BigInteger cost = BigInteger.valueOf(price);
        if (plugin.getLinhThachBankService().balance(p.getUniqueId()).compareTo(cost) < 0) {
            p.sendMessage("§cKhông đủ Linh Thạch. §7Cần §e" + price + " §7| Có §e" + plugin.getLinhThachBankService().balance(p.getUniqueId()));
            return false;
        }
        if (!plugin.getLinhThachBankService().withdraw(p.getUniqueId(), cost)) {
            p.sendMessage("§cTrừ Linh Thạch thất bại.");
            return false;
        }
        d.addOwnedPet(id);
        plugin.getCultivationService().save(p.getUniqueId());
        plugin.getLinhThachBankService().save();
        p.sendMessage("§a✦ Đã mua Linh Thú §f" + petName(id) + " §avới giá §e" + price + " Linh Thạch§a.");
        return true;
    }

    public boolean toggleRide(Player p, String id) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (!d.ownsPet(id)) {
            p.sendMessage("§cBạn chưa sở hữu Linh Thú này.");
            return false;
        }
        UUID old = activeEntities.remove(p.getUniqueId());
        if (old != null) {
            Entity entity = Bukkit.getEntity(old);
            if (entity != null && entity.isValid()) entity.remove();
        }
        if (id.equals(d.activePetId())) {
            d.activePetId("");
            d.petName("");
            plugin.getCultivationService().save(p.getUniqueId());
            p.sendMessage("§7Đã thu hồi Linh Thú.");
            return true;
        }
        EntityType type;
        try { type = EntityType.valueOf(petEntity(id).toUpperCase(Locale.ROOT)); }
        catch (IllegalArgumentException ex) { p.sendMessage("§cEntity Linh Thú không hợp lệ: " + petEntity(id)); return false; }
        if (!type.isAlive() || !LivingEntity.class.isAssignableFrom(type.getEntityClass())) {
            p.sendMessage("§cLinh Thú này không thể triệu hồi.");
            return false;
        }
        Location loc = p.getLocation().clone().add(0, 0.15, 0);
        Entity spawned = p.getWorld().spawnEntity(loc, type);
        if (!(spawned instanceof LivingEntity pet)) { spawned.remove(); p.sendMessage("§cKhông thể tạo Linh Thú."); return false; }
        pet.setPersistent(true);
        pet.setInvulnerable(true);
        pet.setCollidable(false);
        pet.setCustomName(ChatColor.translateAlternateColorCodes('&', petName(id)));
        pet.setCustomNameVisible(true);
        pet.getPersistentDataContainer().set(petIdKey, PersistentDataType.STRING, id);
        if (pet instanceof Tameable tameable) {
            tameable.setTamed(true);
            tameable.setOwner(p);
        }
        if (pet instanceof AbstractHorse horse) {
            horse.setTamed(true);
            horse.setOwner(p);
            horse.setAdult();
        }
        // Player must ride the pet, not the reverse.
        pet.eject();
        pet.addPassenger(p);
        activeEntities.put(p.getUniqueId(), pet.getUniqueId());
        d.activePetId(id);
        d.petName(petName(id));
        plugin.getCultivationService().save(p.getUniqueId());
        p.sendMessage("§a✦ Đã cưỡi §f" + petName(id) + "§a.");
        return true;
    }

    public boolean owns(PlayerData d, String id) { return d.ownsPet(id); }
    public boolean isActive(PlayerData d, String id) { return id.equals(d.activePetId()); }

    public ItemStack shopItem(String id, PlayerData d) {
        ItemStack item = new ItemStack(petIcon(id));
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            boolean owned = d.ownsPet(id);
            boolean active = isActive(d, id);
            meta.setDisplayName((owned ? "§a" : "§6") + petName(id));
            List<String> lore = new ArrayList<>();
            lore.add("§7Loài: §f" + petEntity(id));
            lore.add("§7Giá: §e" + petPrice(id) + " Linh Thạch");
            lore.add(owned ? (active ? "§aĐang cưỡi" : "§eĐã sở hữu • Click để cưỡi") : "§eClick để mua");
            lore.addAll(petLore(id));
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    public void removeActive(Player p) {
        UUID id = activeEntities.remove(p.getUniqueId());
        if (id != null) {
            Entity e = Bukkit.getEntity(id);
            if (e != null && e.isValid()) e.remove();
        }
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        d.activePetId("");
        d.petName("");
    }

    @EventHandler public void onQuit(PlayerQuitEvent e) { removeActive(e.getPlayer()); }

    @EventHandler public void onPetDeath(EntityDeathEvent e) {
        String id = e.getEntity().getPersistentDataContainer().get(petIdKey, PersistentDataType.STRING);
        if (id == null) return;
        activeEntities.entrySet().removeIf(entry -> entry.getValue().equals(e.getEntity().getUniqueId()));
    }

    @EventHandler public void onPetInteract(PlayerInteractEntityEvent e) {
        String id = e.getRightClicked().getPersistentDataContainer().get(petIdKey, PersistentDataType.STRING);
        if (id == null) return;
        e.setCancelled(true);
        if (!e.getRightClicked().getWorld().equals(e.getPlayer().getWorld())) return;
        UUID owner = activeEntities.entrySet().stream().filter(x -> x.getValue().equals(e.getRightClicked().getUniqueId())).map(Map.Entry::getKey).findFirst().orElse(null);
        if (owner != null && owner.equals(e.getPlayer().getUniqueId())) e.getRightClicked().addPassenger(e.getPlayer());
    }
}
