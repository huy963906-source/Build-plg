package com.tcgame.tutiencore.license;

import com.tcgame.tutiencore.TuTienCore;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.configuration.file.FileConfiguration;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/** Local/offline license gate. This is not a substitute for a central license server. */
public final class LicenseManager implements CommandExecutor, TabCompleter {
    private static final String ADMIN_KEY = "TTCPLG-ZYAS-DEPTRAI";
    private static final List<String> INITIAL_KEYS = List.of(
            "TTCPLG-TAJS-YWIA",
            "TTCPLG-HAVB-SHJA",
            "TTCPLG-FBSN-SOKA",
            "TTCPLG-CHSN-FJEN",
            "TTCPLG-WIBS-GJDN",
            "TTCPLG-SCHJ-FJDJ"
    );
    private final TuTienCore plugin;

    public LicenseManager(TuTienCore plugin) { this.plugin = plugin; }

    public boolean isActivatedForThisServer() {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("license.activated", false)) return false;
        String stored = c.getString("license.server-fingerprint", "");
        return !stored.isBlank() && stored.equals(fingerprint());
    }

    public void registerCommand() {
        PluginCommand cmd = plugin.getCommand("ttlicense");
        if (cmd != null) { cmd.setExecutor(this); cmd.setTabCompleter(this); }
    }

    public void ensureDefaultKeyPool() {
        if (!plugin.getConfig().contains("license.available-keys")) {
            plugin.getConfig().set("license.available-keys", new ArrayList<>(INITIAL_KEYS));
            plugin.saveConfig();
        }
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("status")) {
            sender.sendMessage(ChatColor.GOLD + "TuTienCore Premium: " + (isActivatedForThisServer() ? ChatColor.GREEN + "ĐÃ KÍCH HOẠT" : ChatColor.RED + "CHƯA KÍCH HOẠT"));
            if (!isActivatedForThisServer()) sender.sendMessage(ChatColor.YELLOW + "Dùng /ttlicense activate <key> từ console rồi khởi động lại server.");
            return true;
        }
        if (args.length != 2 || !args[0].equalsIgnoreCase("activate")) {
            sender.sendMessage(ChatColor.YELLOW + "Dùng: /ttlicense activate <key> hoặc /ttlicense status");
            return true;
        }
        if (sender instanceof Player) {
            sender.sendMessage(ChatColor.RED + "Để bảo vệ key, hãy kích hoạt bằng console của server.");
            return true;
        }
        if (isActivatedForThisServer()) {
            sender.sendMessage(ChatColor.GREEN + "TuTienCore Premium đã được kích hoạt trên server này.");
            return true;
        }

        String key = args[1].trim().toUpperCase(Locale.ROOT);
        FileConfiguration c = plugin.getConfig();
        List<String> available = new ArrayList<>(c.getStringList("license.available-keys"));
        boolean admin = constantTimeEquals(key, ADMIN_KEY);
        boolean valid = admin || available.stream().anyMatch(k -> constantTimeEquals(k, key));
        if (!valid) {
            sender.sendMessage(ChatColor.RED + "Key không hợp lệ hoặc đã được sử dụng. Liên hệ zyas qua Discord: qhuy963906.");
            return true;
        }

        // Consume commercial key from this installation's local pool. Admin key is never consumed.
        if (!admin) {
            available.removeIf(k -> constantTimeEquals(k, key));
            c.set("license.available-keys", available);
        }
        c.set("license.activated", true);
        c.set("license.activated-key", key);
        c.set("license.server-fingerprint", fingerprint());
        c.set("license.activated-by", sender.getName());
        plugin.saveConfig();
        sender.sendMessage(ChatColor.GREEN + "Kích hoạt TuTienCore Premium thành công!");
        sender.sendMessage(ChatColor.YELLOW + "Hãy khởi động lại server để bật toàn bộ tính năng.");
        sender.sendMessage(ChatColor.GRAY + "Muốn reset/chuyển server: liên hệ zyas — Discord qhuy963906.");
        plugin.getLogger().info("Premium license activated on this installation (key hidden). Restart server to initialize features.");
        return true;
    }

    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return Arrays.asList("activate", "status").stream().filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        return Collections.emptyList();
    }

    private String fingerprint() {
        // Best-effort local server identity. Offline mode cannot guarantee global anti-copy protection.
        String identity = plugin.getServer().getIp() + ":" + plugin.getServer().getPort() + ":" + plugin.getServer().getName();
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(identity.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (byte b : digest) out.append(String.format("%02x", b));
            return out.toString();
        } catch (Exception e) { return identity; }
    }

    private static boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null) return false;
        return MessageDigest.isEqual(a.getBytes(StandardCharsets.UTF_8), b.getBytes(StandardCharsets.UTF_8));
    }
}
