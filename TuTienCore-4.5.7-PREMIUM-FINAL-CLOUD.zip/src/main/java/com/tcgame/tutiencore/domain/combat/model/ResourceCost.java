package com.tcgame.tutiencore.domain.combat.model;

import java.util.Objects;

public record ResourceCost(
        ResourceType resourceType,
        double amount,
        ResourceReason reason
) {
    public ResourceCost {
        Objects.requireNonNull(resourceType, "resourceType");
        Objects.requireNonNull(reason, "reason");
        if (!Double.isFinite(amount) || amount < 0) throw new IllegalArgumentException("amount must be finite and >= 0");
    }
}
