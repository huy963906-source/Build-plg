package com.tcgame.tutiencore.domain.combat.model;

import java.util.Objects;
import java.util.UUID;

public record SkillExecution(
        UUID executionId,
        String skillId,
        UUID casterId,
        UUID targetId,
        long createdAtTick,
        long impactAtTick,
        long expireAtTick,
        SkillExecutionState state
) {
    public SkillExecution {
        Objects.requireNonNull(executionId, "executionId");
        if (skillId == null || skillId.isBlank()) throw new IllegalArgumentException("skillId cannot be blank");
        Objects.requireNonNull(casterId, "casterId");
        Objects.requireNonNull(targetId, "targetId");
        Objects.requireNonNull(state, "state");
        if (createdAtTick < 0 || impactAtTick < createdAtTick || expireAtTick < impactAtTick) {
            throw new IllegalArgumentException("invalid execution timeline");
        }
    }
}
