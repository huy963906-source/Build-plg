package com.tcgame.tutiencore.domain.movement.api;

import com.tcgame.tutiencore.domain.movement.model.DismountReason;
import com.tcgame.tutiencore.domain.movement.model.FlightSession;
import com.tcgame.tutiencore.domain.movement.model.MovementInput;

import java.util.Optional;
import java.util.UUID;

public interface MovementAPI {
    Optional<FlightSession> getSession(UUID playerId);
    boolean canStart(UUID playerId);
    FlightSession start(UUID playerId);
    void update(UUID playerId, MovementInput input);
    void dismount(UUID playerId, DismountReason reason);
    boolean isFlying(UUID playerId);
}
