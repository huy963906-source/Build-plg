package com.tcgame.tutiencore.domain.combat.model;

public enum ResourceReason {
    SKILL_CAST,
    FLIGHT,
    RESTORE,
    ADMIN
}
