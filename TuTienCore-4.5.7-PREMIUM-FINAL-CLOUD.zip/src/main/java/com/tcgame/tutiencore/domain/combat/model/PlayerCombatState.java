package com.tcgame.tutiencore.domain.combat.model;

import java.util.Objects;
import java.util.UUID;

public record PlayerCombatState(
        UUID playerId,
        long tuVi,
        double chanKhi,
        double maxChanKhi,
        double regeneration,
        LinhCanProfile linhCan,
        CombatState combatState
) {
    public PlayerCombatState {
        Objects.requireNonNull(playerId, "playerId");
        Objects.requireNonNull(linhCan, "linhCan");
        Objects.requireNonNull(combatState, "combatState");
        if (tuVi < 0) throw new IllegalArgumentException("tuVi must be >= 0");
        if (!Double.isFinite(chanKhi) || chanKhi < 0) throw new IllegalArgumentException("chanKhi must be finite and >= 0");
        if (!Double.isFinite(maxChanKhi) || maxChanKhi < 0) throw new IllegalArgumentException("maxChanKhi must be finite and >= 0");
        if (chanKhi > maxChanKhi) throw new IllegalArgumentException("chanKhi cannot exceed maxChanKhi");
        if (!Double.isFinite(regeneration) || regeneration < 0) throw new IllegalArgumentException("regeneration must be finite and >= 0");
    }
}
