package com.tcgame.tutiencore.domain.combat.model;

import java.util.Objects;

public record LinhCanProfile(
        LinhCanQuality quality,
        double regenerationMultiplier
) {
    public LinhCanProfile {
        Objects.requireNonNull(quality, "quality");
        if (!Double.isFinite(regenerationMultiplier) || regenerationMultiplier < 0.0) {
            throw new IllegalArgumentException("regenerationMultiplier must be finite and >= 0");
        }
    }
}
