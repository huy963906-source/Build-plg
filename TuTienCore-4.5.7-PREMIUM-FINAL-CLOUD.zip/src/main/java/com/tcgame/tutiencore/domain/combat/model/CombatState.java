package com.tcgame.tutiencore.domain.combat.model;

public enum CombatState {
    OUT_OF_COMBAT,
    IN_COMBAT,
    CROWD_CONTROLLED,
    CASTING
}
