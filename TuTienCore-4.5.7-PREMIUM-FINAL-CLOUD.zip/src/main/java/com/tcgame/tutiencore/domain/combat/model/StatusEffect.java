package com.tcgame.tutiencore.domain.combat.model;

import java.util.Objects;

public record StatusEffect(
        String effectId,
        int amplifier,
        long durationTicks
) {
    public StatusEffect {
        if (effectId == null || effectId.isBlank()) throw new IllegalArgumentException("effectId cannot be blank");
        if (amplifier < 0) throw new IllegalArgumentException("amplifier must be >= 0");
        if (durationTicks < 0) throw new IllegalArgumentException("durationTicks must be >= 0");
    }
}
