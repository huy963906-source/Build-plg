package com.tcgame.tutiencore.domain.combat.model;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

public record ImpactPoint(
        UUID executionId,
        String skillId,
        LocationSnapshot location,
        long impactAtTick,
        List<UUID> targetIds
) {
    public ImpactPoint {
        Objects.requireNonNull(executionId, "executionId");
        if (skillId == null || skillId.isBlank()) throw new IllegalArgumentException("skillId cannot be blank");
        Objects.requireNonNull(location, "location");
        if (impactAtTick < 0) throw new IllegalArgumentException("impactAtTick must be >= 0");
        targetIds = List.copyOf(Objects.requireNonNull(targetIds, "targetIds"));
    }
}
