package com.tcgame.tutiencore.domain.combat.model;

public enum SkillExecutionState {
    CREATED,
    VALIDATED,
    SCHEDULED,
    IMPACTED,
    COMPLETED,
    CANCELLED
}
