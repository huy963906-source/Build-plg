package com.tcgame.tutiencore.domain.combat.model;

public record LocationSnapshot(
        String world,
        double x,
        double y,
        double z,
        float yaw,
        float pitch
) {
    public LocationSnapshot {
        if (world == null || world.isBlank()) throw new IllegalArgumentException("world cannot be blank");
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)) throw new IllegalArgumentException("coordinates must be finite");
        if (!Float.isFinite(yaw) || !Float.isFinite(pitch)) throw new IllegalArgumentException("rotation must be finite");
    }
}
