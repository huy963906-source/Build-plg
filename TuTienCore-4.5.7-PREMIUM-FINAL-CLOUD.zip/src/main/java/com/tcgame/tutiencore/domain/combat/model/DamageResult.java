package com.tcgame.tutiencore.domain.combat.model;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

public record DamageResult(
        UUID executionId,
        double rawDamage,
        double finalDamage,
        DamageType damageType,
        List<StatusEffect> effects
) {
    public DamageResult {
        Objects.requireNonNull(executionId, "executionId");
        Objects.requireNonNull(damageType, "damageType");
        effects = List.copyOf(Objects.requireNonNull(effects, "effects"));
        if (!Double.isFinite(rawDamage) || rawDamage < 0) throw new IllegalArgumentException("rawDamage must be finite and >= 0");
        if (!Double.isFinite(finalDamage) || finalDamage < 0) throw new IllegalArgumentException("finalDamage must be finite and >= 0");
    }
}
