package com.tcgame.tutiencore.domain.combat.model;

import java.util.Objects;
import java.util.UUID;

public record SkillCastRequest(
        UUID executionId,
        UUID casterId,
        UUID targetId,
        String skillId,
        long createdAtTick
) {
    public SkillCastRequest {
        Objects.requireNonNull(executionId, "executionId");
        Objects.requireNonNull(casterId, "casterId");
        Objects.requireNonNull(targetId, "targetId");
        if (skillId == null || skillId.isBlank()) throw new IllegalArgumentException("skillId cannot be blank");
        if (createdAtTick < 0) throw new IllegalArgumentException("createdAtTick must be >= 0");
    }
}
