package com.tcgame.tutiencore.domain.combat.model;

import java.util.Objects;
import java.util.UUID;

public record CombatRequest(
        UUID executionId,
        UUID attackerId,
        UUID targetId,
        String skillId,
        long serverTick
) {
    public CombatRequest {
        Objects.requireNonNull(executionId, "executionId");
        Objects.requireNonNull(attackerId, "attackerId");
        Objects.requireNonNull(targetId, "targetId");
        if (skillId == null || skillId.isBlank()) throw new IllegalArgumentException("skillId cannot be blank");
        if (serverTick < 0) throw new IllegalArgumentException("serverTick must be >= 0");
    }
}
