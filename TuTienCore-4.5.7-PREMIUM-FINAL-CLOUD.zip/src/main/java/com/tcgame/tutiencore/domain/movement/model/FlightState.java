package com.tcgame.tutiencore.domain.movement.model;

public enum FlightState {
    SPAWN,
    ATTACH,
    ACTIVE,
    DISMOUNT,
    CLEANUP,
    DESTROYED
}
