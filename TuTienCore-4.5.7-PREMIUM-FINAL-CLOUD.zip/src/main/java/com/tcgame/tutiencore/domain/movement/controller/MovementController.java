package com.tcgame.tutiencore.domain.movement.controller;

import com.tcgame.tutiencore.domain.movement.model.MovementInput;
import com.tcgame.tutiencore.domain.movement.model.MovementSnapshot;
import com.tcgame.tutiencore.domain.movement.model.MovementVector;

public interface MovementController {
    MovementVector calculate(MovementSnapshot current, MovementInput input);
}
