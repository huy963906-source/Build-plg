package com.tcgame.tutiencore.domain.movement.model;

import java.util.Objects;
import java.util.UUID;

public record FlightSession(
        UUID sessionId,
        UUID ownerId,
        UUID mountEntityId,
        UUID displayEntityId,
        FlightState state,
        double currentChanKhi,
        double maxChanKhi,
        long createdAtTick
) {
    public FlightSession {
        Objects.requireNonNull(sessionId, "sessionId");
        Objects.requireNonNull(ownerId, "ownerId");
        Objects.requireNonNull(mountEntityId, "mountEntityId");
        Objects.requireNonNull(displayEntityId, "displayEntityId");
        Objects.requireNonNull(state, "state");
        if (!Double.isFinite(currentChanKhi) || currentChanKhi < 0) throw new IllegalArgumentException("currentChanKhi must be finite and >= 0");
        if (!Double.isFinite(maxChanKhi) || maxChanKhi < 0) throw new IllegalArgumentException("maxChanKhi must be finite and >= 0");
        if (currentChanKhi > maxChanKhi) throw new IllegalArgumentException("currentChanKhi cannot exceed maxChanKhi");
        if (createdAtTick < 0) throw new IllegalArgumentException("createdAtTick must be >= 0");
    }
}
