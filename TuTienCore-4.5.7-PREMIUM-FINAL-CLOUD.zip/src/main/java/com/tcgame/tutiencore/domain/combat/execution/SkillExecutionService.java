package com.tcgame.tutiencore.domain.combat.execution;

import com.tcgame.tutiencore.domain.combat.model.ImpactPoint;
import com.tcgame.tutiencore.domain.combat.model.SkillCastRequest;
import com.tcgame.tutiencore.domain.combat.model.SkillExecution;

import java.util.UUID;

public interface SkillExecutionService {
    SkillExecution validate(SkillCastRequest request);
    SkillExecution schedule(SkillExecution execution);
    ImpactPoint resolveImpact(SkillExecution execution);
    void complete(UUID executionId);
    void cancel(UUID executionId);
}
