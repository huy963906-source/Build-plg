package com.tcgame.tutiencore.domain.combat.api;

import com.tcgame.tutiencore.domain.combat.model.SkillCastRequest;
import com.tcgame.tutiencore.domain.combat.model.SkillDefinition;
import com.tcgame.tutiencore.domain.combat.model.SkillExecution;

import java.util.Optional;
import java.util.UUID;

public interface SkillAPI {
    SkillDefinition getSkill(String skillId);
    boolean canCast(SkillCastRequest request);
    SkillExecution createExecution(SkillCastRequest request);
    void cancelExecution(UUID executionId);
    Optional<SkillExecution> getExecution(UUID executionId);
}
