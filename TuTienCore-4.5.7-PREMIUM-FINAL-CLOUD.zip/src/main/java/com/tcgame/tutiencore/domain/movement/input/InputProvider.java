package com.tcgame.tutiencore.domain.movement.input;

import com.tcgame.tutiencore.domain.movement.model.MovementInput;

import java.util.UUID;

public interface InputProvider {
    MovementInput getInput(UUID playerId);
}
