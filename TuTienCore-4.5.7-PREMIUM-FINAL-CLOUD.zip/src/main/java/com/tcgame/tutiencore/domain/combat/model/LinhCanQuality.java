package com.tcgame.tutiencore.domain.combat.model;

public enum LinhCanQuality {
    NGUY,
    HA,
    TRUNG,
    CAO,
    THIEN,
    BIEN_DI
}
