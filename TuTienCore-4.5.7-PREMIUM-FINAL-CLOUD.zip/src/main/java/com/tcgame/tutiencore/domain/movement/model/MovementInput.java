package com.tcgame.tutiencore.domain.movement.model;

public record MovementInput(
        boolean forward,
        boolean backward,
        boolean left,
        boolean right,
        boolean jump,
        boolean sneak,
        float yaw,
        float pitch
) {
    public MovementInput {
        if (!Float.isFinite(yaw) || !Float.isFinite(pitch)) throw new IllegalArgumentException("yaw/pitch must be finite");
    }
}
