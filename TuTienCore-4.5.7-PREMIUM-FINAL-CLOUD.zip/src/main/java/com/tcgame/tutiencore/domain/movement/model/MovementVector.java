package com.tcgame.tutiencore.domain.movement.model;

public record MovementVector(double x, double y, double z) {
    public MovementVector {
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)) throw new IllegalArgumentException("vector components must be finite");
    }

    public double lengthSquared() {
        return x * x + y * y + z * z;
    }
}
