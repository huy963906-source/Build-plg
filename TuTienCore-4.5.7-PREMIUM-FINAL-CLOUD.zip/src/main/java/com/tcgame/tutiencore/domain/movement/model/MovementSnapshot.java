package com.tcgame.tutiencore.domain.movement.model;

public record MovementSnapshot(
        String world,
        double x,
        double y,
        double z,
        float yaw,
        float pitch,
        long serverTick
) {
    public MovementSnapshot {
        if (world == null || world.isBlank()) throw new IllegalArgumentException("world cannot be blank");
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)) throw new IllegalArgumentException("coordinates must be finite");
        if (!Float.isFinite(yaw) || !Float.isFinite(pitch)) throw new IllegalArgumentException("rotation must be finite");
        if (serverTick < 0) throw new IllegalArgumentException("serverTick must be >= 0");
    }
}
