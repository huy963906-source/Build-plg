package com.tcgame.tutiencore.domain.combat.model;

import java.util.Objects;

public record SkillDefinition(
        String skillId,
        String name,
        int maxLevel,
        double baseDamage,
        double chanKhiCost,
        long cooldownMs,
        DamageType damageType
) {
    public SkillDefinition {
        if (skillId == null || skillId.isBlank()) throw new IllegalArgumentException("skillId cannot be blank");
        if (name == null || name.isBlank()) throw new IllegalArgumentException("name cannot be blank");
        if (maxLevel < 1) throw new IllegalArgumentException("maxLevel must be >= 1");
        if (!Double.isFinite(baseDamage) || baseDamage < 0) throw new IllegalArgumentException("baseDamage must be finite and >= 0");
        if (!Double.isFinite(chanKhiCost) || chanKhiCost < 0) throw new IllegalArgumentException("chanKhiCost must be finite and >= 0");
        if (cooldownMs < 0) throw new IllegalArgumentException("cooldownMs must be >= 0");
        Objects.requireNonNull(damageType, "damageType");
    }
}
