package com.tcgame.tutiencore.domain.movement.model;

public enum DismountReason {
    PLAYER_SNEAK,
    LOW_CHAN_KHI,
    CROWD_CONTROL,
    DISCONNECT,
    TELEPORT,
    WORLD_CHANGE,
    DEATH,
    ADMIN,
    SYSTEM
}
