package com.tcgame.tutiencore.domain.combat.model;

public enum ResourceType {
    CHAN_KHI
}
