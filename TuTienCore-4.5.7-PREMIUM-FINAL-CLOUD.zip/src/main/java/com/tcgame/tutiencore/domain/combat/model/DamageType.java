package com.tcgame.tutiencore.domain.combat.model;

public enum DamageType {
    PHYSICAL,
    MAGIC,
    POISON,
    PURE,
    SOUL_DAMAGE
}
