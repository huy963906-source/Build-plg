package com.tcgame.tutiencore.domain.combat.api;

import com.tcgame.tutiencore.domain.combat.model.*;

import java.util.UUID;

public interface CombatAPI {
    PlayerCombatState getState(UUID playerId);
    boolean canCast(CombatRequest request);
    ResourceCost consumeResource(CombatRequest request);
    DamageResult calculateDamage(CombatRequest request);
    void applyDamage(DamageResult result);
    void restoreResource(UUID playerId, double amount);
}
