package com.tcgame.tutiencore.domain.movement.resource;

import java.util.UUID;

public interface FlightResourceService {
    boolean canFly(UUID playerId);
    double getCurrent(UUID playerId);
    void consume(UUID playerId, double amount);
    void restore(UUID playerId, double amount);
}
