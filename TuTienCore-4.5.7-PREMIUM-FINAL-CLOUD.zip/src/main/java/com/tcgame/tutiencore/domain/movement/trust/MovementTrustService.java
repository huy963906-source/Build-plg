package com.tcgame.tutiencore.domain.movement.trust;

import java.util.UUID;

public interface MovementTrustService {
    void grantFlight(UUID playerId);
    void revokeFlight(UUID playerId);
    boolean isTrusted(UUID playerId);
}
