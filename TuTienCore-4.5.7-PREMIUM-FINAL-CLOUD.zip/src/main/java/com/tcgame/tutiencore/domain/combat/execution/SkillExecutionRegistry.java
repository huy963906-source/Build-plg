package com.tcgame.tutiencore.domain.combat.execution;

import com.tcgame.tutiencore.domain.combat.model.SkillExecution;

import java.util.Optional;
import java.util.UUID;

/**
 * Contract for lifecycle storage and idempotency. Implementations own TTL eviction.
 */
public interface SkillExecutionRegistry {
    Optional<SkillExecution> get(UUID executionId);
    boolean register(SkillExecution execution);
    boolean markImpacted(UUID executionId);
    boolean hasImpacted(UUID executionId);
    void update(SkillExecution execution);
    void evictExpired(long currentTick, long completedTtlTicks);
    void clear();
}
