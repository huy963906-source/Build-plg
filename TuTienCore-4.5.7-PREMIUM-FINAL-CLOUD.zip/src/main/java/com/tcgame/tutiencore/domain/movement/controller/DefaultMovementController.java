package com.tcgame.tutiencore.domain.movement.controller;

import com.tcgame.tutiencore.domain.movement.model.MovementInput;
import com.tcgame.tutiencore.domain.movement.model.MovementSnapshot;
import com.tcgame.tutiencore.domain.movement.model.MovementVector;

/**
 * Pure-Java flight movement calculator.
 *
 * <p>Horizontal movement is normalized so diagonal input cannot increase
 * horizontal speed. Pitch contributes to the forward/backward vertical
 * component. Jump adds independent upward control; sneak is intentionally
 * ignored because on a ridden entity the native client Shift key is the
 * dismount action.</p>
 */
public final class DefaultMovementController implements MovementController {

    private final double flightSpeed;
    private final double verticalSpeed;

    public DefaultMovementController(double flightSpeed, double verticalSpeed) {
        if (!Double.isFinite(flightSpeed) || flightSpeed < 0.0) {
            throw new IllegalArgumentException("flightSpeed must be finite and >= 0");
        }
        if (!Double.isFinite(verticalSpeed) || verticalSpeed < 0.0) {
            throw new IllegalArgumentException("verticalSpeed must be finite and >= 0");
        }
        this.flightSpeed = flightSpeed;
        this.verticalSpeed = verticalSpeed;
    }

    public double flightSpeed() {
        return flightSpeed;
    }

    public double verticalSpeed() {
        return verticalSpeed;
    }

    @Override
    public MovementVector calculate(MovementSnapshot current, MovementInput input) {
        if (current == null) throw new IllegalArgumentException("current cannot be null");
        if (input == null) throw new IllegalArgumentException("input cannot be null");

        final double yaw = Math.toRadians(input.yaw() + 90.0);
        final double pitch = Math.toRadians(-input.pitch());

        final double cosPitch = Math.cos(pitch);
        final double forwardX = cosPitch * Math.cos(yaw);
        final double forwardY = Math.sin(pitch);
        final double forwardZ = cosPitch * Math.sin(yaw);

        // Minecraft yaw uses +Z as forward at yaw=0. The right vector must
        // rotate clockwise from forward; the old Z sign made A/D swap when
        // the player turned away from the default heading.
        final double inputYaw = Math.toRadians(input.yaw());
        final double rightX = Math.cos(inputYaw);
        final double rightZ = -Math.sin(inputYaw);

        double x = 0.0;
        double y = 0.0;
        double z = 0.0;

        if (input.forward()) {
            x += forwardX;
            y += forwardY;
            z += forwardZ;
        }
        if (input.backward()) {
            x -= forwardX;
            y -= forwardY;
            z -= forwardZ;
        }
        if (input.right()) {
            x += rightX;
            z += rightZ;
        }
        if (input.left()) {
            x -= rightX;
            z -= rightZ;
        }

        // Normalize only the horizontal component.
        final double horizontalLength = Math.hypot(x, z);
        if (horizontalLength > 1.0e-12) {
            x = (x / horizontalLength) * flightSpeed;
            z = (z / horizontalLength) * flightSpeed;
        } else {
            x = 0.0;
            z = 0.0;
        }

        if (input.jump()) {
            y += verticalSpeed;
        }
        // Native Shift/Sneak is intentionally NOT mapped to downward movement.
        // On a ridden Interaction entity it is the client's native dismount
        // input; EntityDismountEvent is allowed to complete the dismount.

        return new MovementVector(x, y, z);
    }
}
