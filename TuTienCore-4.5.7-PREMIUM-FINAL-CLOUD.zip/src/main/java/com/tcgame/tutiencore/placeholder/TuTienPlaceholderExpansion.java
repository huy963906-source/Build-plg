package com.tcgame.tutiencore.placeholder;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.economy.EconomyService;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

import java.text.DecimalFormat;

public final class TuTienPlaceholderExpansion extends PlaceholderExpansion {
    private final TuTienCore plugin;
    private final EconomyService economy;
    private final DecimalFormat format = new DecimalFormat("#,##0.##");

    public TuTienPlaceholderExpansion(TuTienCore plugin, EconomyService economy) {
        this.plugin = plugin;
        this.economy = economy;
    }

    @Override public @NotNull String getIdentifier() { return "tutien"; }
    @Override public @NotNull String getAuthor() { return String.join(", ", plugin.getDescription().getAuthors()); }
    @Override public @NotNull String getVersion() { return plugin.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return null;
        String key = params.toLowerCase();
        if (key.equals("linhthach")) return plugin.getLinhThachBankService().balance(player.getUniqueId()).toString();
        if (key.equals("linhthach_tui")) return player.isOnline() && player.getPlayer() != null ? format.format(plugin.getAlchemySystem().countLinhThach(player.getPlayer())) : "0";

        PlayerData d = plugin.getCultivationService().getPlayerData(player.getUniqueId());
        return switch (key) {
            case "linhkhi" -> format.format(d.linhKhi());
            case "linhkhi_max" -> Long.toString(d.maxLinhKhi());
            case "linhkhi_progress" -> String.format("%.1f%%", d.progress() * 100D);
            case "canhgioi" -> d.realmDisplay();
            case "canhgioi_id" -> d.realm().name();
            case "canhgioi_tang" -> Integer.toString(d.realmStage());
            case "canhgioi_cap" -> Integer.toString(d.cultivationLevel());
            case "linhcan" -> d.spiritRootDisplay();
            case "linhcan_id" -> d.spiritRoot().name();
            case "linhcan_phamchat" -> d.spiritRootQuality().displayName();
            case "linhcan_phamchat_id" -> d.spiritRootQuality().name();
            case "cancot" -> format.format(d.canCot());
            case "ngotinh" -> format.format(d.ngoTinh());
            case "rank" -> plugin.getRankSystem().name(d.rankLevel());
            case "rank_id" -> Integer.toString(d.rankLevel());
            case "rank_prefix" -> plugin.getRankSystem().prefix(d.rankLevel());
            case "tuluyen_cycle_seconds" -> Long.toString(plugin.getRankSystem().trainingSeconds(d.rankLevel()));
            case "linhgioi_unlocked" -> Boolean.toString(d.finalTribulationPassed());
            case "congphap_cap" -> Integer.toString(d.techniqueLevel());
            case "congphap_exp" -> Long.toString(d.techniqueExp());
            case "tamphap_cap" -> Integer.toString(d.tamPhapLevel());
            case "tongmon" -> plugin.getSectSystem().getNameFor(player.getUniqueId());
            case "linhthu" -> d.petName().isBlank() ? "Chưa có" : d.petName();
            case "linhthu_level" -> Integer.toString(d.petLevel());
            case "tuluyen" -> plugin.getTrainingManager().isTraining(player.getUniqueId()) ? "Đang tu luyện" : "Không";
            case "do_kiep" -> plugin.getTribulationSystem().isInTribulation(player.getUniqueId()) ? "Đang độ kiếp" : "Không";
            default -> null;
        };
    }
}
