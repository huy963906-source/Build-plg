package com.tcgame.tutiencore.storage;

import com.tcgame.tutiencore.TuTienCore;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;

/** Persistent 54-slot personal storage. */
public final class StorageSystem implements Listener {
    public static final String TITLE = "§5§l✦ TÚI TRỮ VẬT ✦";
    private final TuTienCore plugin;
    private final File file;
    private final YamlConfiguration data;

    public StorageSystem(TuTienCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "storage.yml");
        if (!file.exists()) {
            try { file.createNewFile(); } catch (IOException e) { plugin.getLogger().warning("Không tạo được storage.yml: " + e.getMessage()); }
        }
        this.data = YamlConfiguration.loadConfiguration(file);
    }

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE);
        String base = "storage." + player.getUniqueId();
        for (int slot = 0; slot < 54; slot++) {
            ItemStack item = data.getItemStack(base + ".slot." + slot);
            if (item != null && !item.getType().isAir()) inv.setItem(slot, item);
        }
        player.openInventory(inv);
        player.sendActionBar("§5✦ Túi Trữ Vật §7| §f54 ô lưu trữ riêng");
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!TITLE.equals(event.getView().getTitle())) return;
        if (!(event.getPlayer() instanceof Player player)) return;
        saveInventory(player, event.getInventory());
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (!TITLE.equals(event.getView().getTitle())) return;
        // All slots in this GUI belong to storage, so normal drag is allowed.
    }

    public void saveInventory(Player player, Inventory inv) {
        String base = "storage." + player.getUniqueId();
        data.set(base, null);
        for (int slot = 0; slot < Math.min(54, inv.getSize()); slot++) {
            ItemStack item = inv.getItem(slot);
            if (item != null && !item.getType().isAir()) data.set(base + ".slot." + slot, item);
        }
        saveFile();
    }

    public void saveAllOpen() {
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            if (TITLE.equals(p.getOpenInventory().getTitle())) saveInventory(p, p.getOpenInventory().getTopInventory());
        }
    }

    private void saveFile() {
        try { data.save(file); }
        catch (IOException e) { plugin.getLogger().warning("Không lưu được storage.yml: " + e.getMessage()); }
    }
}
