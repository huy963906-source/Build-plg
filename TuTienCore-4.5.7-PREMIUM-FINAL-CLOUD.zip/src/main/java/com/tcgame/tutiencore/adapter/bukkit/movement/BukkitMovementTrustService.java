package com.tcgame.tutiencore.adapter.bukkit.movement;

import com.tcgame.tutiencore.domain.movement.trust.MovementTrustService;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Bridge used by AntiCheat to recognize legitimate Ngự Kiếm movement. */
public final class BukkitMovementTrustService implements MovementTrustService {
    private final Set<UUID> trusted = ConcurrentHashMap.newKeySet();

    @Override
    public void grantFlight(UUID playerId) { trusted.add(playerId); }

    @Override
    public void revokeFlight(UUID playerId) { trusted.remove(playerId); }

    @Override
    public boolean isTrusted(UUID playerId) { return trusted.contains(playerId); }
}
