package com.tcgame.tutiencore.adapter.bukkit.movement;

import com.tcgame.tutiencore.domain.movement.model.DismountReason;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.cultivation.Realm;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public final class NgukiemCommand implements CommandExecutor {
    private final BukkitMovementAPI movement;
    public NgukiemCommand(BukkitMovementAPI movement) { this.movement = movement; }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
        UUID id = p.getUniqueId();
        PlayerData data = ((com.tcgame.tutiencore.TuTienCore) movement.getPlugin()).getCultivationService().getPlayerData(id);
        if (data.realm() != Realm.TRUC_CO && data.realm() != Realm.KIM_DAN && data.realm().ordinal() < Realm.TRUC_CO.ordinal()) {
            p.sendMessage("§c[Ngự Kiếm] §fYêu cầu tối thiểu: §dTrúc Cơ Tầng 1§f.");
            return true;
        }
        if (movement.isFlying(id)) {
            movement.dismount(id, DismountReason.ADMIN);
            p.sendMessage("§7[Ngự Kiếm] §fĐã hạ xuống.");
            return true;
        }
        try {
            movement.start(id);
            p.sendMessage("§d[Ngự Kiếm] §fCất cánh! §7WASD + chuột để điều hướng, Space để lên, Shift để rời kiếm.");
        } catch (IllegalStateException ex) {
            p.sendMessage("§c[Ngự Kiếm] §fKhông thể cất cánh lúc này.");
        }
        return true;
    }
}
