package com.tcgame.tutiencore.adapter.bukkit.movement;

import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.domain.movement.api.MovementAPI;
import com.tcgame.tutiencore.domain.movement.controller.MovementController;
import com.tcgame.tutiencore.domain.movement.input.InputProvider;
import com.tcgame.tutiencore.domain.movement.model.*;
import com.tcgame.tutiencore.domain.movement.resource.FlightResourceService;
import com.tcgame.tutiencore.domain.movement.trust.MovementTrustService;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Main-thread Bukkit adapter. Domain code calculates movement; this class only
 * owns entities, sessions, teleportation and Bukkit lifecycle.
 */
public final class BukkitMovementAPI implements MovementAPI {
    private static final String TAG = "tutiencore_ngukiem";

    private final JavaPlugin plugin;
    private final MovementController controller;
    private final InputProvider inputProvider;
    private final FlightResourceService resources;
    private final MovementTrustService trust;
    private final Map<UUID, FlightRuntime> sessions = new ConcurrentHashMap<>();
    private final NamespacedKey ownerKey;
    private final NamespacedKey sessionKey;
    private final double drainPerTick;

    public BukkitMovementAPI(JavaPlugin plugin, MovementController controller,
                             InputProvider inputProvider, FlightResourceService resources,
                             MovementTrustService trust, double drainPerTick) {
        this.plugin = Objects.requireNonNull(plugin);
        this.controller = Objects.requireNonNull(controller);
        this.inputProvider = Objects.requireNonNull(inputProvider);
        this.resources = Objects.requireNonNull(resources);
        this.trust = Objects.requireNonNull(trust);
        if (!Double.isFinite(drainPerTick) || drainPerTick < 0) throw new IllegalArgumentException("drainPerTick must be finite and >= 0");
        this.drainPerTick = drainPerTick;
        this.ownerKey = new NamespacedKey(plugin, "flight_owner");
        this.sessionKey = new NamespacedKey(plugin, "flight_session");
    }

    public JavaPlugin getPlugin() { return plugin; }

    @Override public Optional<FlightSession> getSession(UUID playerId) {
        FlightRuntime r = sessions.get(playerId);
        return r == null ? Optional.empty() : Optional.of(r.model());
    }

    @Override public boolean canStart(UUID playerId) {
        Player p = plugin.getServer().getPlayer(playerId);
        return p != null && p.isOnline() && !sessions.containsKey(playerId) && resources.canFly(playerId);
    }

    @Override public FlightSession start(UUID playerId) {
        Player player = requirePlayer(playerId);
        if (!canStart(playerId)) throw new IllegalStateException("Player cannot start flight");

        UUID sessionId = UUID.randomUUID();
        World world = player.getWorld();
        Location base = player.getLocation().clone();

        Interaction mount = (Interaction) world.spawnEntity(base, EntityType.INTERACTION);
        ItemDisplay display = (ItemDisplay) world.spawnEntity(base, EntityType.ITEM_DISPLAY);

        mount.addScoreboardTag(TAG);
        display.addScoreboardTag(TAG);
        mark(mount, playerId, sessionId);
        mark(display, playerId, sessionId);

        mount.setInteractionWidth(1.25f);
        mount.setInteractionHeight(0.25f);
        mount.setGravity(false);
        mount.setInvulnerable(true);
        mount.setSilent(true);

        display.setGravity(false);
        display.setInvulnerable(true);
        display.setSilent(true);
        PlayerData pd = ((com.tcgame.tutiencore.TuTienCore) plugin).getCultivationService().getPlayerData(playerId);
        String skin = pd.flightSkin();
        String configuredMaterial = plugin.getConfig().getString("flight.sword-skins." + skin + ".material", "WOODEN_SWORD");
        org.bukkit.Material swordMaterial = org.bukkit.Material.matchMaterial(configuredMaterial == null ? "WOODEN_SWORD" : configuredMaterial);
        if (swordMaterial == null || !swordMaterial.name().endsWith("_SWORD")) swordMaterial = org.bukkit.Material.WOODEN_SWORD;
        display.setItemStack(new ItemStack(swordMaterial));
        // Match the supplied /summon model exactly: item_display:"none" and UNIFORM
        // scale. The previous (4,1,4) scale stretched the sword and made the model look
        // distorted. The command's 2.8284 values are a uniform scale (sqrt(8)).
        display.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);
        display.setTransformation(new Transformation(
                new Vector3f(0f, -0.50f, 1.1875f),
                new Quaternionf(0.6532815f, 0.27059805f, -0.27059805f, 0.6532815f),
                new Vector3f(2.8284f, 2.8284f, 2.8284f),
                new Quaternionf()
        ));

        FlightSession model = new FlightSession(sessionId, playerId, mount.getUniqueId(), display.getUniqueId(),
                FlightState.SPAWN, resources.getCurrent(playerId), resources.getCurrent(playerId), plugin.getServer().getCurrentTick());
        FlightRuntime runtime = new FlightRuntime(model, mount, display);
        sessions.put(playerId, runtime);

        // ATTACH is completed on the server thread; Shift remains native dismount.
        mount.addPassenger(player);
        trust.grantFlight(playerId);
        runtime.state = FlightState.ACTIVE;
        teleportDisplay(runtime, mount.getLocation());
        return runtime.model();
    }

    @Override public void update(UUID playerId, MovementInput input) {
        FlightRuntime r = sessions.get(playerId);
        if (r == null || r.state != FlightState.ACTIVE) return;
        Player p = plugin.getServer().getPlayer(playerId);
        if (p == null || !p.isOnline() || !r.mount.isValid()) {
            dismount(playerId, DismountReason.DISCONNECT);
            return;
        }

        Location current = r.mount.getLocation();
        MovementSnapshot snapshot = new MovementSnapshot(current.getWorld().getName(), current.getX(), current.getY(), current.getZ(),
                p.getYaw(), p.getPitch(), plugin.getServer().getCurrentTick());
        MovementVector delta = controller.calculate(snapshot, input);
        Location next = current.clone().add(delta.x(), delta.y(), delta.z());
        next.setYaw(p.getYaw());
        next.setPitch(0f);
        if (!isSafe(next)) {
            delta = new MovementVector(0, Math.min(0, delta.y()), 0);
            next = current.clone().add(delta.x(), delta.y(), delta.z());
        }
        r.mount.teleport(next);
        teleportDisplay(r, next);
        resources.consume(playerId, drainPerTick);
        if (!resources.canFly(playerId)) dismount(playerId, DismountReason.LOW_CHAN_KHI);
        else r.currentChanKhi = resources.getCurrent(playerId);
    }

    @Override public void dismount(UUID playerId, DismountReason reason) {
        FlightRuntime r = sessions.remove(playerId);
        if (r == null) return;
        r.state = FlightState.DISMOUNT;
        trust.revokeFlight(playerId);

        Player p = plugin.getServer().getPlayer(playerId);
        if (p != null && p.isOnline() && p.getVehicle() == r.mount) p.leaveVehicle();
        r.state = FlightState.CLEANUP;
        removeEntity(r.mount);
        removeEntity(r.display);
        r.state = FlightState.DESTROYED;
    }

    @Override public boolean isFlying(UUID playerId) { return sessions.containsKey(playerId); }

    public void tick() {
        // Keep all Bukkit/entity operations on the server thread.
        for (UUID id : new ArrayList<>(sessions.keySet())) {
            FlightRuntime r = sessions.get(id);
            if (r == null) continue;
            if (r.mount.getPassengers().stream().noneMatch(e -> e.getUniqueId().equals(id))) {
                // Native Shift dismount has happened; the event normally catches it.
                if (!r.mount.getPassengers().stream().anyMatch(e -> e instanceof Player)) {
                    dismount(id, DismountReason.PLAYER_SNEAK);
                    continue;
                }
            }
            update(id, inputProvider.getInput(id));
        }
    }

    public void handleNativeDismount(Entity rider, Entity dismounted) {
        if (!(rider instanceof Player player)) return;
        FlightRuntime r = sessions.get(player.getUniqueId());
        if (r != null && r.mount.getUniqueId().equals(dismounted.getUniqueId())) {
            dismount(player.getUniqueId(), DismountReason.PLAYER_SNEAK);
        }
    }

    /** Called when Paper removes either runtime entity unexpectedly. */
    public void handleTaggedEntityRemoved(Entity entity) {
        if (entity == null) return;
        String ownerRaw = entity.getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
        if (ownerRaw == null) return;
        try {
            UUID owner = UUID.fromString(ownerRaw);
            FlightRuntime r = sessions.get(owner);
            if (r == null) return;
            if (entity.getUniqueId().equals(r.mount.getUniqueId()) || entity.getUniqueId().equals(r.display.getUniqueId())) {
                plugin.getServer().getScheduler().runTask(plugin, () -> dismount(owner, DismountReason.SYSTEM));
            }
        } catch (IllegalArgumentException ignored) {
            // Corrupt PDC is handled by the periodic hard reset.
        }
    }

    public void cleanupAll(DismountReason reason) {
        for (UUID id : new ArrayList<>(sessions.keySet())) dismount(id, reason);
        trustCleanup();
    }

    public void hardResetTaggedEntities() {
        Set<UUID> onlineOwners = new HashSet<>();
        for (FlightRuntime r : sessions.values()) onlineOwners.add(r.base.ownerId());

        for (World world : plugin.getServer().getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (!entity.getScoreboardTags().contains(TAG)) continue;

                String ownerRaw = entity.getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
                UUID owner = null;
                if (ownerRaw != null) {
                    try { owner = UUID.fromString(ownerRaw); }
                    catch (IllegalArgumentException ignored) { }
                }

                FlightRuntime runtime = owner == null ? null : sessions.get(owner);
                boolean validMount = runtime != null && entity.getUniqueId().equals(runtime.mount.getUniqueId());
                boolean validDisplay = runtime != null && entity.getUniqueId().equals(runtime.display.getUniqueId());
                boolean ownerOnline = owner != null && plugin.getServer().getPlayer(owner) != null;

                if (!ownerOnline || runtime == null || (!validMount && !validDisplay)) {
                    entity.remove();
                }
            }
        }

        // A session can survive an unexpected entity removal; invalidate it as well.
        for (UUID owner : new ArrayList<>(sessions.keySet())) {
            FlightRuntime r = sessions.get(owner);
            if (r == null) continue;
            if (!r.mount.isValid() || !r.display.isValid()) {
                dismount(owner, DismountReason.SYSTEM);
            }
        }
    }

    private void trustCleanup() {
        for (UUID id : new ArrayList<>(sessions.keySet())) trust.revokeFlight(id);
    }

    private void mark(Entity entity, UUID owner, UUID session) {
        entity.getPersistentDataContainer().set(ownerKey, PersistentDataType.STRING, owner.toString());
        entity.getPersistentDataContainer().set(sessionKey, PersistentDataType.STRING, session.toString());
    }

    private void teleportDisplay(FlightRuntime r, Location loc) {
        if (r.display.isValid()) r.display.teleport(loc.clone().add(0, -0.15, 0));
    }

    public MovementTrustService trustService() {
        return trust;
    }

    private boolean isSafe(Location loc) {
        return loc.getWorld() != null && Double.isFinite(loc.getX()) && Double.isFinite(loc.getY()) && Double.isFinite(loc.getZ())
                && loc.getY() > loc.getWorld().getMinHeight() - 2 && loc.getY() < loc.getWorld().getMaxHeight() - 2;
    }

    private void removeEntity(Entity e) { if (e != null && e.isValid()) e.remove(); }
    private Player requirePlayer(UUID id) { Player p = plugin.getServer().getPlayer(id); if (p == null) throw new IllegalArgumentException("Player is offline"); return p; }

    private static final class FlightRuntime {
        final FlightSession base;
        final Interaction mount;
        final ItemDisplay display;
        FlightState state;
        double currentChanKhi;
        FlightRuntime(FlightSession base, Interaction mount, ItemDisplay display) {
            this.base = base; this.mount = mount; this.display = display; this.state = base.state(); this.currentChanKhi = base.currentChanKhi();
        }
        FlightSession model() { return new FlightSession(base.sessionId(), base.ownerId(), base.mountEntityId(), base.displayEntityId(), state, currentChanKhi, base.maxChanKhi(), base.createdAtTick()); }
    }
}
