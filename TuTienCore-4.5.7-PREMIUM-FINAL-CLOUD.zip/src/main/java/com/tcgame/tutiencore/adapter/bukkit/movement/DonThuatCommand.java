package com.tcgame.tutiencore.adapter.bukkit.movement;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.UUID;

/**
 * Lightweight Cycle-1 dash. It never creates a FlightSession.
 * It borrows MovementTrustService for a short window, then revokes it.
 */
public final class DonThuatCommand implements CommandExecutor {
    private final BukkitMovementAPI movement;
    private final JavaPlugin plugin;
    private final long durationTicks;
    private final double horizontalPower;
    private final double verticalPower;

    public DonThuatCommand(JavaPlugin plugin, BukkitMovementAPI movement, long durationTicks,
                           double horizontalPower, double verticalPower) {
        this.plugin = plugin;
        this.movement = movement;
        this.durationTicks = Math.max(1L, durationTicks);
        this.horizontalPower = horizontalPower;
        this.verticalPower = verticalPower;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }

        UUID id = player.getUniqueId();
        if (movement.isFlying(id)) {
            movement.dismount(id, com.tcgame.tutiencore.domain.movement.model.DismountReason.SYSTEM);
        }

        Vector direction = player.getLocation().getDirection().normalize();
        Vector velocity = direction.multiply(horizontalPower);
        velocity.setY(velocity.getY() + verticalPower);

        movement.trustService().grantFlight(id);
        player.setFallDistance(0f);
        player.setVelocity(velocity);
        player.sendMessage("§b[Độn Thuật] §fKích hoạt.");

        plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> movement.trustService().revokeFlight(id), durationTicks);
        return true;
    }

}
