package com.tcgame.tutiencore.adapter.bukkit.movement;

import com.tcgame.tutiencore.domain.movement.model.DismountReason;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDismountEvent;
import org.bukkit.event.entity.EntityRemoveEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInputEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class NgukiemListener implements Listener {
    private final PaperInputProvider inputs;
    private final BukkitMovementAPI movement;

    public NgukiemListener(PaperInputProvider inputs, BukkitMovementAPI movement) {
        this.inputs = inputs;
        this.movement = movement;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onInput(PlayerInputEvent event) {
        inputs.handle(event);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onEntityRemove(EntityRemoveEvent event) {
        movement.handleTaggedEntityRemoved(event.getEntity());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDismount(EntityDismountEvent event) {
        // DO NOT cancel. Shift remains native Minecraft dismount.
        movement.handleNativeDismount(event.getEntity(), event.getDismounted());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        movement.dismount(event.getPlayer().getUniqueId(), DismountReason.DISCONNECT);
        inputs.remove(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        movement.dismount(event.getPlayer().getUniqueId(), DismountReason.WORLD_CHANGE);
    }
}
