package com.tcgame.tutiencore.adapter.bukkit.movement;

import com.tcgame.tutiencore.domain.movement.input.InputProvider;
import com.tcgame.tutiencore.domain.movement.model.MovementInput;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInputEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Paper 1.21.x adapter: converts PlayerInputEvent into the domain MovementInput. */
public final class PaperInputProvider implements InputProvider {
    private final Map<UUID, MovementInput> inputs = new ConcurrentHashMap<>();

    public void handle(PlayerInputEvent event) {
        Player player = event.getPlayer();
        var in = event.getInput();
        inputs.put(player.getUniqueId(), new MovementInput(
                in.isForward(),
                in.isBackward(),
                // Keep Paper's native strafe semantics: A = left, D = right.
                // The previous build swapped these two flags and caused A/D to feel reversed.
                in.isLeft(),
                in.isRight(),
                in.isJump(),
                in.isSneak(),
                player.getYaw(),
                player.getPitch()
        ));
    }

    @Override
    public MovementInput getInput(UUID playerId) {
        MovementInput current = inputs.get(playerId);
        if (current != null) return current;
        return new MovementInput(false, false, false, false, false, false, 0.0f, 0.0f);
    }

    public void remove(UUID playerId) {
        inputs.remove(playerId);
    }
}
