package com.tcgame.tutiencore.adapter.bukkit.movement;

import com.tcgame.tutiencore.domain.movement.resource.FlightResourceService;

import java.util.UUID;

/**
 * Cycle-1 mock resource bridge. Free-to-play test mode: movement is always
 * allowed and no real Tu Vi/Linh Khi data is touched. Replace this adapter
 * with the real Chan Khi bridge in a later cycle without changing the contract.
 */
public final class SimpleFlightResourceService implements FlightResourceService {
    private static final double MOCK_CURRENT = 9999.0;

    @Override public boolean canFly(UUID playerId) { return true; }
    @Override public double getCurrent(UUID playerId) { return MOCK_CURRENT; }
    @Override public void consume(UUID playerId, double amount) { /* intentional no-op */ }
    @Override public void restore(UUID playerId, double amount) { /* intentional no-op */ }
}
