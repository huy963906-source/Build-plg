package com.tcgame.tutiencore.adapter.bukkit.movement;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.cultivation.Realm;
import com.tcgame.tutiencore.domain.movement.model.MovementInput;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Player-body flight. Cosmetic only: no paid speed/stat advantage. */
public final class PhiKhongService {
    private final TuTienCore plugin;
    private final Set<UUID> flying = ConcurrentHashMap.newKeySet();
    private final double horizontal;
    private final double vertical;

    public PhiKhongService(TuTienCore plugin) {
        this.plugin = plugin;
        this.horizontal = plugin.getConfig().getDouble("phi-khong.horizontal-speed", 0.65D);
        this.vertical = plugin.getConfig().getDouble("phi-khong.vertical-speed", 0.45D);
    }

    public boolean isFlying(UUID id) { return flying.contains(id); }

    public boolean toggle(Player p) {
        if (isFlying(p.getUniqueId())) { stop(p); return false; }
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (!plugin.getSectSystem().isInOwnSectClaim(p)) {
            p.sendMessage("§c[Phi Không] §fChỉ được bay trong Lãnh Địa Tông Môn của bạn.");
            return false;
        }
        if (d.realm().ordinal() < Realm.TRUC_CO.ordinal()) {
            p.sendMessage("§c[Phi Không] §fYêu cầu tối thiểu §dTrúc Cơ Tầng 1§f.");
            return false;
        }
        flying.add(p.getUniqueId());
        p.setGravity(false);
        p.setFallDistance(0f);
        p.sendMessage("§b✦ Phi Không §fđã kích hoạt! §7WASD + chuột, Space lên, Shift hạ xuống.");
        return true;
    }

    public void stop(Player p) {
        flying.remove(p.getUniqueId());
        p.setGravity(true);
        p.setVelocity(p.getVelocity().setY(0));
        p.setFallDistance(0f);
        p.sendMessage("§7[Phi Không] §fĐã hạ xuống.");
    }

    public void tick(PaperInputProvider inputProvider) {
        for (UUID id : new ArrayList<>(flying)) {
            Player p = plugin.getServer().getPlayer(id);
            if (p == null || !p.isOnline()) { flying.remove(id); continue; }
            if (!plugin.getSectSystem().isInOwnSectClaim(p)) {
                stop(p);
                continue;
            }
            MovementInput in = inputProvider.getInput(id);
            double yaw = Math.toRadians(in.yaw() + 90.0D);
            double pitch = Math.toRadians(-in.pitch());
            double cos = Math.cos(pitch);
            double fx = cos * Math.cos(yaw), fy = Math.sin(pitch), fz = cos * Math.sin(yaw);
            double rx = Math.cos(yaw - Math.PI / 2.0D), rz = Math.sin(yaw - Math.PI / 2.0D);
            double x=0,z=0,y=0;
            if(in.forward()){x+=fx;z+=fz;y+=fy;}
            if(in.backward()){x-=fx;z-=fz;y-=fy;}
            if(in.left()){x-=rx;z-=rz;}
            if(in.right()){x+=rx;z+=rz;}
            if(in.jump()) y += 1.0D;
            if(in.sneak()) y -= 1.0D;
            double len=Math.sqrt(x*x+z*z);
            if(len>1){x/=len;z/=len;}
            if(Math.abs(y)>1)y=Math.signum(y);
            Location next=p.getLocation().clone().add(x*horizontal,y*vertical,z*horizontal);
            next.setYaw(p.getYaw()); next.setPitch(p.getPitch());
            p.teleport(next);
            p.setFallDistance(0f);
        }
    }

    public void cleanup() {
        for(UUID id:new ArrayList<>(flying)) {
            Player p=plugin.getServer().getPlayer(id);
            if(p!=null) { p.setGravity(true); p.setVelocity(p.getVelocity().setY(0)); }
        }
        flying.clear();
    }
}
