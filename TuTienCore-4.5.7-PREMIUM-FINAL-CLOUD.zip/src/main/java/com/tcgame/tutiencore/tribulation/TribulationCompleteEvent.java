package com.tcgame.tutiencore.tribulation;
import com.tcgame.tutiencore.cultivation.Realm;
import org.bukkit.entity.Player;
import org.bukkit.event.Event; import org.bukkit.event.HandlerList;
public final class TribulationCompleteEvent extends Event { private static final HandlerList HANDLERS=new HandlerList(); private final Player player; private final Realm target; private final boolean success; public TribulationCompleteEvent(Player p,Realm t,boolean s){player=p;target=t;success=s;} public Player getPlayer(){return player;} public Realm getTargetRealm(){return target;} public boolean isSuccess(){return success;} public HandlerList getHandlers(){return HANDLERS;} public static HandlerList getHandlerList(){return HANDLERS;} }
