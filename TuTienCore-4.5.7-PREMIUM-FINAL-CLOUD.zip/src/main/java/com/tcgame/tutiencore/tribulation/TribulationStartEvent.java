package com.tcgame.tutiencore.tribulation;
import com.tcgame.tutiencore.cultivation.Realm;
import org.bukkit.entity.Player;
import org.bukkit.event.Event; import org.bukkit.event.HandlerList;
public final class TribulationStartEvent extends Event { private static final HandlerList HANDLERS=new HandlerList(); private final Player player; private final Realm target; public TribulationStartEvent(Player p,Realm t){player=p;target=t;} public Player getPlayer(){return player;} public Realm getTargetRealm(){return target;} public HandlerList getHandlers(){return HANDLERS;} public static HandlerList getHandlerList(){return HANDLERS;} }
