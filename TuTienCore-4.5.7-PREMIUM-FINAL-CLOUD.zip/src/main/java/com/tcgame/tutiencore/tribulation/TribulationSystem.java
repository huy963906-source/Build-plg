package com.tcgame.tutiencore.tribulation;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.cultivation.Realm;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.BiConsumer;

/**
 * Nine-wave thunder tribulation system.
 *
 * Every /dotpha starts a tribulation. A normal tribulation has 9 waves,
 * each wave has 10 strike groups. Every strike group creates 2-3 visual
 * lightning bolts. The lightning effects themselves do not deal damage;
 * configurable damage pulses are applied separately.
 */
public final class TribulationSystem {
    private static final int DEFAULT_WAVES = 9;
    private static final int DEFAULT_STRIKES_PER_WAVE = 10;

    private final TuTienCore plugin;
    private final Map<UUID, Realm> active = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> wave = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> strikes = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> ticksUntilStrike = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> finalAscent = new ConcurrentHashMap<>();
    private final Map<UUID, Realm> pendingFinalBreakthrough = new ConcurrentHashMap<>();
    private final Map<UUID, Location> ritualOrigin = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> talismanActive = new ConcurrentHashMap<>();
    private final Map<UUID, BossBar> bars = new ConcurrentHashMap<>();
    private final BukkitTask task;
    private BiConsumer<Player, Realm> completionHandler;

    public TribulationSystem(TuTienCore plugin) {
        this.plugin = plugin;
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    public void setCompletionHandler(BiConsumer<Player, Realm> handler) {
        this.completionHandler = handler;
    }

    public boolean isInTribulation(UUID uuid) {
        return active.containsKey(uuid);
    }

    public boolean isFinalAscent(UUID uuid) {
        return finalAscent.getOrDefault(uuid, false);
    }

    public boolean consumeFinalAscent(UUID uuid) {
        return Boolean.TRUE.equals(finalAscent.remove(uuid));
    }

    public int currentWave(UUID uuid) {
        return wave.getOrDefault(uuid, 0);
    }

    public int currentStrike(UUID uuid) {
        return strikes.getOrDefault(uuid, 0);
    }

    /** Normal breakthrough: one cinematic red lightning strike, weaker than true tribulation. */
    public boolean start(Player player, Realm target) {
        return startInternal(player, target, false, false);
    }

    /** Prepare the Trúc Cơ ritual. The player must explicitly use /dokiep to begin the 9 strikes. */
    public boolean prepareTrucCo(Player player, Realm target) {
        UUID uuid = player.getUniqueId();
        if (active.containsKey(uuid) || pendingFinalBreakthrough.containsKey(uuid)) return false;
        pendingFinalBreakthrough.put(uuid, target);
        beginRitualPose(player, false);
        player.sendTitle("§c§l⚡ THIÊN ĐẠO HỘI TỤ ⚡", "§fDùng §e/dokiep §fđể nghênh đón Thiên Kiếp", 10, 60, 10);
        player.sendMessage("§c⚡ §fĐột phá đã đưa bạn vào vị trí độ kiếp Trúc Cơ.");
        player.sendMessage("§e⚡ §fGõ §e/dokiep §fđể bắt đầu Cửu Thiên Hồng Lôi.");
        dramaticStart(player, true);
        Bukkit.getServer().broadcastMessage("§c§l⚡ " + player.getName() + " §fđang chuẩn bị §cĐỘ KIẾP TRÚC CƠ§f!");
        return true;
    }

    public boolean startPreparedTrucCo(Player player) {
        UUID uuid = player.getUniqueId();
        Realm target = pendingFinalBreakthrough.remove(uuid);
        if (target != Realm.TRUC_CO) return false;
        return startInternal(player, target, true, true);
    }

    public boolean startFinalAscent(Player player) {
        return startInternal(player, Realm.DO_KIEP, true, true);
    }

    /** Starts the Trúc Cơ tribulation directly when the player is Luyện Khí Tầng 10 and full. */
    public boolean startTrucCo(Player player) {
        PlayerData data = plugin.getCultivationService().getPlayerData(player.getUniqueId());
        if (data.realm() != Realm.LUYEN_KHI || data.realmStage() < 10
                || data.linhKhi() < data.nextLinhKhiStageThreshold() || isInTribulation(player.getUniqueId())) return false;
        return startInternal(player, Realm.TRUC_CO, true, false);
    }

    private boolean startInternal(Player player, Realm target, boolean finalStage, boolean alreadyRitual) {
        UUID uuid = player.getUniqueId();
        if (active.containsKey(uuid)) return false;

        active.put(uuid, target);
        PlayerDataHolder.increment(plugin, player);
        wave.put(uuid, 1);
        strikes.put(uuid, 0);
        // Both breakthrough and Trúc Cơ use sequential lightning. Trúc Cơ = 19 waves.
        ticksUntilStrike.put(uuid, 0);
        finalAscent.put(uuid, finalStage);
        if (finalStage && activateBreakthroughTalisman(player)) {
            talismanActive.put(uuid, true);
            player.sendMessage("§b🧿 Phù Đột Phá đã kích hoạt: miễn 8 Hồng Lôi đầu tiên.");
        }
        if (!alreadyRitual) beginRitualPose(player, finalStage);

        int total = finalStage ? finalWaveCount() : breakthroughWaveCount();
        BossBar bar = Bukkit.createBossBar(finalStage ? "§c⚡ THIÊN KIẾP TRÚC CƠ §f| §e1/19" : "§6⚡ HỒNG LÔI ĐỘT PHÁ §f| §e1/9",
                finalStage ? BarColor.RED : BarColor.YELLOW, BarStyle.SEGMENTED_10);
        bar.setProgress(1.0); bar.addPlayer(player); bars.put(uuid, bar);

        Bukkit.getPluginManager().callEvent(new TribulationStartEvent(player, target));
        player.playSound(player, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, finalStage ? 0.45f : 0.8f);
        if (finalStage) {
            player.sendTitle("§c§l⚡ THIÊN KIẾP TRÚC CƠ ⚡", "§f19 đạo Hồng Lôi • mỗi đạo cách nhau 5 giây", 10, 55, 10);
            Bukkit.getServer().broadcastMessage("§c§l⚡ THIÊN KIẾP GIÁNG LÂM ⚡ §f" + player.getName() + " §cĐANG ĐỘ KIẾP TRÚC CƠ!");
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 10.0f, 0.55f);
            for (Player online : Bukkit.getOnlinePlayers()) {
                online.sendTitle("§c§l⚡ THIÊN KIẾP GIÁNG LÂM ⚡", "§f" + player.getName() + " §cĐANG ĐỘ KIẾP TRÚC CƠ", 5, 45, 10);
                online.playSound(online.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.4f, 0.55f);
            }
        } else {
            player.sendTitle("§6§l✦ ĐỘT PHÁ ✦", "§fHồng Lôi đang tôi luyện đạo cơ", 5, 35, 10);
        }
        if (!alreadyRitual) dramaticStart(player, finalStage);
        return true;
    }

    private void beginRitualPose(Player player, boolean finalStage) {
        ritualOrigin.put(player.getUniqueId(), player.getLocation().clone());
        Location up = player.getLocation().clone().add(0, 5.0, 0);
        player.teleport(up);
        player.setGravity(false);
        player.setPose(org.bukkit.entity.Pose.SITTING);
        player.getWorld().spawnParticle(Particle.DUST, up.clone().add(0,1.2,0), 90, 2.5, 2.0, 2.5, 0.02,
                new Particle.DustOptions(Color.fromRGB(255, 35, 35), finalStage ? 2.0f : 1.35f));
        player.getWorld().spawnParticle(Particle.ENCHANT, up.clone().add(0,2,0), finalStage ? 100 : 55, 2.2, 2.5, 2.2, 0.08);
    }

    private void tick() {
        int intervalTicks = Math.max(1, plugin.getConfig().getInt("tribulation.strike-interval-ticks", 100));
        for (UUID uuid : new java.util.HashSet<>(active.keySet())) {
            Player player = plugin.getServer().getPlayer(uuid);
            if (player == null || !player.isOnline() || player.isDead()) { finish(uuid, false); continue; }
            boolean finalStage = isFinalAscent(uuid);
            int remaining = ticksUntilStrike.merge(uuid, -1, Integer::sum);
            lightStormAmbient(player, finalStage);
            updateBossBar(player, uuid);
            if (remaining > 0) { sendActionBar(player, false); continue; }

            // IMPORTANT: both normal Đột Phá and Trúc Cơ must continue to the next strike.
            // The old normal path used Integer.MAX_VALUE here, so it fired once and then got stuck forever.
            ticksUntilStrike.put(uuid, intervalTicks);
            strikeGroup(player, uuid, finalStage);

            int strikeNumber = strikes.getOrDefault(uuid, 0);
            if (strikeNumber >= (finalStage ? finalWaveCount() : breakthroughWaveCount())) {
                finish(uuid, !player.isDead());
            }
            sendActionBar(player, true);
        }
    }

    private void strikeGroup(Player player, UUID uuid, boolean finalStage) {
        int strike = strikes.merge(uuid, 1, Integer::sum);
        PlayerData data = plugin.getCultivationService().getPlayerData(uuid);
        World world = player.getWorld();

        // Hồng Lôi cinematic: red dust, electric sparks, rings, clouds and a direct visual lightning effect.
        int radius = 8;
        strikeVisual(player, radius, finalStage);
        Location body = player.getLocation().clone().add(0, 1.0, 0);
        world.spawnParticle(Particle.DUST, body, finalStage ? 90 : 55, 1.8, 1.8, 1.8, 0.04,
                new Particle.DustOptions(Color.fromRGB(255, 25, 25), finalStage ? 2.2f : 1.35f));
        world.spawnParticle(Particle.ELECTRIC_SPARK, body, finalStage ? 70 : 35, 1.5, 2.0, 1.5, 0.18);
        world.spawnParticle(Particle.SOUL_FIRE_FLAME, body.clone().add(0, 1.5, 0), finalStage ? 45 : 22, 1.2, 1.5, 1.2, 0.04);
        world.spawnParticle(Particle.CLOUD, body.clone().add(0, 5, 0), finalStage ? 35 : 18, 3.2, 0.5, 3.2, 0.02);
        player.playSound(player, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, finalStage ? 1.2f : 0.65f, finalStage ? 0.42f : 0.72f);

        if (plugin.getConfig().getBoolean("tribulation.damage", true)) {
            double hearts;
            if (finalStage) {
                hearts = plugin.getConfig().getDouble("tribulation.final-damage-hearts-start", 0.5D)
                        + (strike - 1) * plugin.getConfig().getDouble("tribulation.final-damage-hearts-step", 0.2D);
                // Phù Đột Phá: miễn 8 đạo đầu, đạo 9 vẫn chịu damage.
                if (Boolean.TRUE.equals(talismanActive.get(uuid)) && strike <= 8) {
                    hearts = 0D;
                    player.sendActionBar("§b🧿 Phù Đột Phá §fđã chặn Hồng Lôi §e" + strike + "/8");
                    world.spawnParticle(Particle.TOTEM_OF_UNDYING, body, 35, 1.0, 1.2, 1.0, 0.05);
                }
            } else {
                int attempts = Math.max(1, data.breakthroughCount());
                hearts = plugin.getConfig().getDouble("breakthrough.lightning.damage-hearts-start", 0.5D)
                        + (attempts - 1) * plugin.getConfig().getDouble("breakthrough.lightning.damage-hearts-step", 0.2D);
            }
            if (hearts > 0) {
                double reduction = plugin.getTechniqueSystem().tribulationReduction(data);
                if (!finalStage) reduction = Math.min(0.25D, reduction);
                player.damage(Math.max(0D, hearts * 2D * (1D - reduction)));
            }
        }

        if (finalStage) {
            player.sendMessage("§c⚡ Hồng Lôi §f" + strike + "/19 §7giáng xuống! §cDamage: §f"
                    + (0.5D + (strike - 1) * 0.2D) + " tim");
        } else {
            player.sendMessage("§6⚡ Hồng Lôi Đột Phá §fgiáng xuống! §7Damage: §c"
                    + (plugin.getConfig().getDouble("breakthrough.lightning.damage-hearts-start", 0.5D)
                    + (Math.max(1, data.breakthroughCount()) - 1) * plugin.getConfig().getDouble("breakthrough.lightning.damage-hearts-step", 0.2D)) + " tim");
        }
    }

    private boolean activateBreakthroughTalisman(Player player) {
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return false;
        if (!"§c§lPhù Đột Phá".equals(item.getItemMeta().getDisplayName())) return false;
        int amount = item.getAmount();
        if (amount <= 1) player.getInventory().setItemInMainHand(null);
        else item.setAmount(amount - 1);
        return true;
    }

    private void strikeVisual(Player player, int radius, boolean finalStage) {
        World world = player.getWorld();

        // FIX: Lôi Kiếp phải giáng đúng vào vị trí người chơi, không spawn
        // ngẫu nhiên cách player nhiều block hoặc cao trên đầu. Bukkit's
        // lightning location là điểm chân tia sét trên mặt đất, nên dùng
        // đúng X/Z và Y hiện tại của player để tia sét chạm vào người.
        Location lightning = player.getLocation().clone();
        lightning.setY(player.getLocation().getY());

        // Effect-only lightning: không tạo thêm damage vanilla. Damage của
        // Lôi Kiếp vẫn được xử lý bởi damage pulse bên dưới.
        world.strikeLightningEffect(lightning);

        // Hiệu ứng hội tụ quanh thân người chơi.
        Location body = player.getLocation().clone().add(0, 1.0, 0);
        world.spawnParticle(Particle.DUST, body, finalStage ? 45 : 24, 0.45, 0.9, 0.45, 0.08,
                new Particle.DustOptions(Color.fromRGB(255, 20, 20), finalStage ? 1.8f : 1.2f));
        world.spawnParticle(Particle.ELECTRIC_SPARK, body, finalStage ? 30 : 16, 0.45, 0.9, 0.45, 0.18);
        // Vòng lôi trận + linh hỏa + nghịch chuyển quanh người chơi.
        for (int ring = 1; ring <= 3; ring++) {
            double r = ring * 1.15;
            for (int k = 0; k < 18; k++) {
                double a = (Math.PI * 2D * k / 18D) + (System.nanoTime() / 1.0E9D * 0.35D);
                Location q = body.clone().add(Math.cos(a) * r, (ring - 2) * 0.55, Math.sin(a) * r);
                world.spawnParticle(ring == 3 ? Particle.REVERSE_PORTAL : Particle.SOUL_FIRE_FLAME, q, 1, 0, 0, 0, 0);
            }
        }
        world.spawnParticle(Particle.ENCHANT, body.clone().add(0, 2.2, 0), 24, 0.8, 1.5, 0.8, 0.12);
    }

    private void lightStormAmbient(Player player, boolean finalStage) {
        if (!plugin.getConfig().getBoolean("tribulation.visual-storm", true)) return;
        if (player.getTicksLived() % 4 != 0) return;

        Location center = player.getLocation().clone().add(0, 12.0, 0);
        World world = player.getWorld();
        int points = finalStage ? 22 : 14;
        double radius = plugin.getConfig().getDouble("tribulation.storm-radius", 200.0D);
        long seed = System.nanoTime() / 50_000_000L;
        for (int i = 0; i < points; i++) {
            double a = (i * Math.PI * 2D / points) + (seed * 0.012D);
            double r = radius * (0.45D + ((i * 37L) % 55L) / 100.0D);
            Location q = center.clone().add(Math.cos(a) * r, Math.sin(a * 2.7D + seed) * 2.5D, Math.sin(a) * r);
            world.spawnParticle(Particle.CLOUD, q, 2, 4.0, 1.0, 4.0, 0.01);
            world.spawnParticle(Particle.DUST, q, 1, 3.0, 1.2, 3.0, 0.02,
                    new Particle.DustOptions(Color.fromRGB(18, 18, 24), finalStage ? 2.0f : 1.5f));
            world.spawnParticle(Particle.DUST, q.clone().add(0, -1.5, 0), 1, 3.0, 0.8, 3.0, 0.02,
                    new Particle.DustOptions(Color.fromRGB(255, 25, 25), finalStage ? 1.8f : 1.3f));
        }
    }

    private void waveBurst(Player player, boolean finalStage) {
        World world = player.getWorld();
        Location center = player.getLocation().clone().add(0, 2.5, 0);
        world.spawnParticle(Particle.DUST, center, 36, 2.8, 2.0, 2.8, 0.12,
                new Particle.DustOptions(finalStage ? Color.fromRGB(255, 40, 40) : Color.fromRGB(255, 120, 30), finalStage ? 1.6f : 1.2f));
        world.spawnParticle(Particle.DUST, center, 18, 1.5, 1.2, 1.5, 0,
                new Particle.DustOptions(
                        finalStage ? Color.fromRGB(220, 90, 255) : Color.fromRGB(95, 145, 255),
                        finalStage ? 1.5f : 1.2f
                ));
    }

    private void dramaticStart(Player player, boolean finalStage) {
        waveBurst(player, finalStage);
        player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation().clone().add(0, 6, 0), 55, 4.5, 0.9, 4.5, 0.03);
        player.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, player.getLocation().clone().add(0, 1.5, 0), 40, 2.8, 1.5, 2.8, 0.04);
        player.getWorld().spawnParticle(Particle.REVERSE_PORTAL, player.getLocation().clone().add(0, 3, 0), 45, 3.5, 2.0, 3.5, 0.08);
        player.playSound(player, Sound.ENTITY_WITHER_SPAWN, 0.45f, 1.45f);
    }

    private void sendActionBar(Player player, boolean strikeHappened) {
        UUID uuid = player.getUniqueId();
        int s = strikes.getOrDefault(uuid, 0);
        boolean finalStage = isFinalAscent(uuid);
        player.sendActionBar(finalStage
                ? "§c⚡ Thiên Kiếp Trúc Cơ §f" + s + "/19 §7| mỗi sét cách nhau 5 giây"
                : "§6⚡ Đột Phá §f" + s + "/9 §7| mỗi sét cách nhau 5 giây");
    }

    private void updateBossBar(Player player, UUID uuid) {
        BossBar bar = bars.get(uuid); if (bar == null) return;
        boolean finalStage = isFinalAscent(uuid);
        int s = strikes.getOrDefault(uuid, 0);
        double total = finalStage ? finalWaveCount() : breakthroughWaveCount();
        bar.setProgress(Math.max(0.001D, Math.min(1D, 1D - ((double) s / total))));
        bar.setTitle(finalStage ? "§c⚡ THIÊN KIẾP TRÚC CƠ §f| §e" + s + "/19" : "§6⚡ ĐỘT PHÁ §f| §e" + s + "/9");
    }

    private int breakthroughWaveCount() { return Math.max(1, plugin.getConfig().getInt("tribulation.breakthrough-wave-count", 9)); }
    private int finalWaveCount() { return Math.max(1, plugin.getConfig().getInt("tribulation.final-wave-count", 19)); }
    private int waveCount() { return finalWaveCount(); }
    private int strikesPerWave() { return 1; }

    /** Kept for compatibility with older effects code. */
    public void breakthroughStorm(Player player) {
        if (!plugin.getConfig().getBoolean("tribulation.breakthrough-storm", true)) return;
        waveBurst(player, false);
        player.sendActionBar("§5⚡ §dThiên Lôi giáng thế — Đột Phá thành công!");
    }

    private void finish(UUID uuid, boolean survival) {
        Realm target = active.remove(uuid);
        boolean finale = isFinalAscent(uuid);
        wave.remove(uuid);
        strikes.remove(uuid);
        ticksUntilStrike.remove(uuid);
        BossBar oldBar = bars.remove(uuid); if (oldBar != null) oldBar.removeAll();
        pendingFinalBreakthrough.remove(uuid);
        talismanActive.remove(uuid);

        Player player = plugin.getServer().getPlayer(uuid);
        if (target == null) {
            finalAscent.remove(uuid);
            restoreRitualPose(player);
            return;
        }

        Bukkit.getPluginManager().callEvent(new TribulationCompleteEvent(player, target, survival));

        if (player != null && survival) {
            waveBurst(player, finale);
            if (finale) {
                player.sendTitle("§d§l✦ THIÊN KIẾP VƯỢT QUA ✦", "§fCửu Lôi đã tan biến", 10, 60, 20);
                player.playSound(player, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 0.7f);
            } else {
                player.sendTitle("§6§l✦ CỬU LÔI VƯỢT QUA ✦", "§fThiên kiếp hoàn tất", 8, 45, 15);
            }
        } else if (player != null) {
            player.sendMessage("§c✦ Thiên Kiếp thất bại vì bạn đã không thể vượt qua Cửu Lôi.");
        }

        if (player != null) restoreRitualPose(player);
        if (player != null && survival && completionHandler != null) {
            completionHandler.accept(player, target);
        }
        finalAscent.remove(uuid);
    }

    private void restoreRitualPose(Player player) {
        if (player == null) return;
        UUID uuid = player.getUniqueId();
        Location origin = ritualOrigin.remove(uuid);
        player.setGravity(true);
        player.setPose(org.bukkit.entity.Pose.STANDING);
        player.setFallDistance(0.0f);
        player.setVelocity(new org.bukkit.util.Vector(0, 0, 0));
        if (origin != null && player.isOnline() && !player.isDead()) player.teleport(origin);
    }

    /** Clean up all ritual state when the plugin/server is disabled or reloaded. */
    public void shutdown() {
        if (task != null) task.cancel();
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            UUID uuid = player.getUniqueId();
            if (active.containsKey(uuid) || pendingFinalBreakthrough.containsKey(uuid) || ritualOrigin.containsKey(uuid)) {
                forceRestorePlayer(player);
            }
        }
        active.clear();
        finalAscent.clear();
        wave.clear();
        strikes.clear();
        ticksUntilStrike.clear();
        pendingFinalBreakthrough.clear();
        talismanActive.clear();
        for (BossBar bar : bars.values()) bar.removeAll();
        bars.clear();
        ritualOrigin.clear();
    }

    /** Emergency recovery for players left floating by an interrupted old ritual. */
    public void forceRestorePlayer(Player player) {
        if (player == null) return;
        UUID uuid = player.getUniqueId();
        active.remove(uuid);
        finalAscent.remove(uuid);
        wave.remove(uuid);
        strikes.remove(uuid);
        ticksUntilStrike.remove(uuid);
        pendingFinalBreakthrough.remove(uuid);
        talismanActive.remove(uuid);
        BossBar oldBar = bars.remove(uuid);
        if (oldBar != null) oldBar.removeAll();
        restoreRitualPose(player);
        player.sendMessage("§a✦ Đã khôi phục trọng lực và thoát trạng thái Đột Phá/Độ Kiếp.");
    }

    private static final class PlayerDataHolder {
        static void increment(TuTienCore plugin, Player player) {
            PlayerData data = plugin.getCultivationService().getPlayerData(player.getUniqueId());
            int count = data.incrementTribulationCount();
            plugin.getCultivationService().save(player.getUniqueId());
            player.sendMessage("§5⚡ §dĐộ khó Thiên Kiếp hiện tại: §f" + count
                    + "§7 — mỗi lần /dotpha tiếp theo sẽ mạnh hơn.");
        }
    }

}
