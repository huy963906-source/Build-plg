package com.tcgame.tutiencore.quest;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.cultivation.Realm;
import com.tcgame.tutiencore.spiritroot.SpiritRootRerollService;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import java.util.List;

/** Luồng nhập môn: Đá Cao Cấp -> Trưởng Lão -> Luyện Khí Quyết -> mở khóa -> reroll linh căn. */
public final class InitiationSystem {
    private final TuTienCore plugin;
    private final NamespacedKey bookKey;
    private final SpiritRootRerollService reroller;

    public SpiritRootRerollService getReroller() { return reroller; }

    public InitiationSystem(TuTienCore plugin) {
        this.plugin = plugin;
        this.bookKey = new NamespacedKey(plugin, "luyen_khi_quyet");
        this.reroller = new SpiritRootRerollService(plugin);
    }

    public void handleElderInteraction(PlayerInteractEntityEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Entity entity = event.getRightClicked();
        if (!isConfiguredElder(entity)) return;
        Player player = event.getPlayer();
        PlayerData data = plugin.getCultivationService().getPlayerData(player.getUniqueId());
        ItemStack held = player.getInventory().getItemInMainHand();
        if (!data.luyenKhi1Unlocked() && isAdvancedStone(held)) {
            ItemStack book = createLuyenKhiBook();
            if (player.getInventory().firstEmpty() == -1) {
                player.sendMessage("§c✦ Túi đồ đầy, hãy chừa 1 ô trống để nhận Luyện Khí Quyết.");
                return;
            }
            consumeOne(player);
            player.getInventory().addItem(book);
            player.sendMessage("§a✦ Đã đổi §bĐá Cao Cấp §alấy §dLuyện Khí Quyết§a.");
            player.sendMessage("§7Chuột phải §dLuyện Khí Quyết §7để khai mở tu luyện.");
            event.setCancelled(true);
        }
    }

    public void handleBookUse(Player player, ItemStack item) {
        if (!isLuyenKhiBook(item)) return;
        if (unlock(player, true)) consumeOne(player);
    }

    /** Admin/quest bridge: unlocks Luyện Khí Tầng 1, grants 1000 Linh Khí and rerolls the root. */
    public boolean unlock(Player player, boolean notify) {
        PlayerData data = plugin.getCultivationService().getPlayerData(player.getUniqueId());
        if (data.luyenKhi1Unlocked()) return false;
        if (plugin.getTrainingManager() != null && plugin.getTrainingManager().isTraining(player.getUniqueId())) {
            plugin.getTrainingManager().stop(player);
        }
        data.luyenKhi1Unlocked(true);
        data.realm(Realm.LUYEN_KHI);
        data.realmStage(1);
        data.linhKhi(1000D);
        reroller.reroll(data);
        plugin.getCultivationService().save(player.getUniqueId());

        if (notify) {
            String roots = data.spiritRoots().isEmpty() ? "Biến Dị" : data.spiritRoots().stream().map(r -> r.displayName()).reduce((a,b) -> a + ", " + b).orElse("Biến Dị");
            player.sendMessage("§5§l✦ LINH CĂN THỨC TỈNH ✦");
            player.sendMessage("§7Phẩm chất: §f" + data.spiritRootQuality().displayName());
            player.sendMessage("§7Linh Căn: §f" + roots);
            player.sendMessage("§7Tốc độ linh căn: §bx" + trim(data.spiritRootQuality().trainingMultiplier()));
            player.sendMessage("§a✦ Cảnh Giới: §eLuyện Khí Tầng 1");
            player.sendMessage("§b✦ Nhận §f1000 Linh Khí§b.");
        }
        return true;
    }

    public boolean isLuyenKhiBook(ItemStack item) {
        if (item == null || item.getType() != Material.ENCHANTED_BOOK) return false;
        ItemMeta meta = item.getItemMeta();
        return meta != null && meta.getPersistentDataContainer().has(bookKey, PersistentDataType.BYTE);
    }

    public ItemStack createLuyenKhiBook() {
        ItemStack book = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta meta = book.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(plugin.getConfig().getString("initiation.luyen-khi-book.name", "&dLuyện Khí Quyết")));
            meta.setLore(List.of(color("&7Pháp quyết nhập môn."), color("&eChuột phải để khai mở tu luyện."), color("&8Khi khai mở sẽ reroll linh căn.")));
            meta.getPersistentDataContainer().set(bookKey, PersistentDataType.BYTE, (byte) 1);
            book.setItemMeta(meta);
        }
        return book;
    }

    private boolean isAdvancedStone(ItemStack item) {
        if (item == null || item.getType() != configuredStoneMaterial()) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        String expected = color(plugin.getConfig().getString("initiation.advanced-stone.name", "&bĐá Cao Cấp"));
        if (!expected.equals(meta.getDisplayName())) return false;
        return !plugin.getConfig().getBoolean("initiation.advanced-stone.require-enchanted", true) || !meta.getEnchants().isEmpty();
    }

    private Material configuredStoneMaterial() {
        try { return Material.valueOf(plugin.getConfig().getString("initiation.advanced-stone.material", "STONE").toUpperCase()); }
        catch (IllegalArgumentException e) { return Material.STONE; }
    }

    private boolean isConfiguredElder(Entity entity) {
        String actual = entity.getCustomName();
        if (actual == null) return false;
        actual = ChatColor.stripColor(actual).trim();
        for (String raw : plugin.getConfig().getStringList("initiation.elder-names")) {
            if (actual.equalsIgnoreCase(ChatColor.stripColor(color(raw)).trim())) return true;
        }
        return false;
    }

    private static void consumeOne(Player p) {
        ItemStack item = p.getInventory().getItemInMainHand();
        if (item.getAmount() <= 1) p.getInventory().setItemInMainHand(null);
        else item.setAmount(item.getAmount() - 1);
    }
    private static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
    private static String trim(double x) { return Math.rint(x) == x ? Long.toString((long)x) : String.format(java.util.Locale.ROOT, "%.2f", x); }
}
