package com.tcgame.tutiencore.quest;

import com.tcgame.tutiencore.TuTienCore;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.persistence.PersistentDataType;

public final class AutoQuestSystem implements Listener {
    private final TuTienCore plugin;
    private final NamespacedKey questNpcKey;

    public AutoQuestSystem(TuTienCore plugin) {
        this.plugin = plugin;
        this.questNpcKey = new NamespacedKey(plugin, "autoquest_elder");
    }

    public void spawnQuestElder(Player p) {
        Location loc = p.getLocation().clone();
        org.bukkit.util.Vector dir = loc.getDirection().setY(0).normalize();
        if (dir.lengthSquared() < 0.01) dir = new org.bukkit.util.Vector(0, 0, 1);
        Location spawn = loc.clone().add(dir.multiply(2.0));
        spawn.setY(p.getLocation().getY());

        Villager elder = (Villager) p.getWorld().spawnEntity(spawn, EntityType.VILLAGER);
        elder.setCustomName("§6§lTrưởng Lão");
        elder.setCustomNameVisible(true);
        elder.setAI(false);
        elder.setInvulnerable(true);
        elder.setSilent(true);
        elder.setCollidable(false);
        elder.setProfession(Villager.Profession.LIBRARIAN);
        elder.setVillagerLevel(5);
        elder.getPersistentDataContainer().set(questNpcKey, PersistentDataType.BYTE, (byte)1);

        p.sendMessage("§6✦ Trưởng Lão §fđã xuất hiện cách bạn §e2 block§f.");
        p.sendMessage("§7Nhấn chuột phải vào Trưởng Lão để nhận nhiệm vụ có sẵn.");
    }

    public void removeNearbyQuestElders(Player p) {
        int removed = 0;
        for (Entity e : p.getWorld().getNearbyEntities(p.getLocation(), 8, 8, 8)) {
            if (isQuestElder(e)) { e.remove(); removed++; }
        }
        p.sendMessage("§7Đã xóa §f" + removed + " §7Trưởng Lão gần bạn.");
    }

    public boolean isQuestElder(Entity e) {
        return e.getPersistentDataContainer().has(questNpcKey, PersistentDataType.BYTE);
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent e) {
        if (!isQuestElder(e.getRightClicked())) return;
        e.setCancelled(true);
        plugin.getQuestMenu().open(e.getPlayer());
    }
}
