package com.tcgame.tutiencore.quest;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.WeekFields;
import java.util.Locale;
import org.bukkit.entity.Player;

/** Daily/weekly cultivation quests. Intro progression is handled by InitiationSystem + NPC/item interactions. */
public final class QuestSystem {
    private final TuTienCore plugin;
    public QuestSystem(TuTienCore plugin) { this.plugin = plugin; }

    public void addTrainingTime(Player player, long seconds) {
        PlayerData d = plugin.getCultivationService().getPlayerData(player.getUniqueId());
        resetPeriods(d);
        d.dailyTrainingSeconds(d.dailyTrainingSeconds() + Math.max(0, seconds));
        d.weeklyTrainingSeconds(d.weeklyTrainingSeconds() + Math.max(0, seconds));
    }

    public long dayKeyPublic() { return dayKey(); }
    public long weekKeyPublic() { return weekKey(); }

    private long dayKey() { return LocalDate.now(ZoneId.systemDefault()).toEpochDay(); }
    private long weekKey() {
        LocalDate now = LocalDate.now(ZoneId.systemDefault());
        WeekFields wf = WeekFields.of(Locale.getDefault());
        return now.getYear() * 100L + now.get(wf.weekOfWeekBasedYear());
    }

    private void resetPeriods(PlayerData d) {
        long day = dayKey(), week = weekKey();
        if (d.dailyProgressDay() != day) { d.dailyProgressDay(day); d.dailyTrainingSeconds(0); d.dailyQuestClaim(0); }
        if (d.weeklyProgressKey() != week) { d.weeklyProgressKey(week); d.weeklyTrainingSeconds(0); d.weeklyQuestClaim(0); }
    }

    public String summary(Player player) {
        PlayerData d = plugin.getCultivationService().getPlayerData(player.getUniqueId());
        resetPeriods(d);
        return "§eNhiệm vụ ngày: §f" + Math.min(600, d.dailyTrainingSeconds()) + "/600s §7| §bTuần: §f" + Math.min(3600, d.weeklyTrainingSeconds()) + "/3600s";
    }

    public boolean claim(Player player, String type) {
        PlayerData d = plugin.getCultivationService().getPlayerData(player.getUniqueId());
        resetPeriods(d);
        if (type.equalsIgnoreCase("daily")) {
            if (d.dailyTrainingSeconds() < 600 || d.dailyQuestClaim() == dayKey()) return false;
            d.dailyQuestClaim(dayKey()); d.addLinhKhi(250);
            player.sendMessage("§aĐã nhận thưởng nhiệm vụ ngày: +250 Linh Khí");
            return true;
        }
        if (d.weeklyTrainingSeconds() < 3600 || d.weeklyQuestClaim() == weekKey()) return false;
        d.weeklyQuestClaim(weekKey()); d.addLinhKhi(3000);
        player.sendMessage("§aĐã nhận thưởng nhiệm vụ tuần: +3000 Linh Khí");
        return true;
    }
}
