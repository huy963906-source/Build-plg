package com.tcgame.tutiencore.anticheat;

import com.tcgame.tutiencore.TuTienCore;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import java.util.*;

public final class AntiCheatMenu implements Listener {
    public static final String TITLE="§c§l✦ ANTICHEAT CONTROL ✦";
    private final TuTienCore plugin;
    public AntiCheatMenu(TuTienCore plugin){this.plugin=plugin;}
    public void open(Player p){
        Inventory inv=Bukkit.createInventory(null,54,TITLE);
        fill(inv,Material.BLACK_STAINED_GLASS_PANE," ");
        boolean enabled=plugin.getConfig().getBoolean("anticheat.enabled",true);
        inv.setItem(4,item(enabled?Material.LIME_DYE:Material.RED_DYE,enabled?"§a§lANTICHEAT: BẬT":"§c§lANTICHEAT: TẮT",List.of("§eClick để bật/tắt toàn bộ hệ thống")));
        inv.setItem(10,item(Material.IRON_SWORD,"§c§lReach",List.of("§7Giới hạn: §f"+plugin.getConfig().getDouble("anticheat.max-entity-reach",6D)+" block")));
        inv.setItem(12,item(Material.FEATHER,"§b§lSpeed",List.of("§7Ground: §f"+plugin.getConfig().getDouble("anticheat.max-ground-speed",14D),"§7Air: §f"+plugin.getConfig().getDouble("anticheat.max-air-speed",22D))));
        inv.setItem(14,item(Material.ELYTRA,"§d§lMovement Check",List.of("§7Phát hiện di chuyển bất thường")));
        inv.setItem(16,item(Material.REDSTONE,"§e§lNgưỡng Flag",List.of("§7VL hiện tại của người chơi bên dưới")));
        int slot=28;
        List<Player> players=new ArrayList<>(Bukkit.getOnlinePlayers());
        players.sort(Comparator.comparingInt((Player x)->plugin.getAntiCheatSystem().violations(x.getUniqueId())).reversed());
        for(Player t:players){if(slot>=53)break; if(slot%9==8)slot++; int vl=plugin.getAntiCheatSystem().violations(t.getUniqueId()); inv.setItem(slot++,item(vl>=3?Material.REDSTONE_BLOCK:Material.PLAYER_HEAD,"§f"+t.getName(),List.of("§7Violation Level: §c"+vl,"§eClick: kick nếu VL ≥ ngưỡng")));}
        inv.setItem(49,item(Material.BARRIER,"§cĐóng",List.of()));
        p.openInventory(inv);
    }
    @EventHandler public void click(InventoryClickEvent e){
        if(!TITLE.equals(e.getView().getTitle())||!(e.getWhoClicked() instanceof Player p))return;e.setCancelled(true);
        if(e.getRawSlot()==4){boolean n=!plugin.getConfig().getBoolean("anticheat.enabled",true);plugin.getConfig().set("anticheat.enabled",n);plugin.saveConfig();p.sendMessage("§cAntiCheat: "+(n?"§aBẬT":"§cTẮT"));open(p);return;}
        if(e.getRawSlot()==49){p.closeInventory();return;}
        ItemStack i=e.getCurrentItem();if(i==null||!i.hasItemMeta()||i.getItemMeta().getDisplayName()==null)return;
        String name=org.bukkit.ChatColor.stripColor(i.getItemMeta().getDisplayName()); Player t=Bukkit.getPlayerExact(name);
        if(t!=null){int vl=plugin.getAntiCheatSystem().violations(t.getUniqueId());p.sendMessage("§e"+t.getName()+" đang có VL §f"+vl+"§e. AntiCheat chỉ cảnh báo; không tự động kick/ban để tránh phạt nhầm.");plugin.getAntiCheatSystem().clearViolations(t.getUniqueId());p.sendMessage("§aĐã xóa VL của §f"+t.getName()+"§a. Kiểm tra log/các plugin movement trước khi xử lý.");open(p);}
    }
    @EventHandler public void drag(InventoryDragEvent e){if(TITLE.equals(e.getView().getTitle()))e.setCancelled(true);}
    private static ItemStack item(Material m,String n,List<String> lore){ItemStack i=new ItemStack(m);ItemMeta meta=i.getItemMeta();if(meta!=null){meta.setDisplayName(n);meta.setLore(lore);i.setItemMeta(meta);}return i;}
    private static void fill(Inventory inv,Material m,String n){ItemStack i=item(m,n,List.of());for(int x=0;x<inv.getSize();x++)inv.setItem(x,i.clone());}
}
