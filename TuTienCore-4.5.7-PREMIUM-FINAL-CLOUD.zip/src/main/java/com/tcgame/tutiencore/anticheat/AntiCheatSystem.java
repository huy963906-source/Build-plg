package com.tcgame.tutiencore.anticheat;

import com.tcgame.tutiencore.TuTienCore;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Lightweight detection only; no automatic punishments. */
public final class AntiCheatSystem implements Listener {
    private final TuTienCore plugin;
    private final Map<UUID, Sample> samples = new HashMap<>();
    private final Map<UUID, Integer> violations = new HashMap<>();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Map<UUID, Long> ignoreUntil = new HashMap<>();
    private final BukkitTask cleanup;

    public AntiCheatSystem(TuTienCore plugin) {
        this.plugin = plugin;
        cleanup = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            long now = System.currentTimeMillis();
            cooldowns.entrySet().removeIf(e -> e.getValue() < now);
            ignoreUntil.entrySet().removeIf(e -> e.getValue() < now);
            samples.entrySet().removeIf(e -> {
                Player p = plugin.getServer().getPlayer(e.getKey());
                return p == null || !p.isOnline();
            });
        }, 20L * 60L, 20L * 60L);
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (!enabled() || bypass(p) || ignoredMovement(p) || e.getTo() == null) return;
        UUID id = p.getUniqueId();
        long wallNow = System.currentTimeMillis();
        if (ignoreUntil.getOrDefault(id, 0L) > wallNow) {
            samples.put(id, new Sample(e.getTo().clone(), System.nanoTime()));
            return;
        }
        long now = System.nanoTime();
        Sample old = samples.get(id);
        if (old == null) { samples.put(id, new Sample(e.getTo().clone(), now)); return; }
        double dt = (now - old.nanoTime()) / 1_000_000_000D;
        // PlayerMoveEvent fires for tiny packet-level rotations and sub-tick moves.
        // Keep the original sample until enough time has elapsed to avoid huge false speeds.
        if (dt < 0.12D) return;
        samples.put(id, new Sample(e.getTo().clone(), now));
        if (dt > 1.25D || !old.location().getWorld().equals(e.getTo().getWorld())) return;
        // Plugin skills, knockback, pistons, slime, riptide and server velocity all cause legitimate bursts.
        if (p.getVelocity().lengthSquared() > 0.36D || p.isInsideVehicle()) return;
        double dx = e.getTo().getX() - old.location().getX();
        double dz = e.getTo().getZ() - old.location().getZ();
        double speed = Math.sqrt(dx * dx + dz * dz) / dt;
        double limit = p.isOnGround()
                ? plugin.getConfig().getDouble("anticheat.max-ground-speed", 16.0D)
                : plugin.getConfig().getDouble("anticheat.max-air-speed", 25.0D);
        if (speed > limit) flag(p, "SPEED", String.format(java.util.Locale.ROOT, "%.1f b/s > %.1f", speed, limit));
        // Removed heuristic FLY flag: flat vertical movement alone is not reliable evidence of cheating.
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        ignoreUntil.put(id, System.currentTimeMillis() + 1800L);
        samples.remove(id);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        samples.remove(id); violations.remove(id); cooldowns.remove(id); ignoreUntil.remove(id);
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityReach(PlayerInteractEntityEvent e) {
        Player p = e.getPlayer();
        if (!enabled() || bypass(p) || ignoredMovement(p)) return;
        double max = plugin.getConfig().getDouble("anticheat.max-entity-reach", 6.0D);
        if (p.getEyeLocation().distanceSquared(e.getRightClicked().getLocation()) > max * max) {
            flag(p, "REACH", String.format(java.util.Locale.ROOT, "distance > %.1f", max));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockReach(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        if (!enabled() || bypass(p) || ignoredMovement(p) || e.getAction() != Action.LEFT_CLICK_BLOCK || e.getClickedBlock() == null) return;
        double max = plugin.getConfig().getDouble("anticheat.max-block-reach", 6.0D);
        if (p.getEyeLocation().distanceSquared(e.getClickedBlock().getLocation().add(0.5, 0.5, 0.5)) > max * max) {
            flag(p, "REACH", String.format(java.util.Locale.ROOT, "block distance > %.1f", max));
        }
    }

    private boolean ignoredMovement(Player p) {
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR || p.isGliding()) return true;
        if (plugin.getNguKiemService() != null && plugin.getNguKiemService().isFlying(p)) return true;
        if (p.hasPotionEffect(PotionEffectType.SPEED) || p.hasPotionEffect(PotionEffectType.LEVITATION) || p.hasPotionEffect(PotionEffectType.JUMP_BOOST)) return true;
        return p.isInsideVehicle();
    }

    public int violations(UUID uuid){ return violations.getOrDefault(uuid,0); }
    public void clearViolations(UUID uuid){ violations.remove(uuid); }

    public boolean bypass(Player p) {
        if (p.isOp() || p.hasPermission("tutien.admin") || p.hasPermission("admin") || p.hasPermission("mod") || p.hasPermission("group.admin") || p.hasPermission("group.mod")) return true;
        if (!plugin.getConfig().getBoolean("anticheat.luckperms-staff-bypass", true)) return false;
        try {
            Class<?> provider = Class.forName("net.luckperms.api.LuckPermsProvider");
            Object api = provider.getMethod("get").invoke(null);
            Object userManager = api.getClass().getMethod("getUserManager").invoke(api);
            Method getUser = userManager.getClass().getMethod("getUser", UUID.class);
            Object user = getUser.invoke(userManager, p.getUniqueId());
            if (user == null) return false;
            String group = String.valueOf(user.getClass().getMethod("getPrimaryGroup").invoke(user));
            return group.equalsIgnoreCase("mod") || group.equalsIgnoreCase("admin");
        } catch (Throwable ignored) {
            return false;
        }
    }

    private void flag(Player p, String check, String detail) {
        int vl = violations.merge(p.getUniqueId(), 1, Integer::sum);
        int threshold = Math.max(1, plugin.getConfig().getInt("anticheat.alert-threshold", 3));
        if (vl < threshold) return;
        long now = System.currentTimeMillis();
        long last = cooldowns.getOrDefault(p.getUniqueId(), 0L);
        if (now - last < plugin.getConfig().getLong("anticheat.alert-cooldown-ms", 5000L)) return;
        cooldowns.put(p.getUniqueId(), now);
        String msg = "§c[TuTienCore AntiCheat] §f" + p.getName() + " §7| §e" + check + " §7| " + detail + " §8(VL " + vl + ")";
        String[] owners = plugin.getConfig().getStringList("anticheat.alert-players").toArray(String[]::new);
        if (owners.length == 0) owners = new String[]{"zyas", "XuanHai26", "tamismeYT"};
        for (String name : owners) {
            Player receiver = plugin.getServer().getPlayerExact(name);
            if (receiver != null && receiver.isOnline()) receiver.sendMessage(msg);
        }
    }

    private boolean enabled() { return plugin.getConfig().getBoolean("anticheat.enabled", true); }

    public void shutdown() {
        cleanup.cancel();
        samples.clear();
        ignoreUntil.clear();
        violations.clear();
        cooldowns.clear();
    }

    private record Sample(org.bukkit.Location location, long nanoTime) {}
}
