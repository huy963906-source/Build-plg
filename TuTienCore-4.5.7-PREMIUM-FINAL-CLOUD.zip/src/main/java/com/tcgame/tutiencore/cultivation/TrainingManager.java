package com.tcgame.tutiencore.cultivation;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.artifact.ArtifactSystem;
import com.tcgame.tutiencore.pet.PetSystem;
import com.tcgame.tutiencore.quest.QuestSystem;
import com.tcgame.tutiencore.technique.TechniqueSystem;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * GSit-backed cultivation sessions.
 *
 * Timing is deliberately based on monotonic real elapsed time (nanoTime), not server ticks
 * and not a speed multiplier. A 320s cycle therefore really takes ~200 real seconds.
 * Cultivation bonuses affect the reward, while the countdown remains honest.
 */
public final class TrainingManager {
    private final TuTienCore plugin;
    private final GsitBridge gsit;
    private final LinhMachService linhMach;
    private final TechniqueSystem technique;
    private final ArtifactSystem artifact;
    private final PetSystem pet;
    private final QuestSystem quest;
    private final LinhZoneManager linhZone;

    private final Map<UUID, Long> activeStarted = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastNanos = new ConcurrentHashMap<>();
    private final Map<UUID, Double> elapsedSeconds = new ConcurrentHashMap<>();
    private final Map<UUID, Double> herbProgress = new ConcurrentHashMap<>();
    private final BukkitTask task;

    public TrainingManager(TuTienCore plugin, GsitBridge gsit, LinhMachService linhMach,
                           TechniqueSystem technique, ArtifactSystem artifact, PetSystem pet, QuestSystem quest) {
        this.plugin = plugin;
        this.gsit = gsit;
        this.linhMach = linhMach;
        this.technique = technique;
        this.artifact = artifact;
        this.pet = pet;
        this.quest = quest;
        this.linhZone = new LinhZoneManager(plugin);

        // Run often enough to keep the UI and particles smooth, but use wall-clock elapsed
        // time for the actual cultivation timer so lag cannot make seconds disappear.
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 2L, 2L);
    }

    public boolean isTraining(UUID uuid) { return activeStarted.containsKey(uuid); }

    public long cycleSeconds(PlayerData d) {
        long base = Math.max(1L, plugin.getConfig().getLong("training.base-cycle-seconds", 200L));
        long reduction = Math.max(0L, plugin.getConfig().getLong("ranks.training-seconds-per-rank", 10L));
        return Math.max(1L, base - ((long) Math.max(0, d.rankLevel() - 1) * reduction));
    }

    /**
     * Training multipliers no longer make the countdown run 2x/10x faster.
     * They are applied to the Linh Khí reward instead, keeping the displayed seconds real.
     */
    public double speedMultiplier(Player p) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        double multiplier = 1D;
        multiplier *= plugin.getRankSystem().cultivationMultiplier(d.rankLevel());
        multiplier *= d.spiritRootQuality().trainingMultiplier();
        multiplier *= technique.cultivationMultiplier(d);
        multiplier *= artifact.cultivationMultiplier(d);
        multiplier *= pet.cultivationMultiplier(d);
        if (d.hasAlchemyBuff()) multiplier *= d.alchemyMultiplier();
        multiplier *= 1D + Math.max(0D, d.tamPhapLevel()) * 0.03D;
        multiplier *= 1D + Math.max(0D, d.canCot() - 1D) * 0.005D;
        multiplier *= 1D + Math.max(0D, d.ngoTinh() - 1D) * 0.005D;
        return Math.max(1D, multiplier);
    }

    public boolean start(Player p) {
        UUID uuid = p.getUniqueId();
        if (isTraining(uuid)) return false;

        PlayerData d = plugin.getCultivationService().getPlayerData(uuid);
        if (isDemonic(d)) {
            p.sendMessage("§c✦ Ma Tu và Quỷ Tu không tu luyện bằng ngồi thiền. Hãy săn Mobs/Player để hấp thụ Linh Khí.");
            return false;
        }
        String requiredName = plugin.getConfig().getString("training.required-realm", "LUYEN_KHI");
        Realm requiredRealm = Realm.byName(requiredName);
        if (requiredRealm == null) requiredRealm = Realm.LUYEN_KHI;
        if (d.realm().ordinal() < requiredRealm.ordinal()) {
            p.sendMessage("§c✦ Bạn chưa bước vào §e" + requiredRealm.displayName() + "§c. Hãy hoàn thành nhiệm vụ nhập môn trước khi tu luyện.");
            return false;
        }
        if (!plugin.getConfig().getBoolean("training.allow-in-combat", false) && p.getNoDamageTicks() > 0) {
            p.sendMessage("§cKhông thể tu luyện ngay sau khi giao chiến.");
            return false;
        }
        if (!gsit.sit(p)) {
            p.sendMessage("§cKhông thể tạo ghế GSit ở vị trí hiện tại.");
            return false;
        }

        long now = System.nanoTime();
        activeStarted.put(uuid, System.currentTimeMillis());
        lastNanos.put(uuid, now);
        elapsedSeconds.put(uuid, 0D);
        herbProgress.put(uuid, 0D);
        d.trainingSessionStarted(System.currentTimeMillis());

        p.sendMessage("§b✦ Bắt đầu tu luyện. §7Đứng lên sẽ dừng tu luyện.");
        p.playSound(p, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.7f, 1.2f);
        return true;
    }

    private boolean isDemonic(PlayerData d) { return d.cultivationClass().equalsIgnoreCase("MA_TU") || d.cultivationClass().equalsIgnoreCase("QUY_TU"); }

    public void stop(Player p) {
        UUID uuid = p.getUniqueId();
        if (activeStarted.remove(uuid) != null) {
            lastNanos.remove(uuid);
            elapsedSeconds.remove(uuid);
            herbProgress.remove(uuid);
            PlayerData d = plugin.getCultivationService().getPlayerData(uuid);
            d.trainingSessionStarted(0);
            gsit.stop(p);
            plugin.getCultivationService().save(uuid);
            p.sendMessage("§7✦ Bạn đã kết thúc tu luyện.");
        }
    }

    private void tick() {
        final long nowNanos = System.nanoTime();

        for (UUID uuid : activeStarted.keySet()) {
            Player p = plugin.getServer().getPlayer(uuid);
            if (p == null || !p.isOnline() || p.isDead() || !gsit.isSitting(p)) {
                if (p != null) stop(p);
                else {
                    activeStarted.remove(uuid);
                    lastNanos.remove(uuid);
                    elapsedSeconds.remove(uuid);
                    herbProgress.remove(uuid);
                }
                continue;
            }

            PlayerData d = plugin.getCultivationService().getPlayerData(uuid);

            // Monotonic real-time delta. Clamp only the amount processed in one pass so a
            // long server stall cannot create a huge catch-up loop and TPS spike.
            long previous = lastNanos.getOrDefault(uuid, nowNanos);
            double delta = Math.max(0D, (nowNanos - previous) / 1_000_000_000D);
            lastNanos.put(uuid, nowNanos);
            delta = Math.min(delta, 2.0D);

            double elapsed = elapsedSeconds.getOrDefault(uuid, 0D) + delta;
            final long cycle = cycleSeconds(d);
            int completed = 0;

            while (elapsed >= cycle && completed < 2) {
                elapsed -= cycle;
                completed++;
                completeTrainingCycle(p, d);
            }
            // Never let a lag spike turn into dozens/hundreds of cycles in one tick.
            if (completed >= 2 && elapsed >= cycle) elapsed = Math.min(elapsed, cycle - 0.001D);
            elapsedSeconds.put(uuid, elapsed);

            // Every cultivation path gets its own rotating 360° VFX.
            if (plugin.getConfig().getBoolean("training.cultivation-vfx.enabled", true)) {
                spawnCultivationVfx(p, nowNanos);
            }

            // The displayed countdown is derived from the same monotonic timer used by the
            // actual cycle. It therefore advances approximately one real second per second.
            long remain = Math.max(0L, (long) Math.ceil(cycle - elapsed));
            p.sendActionBar("§b☯ Tu luyện §7| §dLinh Khí §f" + format(d.linhKhi()) + "/" + format(d.nextLinhKhiStageThreshold())
                    + " §7| §f" + remain + "s");
        }
    }

    private void completeTrainingCycle(Player p, PlayerData d) {
        double before = d.linhKhi();
        double amount = plugin.getConfig().getDouble("training.linh-khi-per-cycle", 25D);

        // Multipliers improve the amount absorbed, not the real-world timer.
        amount *= speedMultiplier(p);
        if (plugin.getHyperVN430System() != null) amount *= plugin.getHyperVN430System().trainingMultiplier(p);

        if (plugin.getConfig().getBoolean("linhzone.enabled", true) && linhZone.isInside(p.getLocation())) {
            amount *= plugin.getConfig().getDouble("linhzone.multiplier", 1.20D);
        }

        d.addLinhKhi(amount);
        double gained = Math.max(0D, d.linhKhi() - before);
        double progress = herbProgress.getOrDefault(p.getUniqueId(), 0D) + gained;
        int herbEvery = Math.max(1, plugin.getConfig().getInt("alchemy.herb-every-linh-khi", 100));
        int herbs = (int) (progress / herbEvery);
        if (herbs > 0) {
            progress -= herbs * herbEvery;
            plugin.getAlchemySystem().addHerb(p, herbs);
            p.sendMessage("§a✿ Tu luyện ngưng tụ được §f" + herbs + " Linh Thảo§a!");
        }
        herbProgress.put(p.getUniqueId(), progress);

        // Quest time is also real time: one completed cycle contributes exactly its real cycle length.
        quest.addTrainingTime(p, cycleSeconds(d));
        p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1.0, 0), 4,
                0.18, 0.45, 0.18, 0.01);
        p.playSound(p, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.35f, 1.55f);
    }

    private void spawnCultivationVfx(Player p, long nowNanos) {
        Location center=p.getLocation().clone().add(0,1.1,0);
        PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId());
        String cls=d.cultivationClass()==null?"TAN_TU":d.cultivationClass().toUpperCase(java.util.Locale.ROOT);
        int points=Math.max(16,Math.min(40,plugin.getConfig().getInt("training.cultivation-vfx.points",32)));
        double radius=Math.max(1.5D,Math.min(3.0D,plugin.getConfig().getDouble("training.cultivation-vfx.radius",3.0D)));
        double phase=nowNanos/1_000_000_000D*plugin.getConfig().getDouble("training.cultivation-vfx.speed",1.15D);
        Particle.DustOptions black=new Particle.DustOptions(Color.fromRGB(10,10,15),1.4f);
        Particle.DustOptions red=new Particle.DustOptions(Color.fromRGB(230,20,25),1.5f);
        Particle.DustOptions gold=new Particle.DustOptions(Color.fromRGB(255,215,70),1.45f);
        Particle.DustOptions green=new Particle.DustOptions(Color.fromRGB(70,220,70),1.35f);
        Particle.DustOptions blue=new Particle.DustOptions(Color.fromRGB(80,170,255),1.3f);
        if(cls.equals("KIEM_TU")||cls.equals("MA_TU")||cls.equals("QUY_TU")){
            Particle.DustOptions dust=cls.equals("KIEM_TU")?black:red;
            // Five-point star outline, continuously rotating around Y.
            for(int i=0;i<points;i++){
                double t=(double)i/points*Math.PI*10D+phase;
                double r=(i%2==0?radius:radius*0.42D);
                p.spawnParticle(Particle.DUST,center.clone().add(Math.cos(t)*r,0.35,Math.sin(t)*r),1,0,0,0,0,dust);
            }
            p.spawnParticle(cls.equals("MA_TU")?Particle.SOUL_FIRE_FLAME:Particle.CRIMSON_SPORE,center,3,0.35,0.55,0.35,0.01);
        } else if(cls.equals("PHAT_TU")){
            // Rotating Buddha-light rings.
            for(int i=0;i<points;i++){
                double a=phase+Math.PI*2D*i/points;
                Location q=center.clone().add(Math.cos(a)*radius,0.4+0.35*Math.sin(a*2),Math.sin(a)*radius);
                p.spawnParticle(Particle.END_ROD,q,1,0,0,0,0.01);
                p.spawnParticle(Particle.DUST,q.clone().add(0,0.45,0),1,0,0,0,0,gold);
            }
        } else if(cls.equals("DOC_TU")){
            // Rotating skull silhouette: cranium, jaw, and two eye sockets.
            for(int i=0;i<points;i++){
                double a=phase+Math.PI*2D*i/points;
                double r=i<points*0.7?radius*0.55:radius*0.35;
                double y=i<points*0.7?1.0:0.35;
                p.spawnParticle(Particle.DUST,center.clone().add(Math.cos(a)*r,y-0.55,Math.sin(a)*r),1,0,0,0,0,green);
            }
            for(int eye=-1;eye<=1;eye+=2){
                double a=phase+eye*0.28;
                p.spawnParticle(Particle.SNEEZE,center.clone().add(Math.cos(a)*0.45,0.85,Math.sin(a)*0.45),2,0.02,0.02,0.02,0);
            }
        } else {
            // Tán Tu: rotating Bagua ring + eight radial spokes.
            for(int i=0;i<points;i++){
                double a=phase+Math.PI*2D*i/points;
                p.spawnParticle(Particle.DUST,center.clone().add(Math.cos(a)*radius,0.2,Math.sin(a)*radius),1,0,0,0,0,blue);
            }
            for(int spoke=0;spoke<8;spoke++){
                double a=phase+Math.PI*2D*spoke/8D;
                for(int k=1;k<=5;k++){
                    double r=radius*k/5D;
                    p.spawnParticle(Particle.DUST,center.clone().add(Math.cos(a)*r,0.2,Math.sin(a)*r),1,0,0,0,0,blue);
                }
            }
        }
    }

    private static String format(double value) {
        if (Math.rint(value) == value) return String.format(java.util.Locale.ROOT, "%.0f", value);
        return String.format(java.util.Locale.ROOT, "%.1f", value);
    }

    public void shutdown() {
        task.cancel();
        activeStarted.clear();
        lastNanos.clear();
        elapsedSeconds.clear();
        herbProgress.clear();
    }
}
