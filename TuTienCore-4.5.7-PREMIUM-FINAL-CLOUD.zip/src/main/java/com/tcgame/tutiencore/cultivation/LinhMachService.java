package com.tcgame.tutiencore.cultivation;

import com.tcgame.tutiencore.TuTienCore;
import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import java.io.File;
import java.io.IOException;
import java.util.*;

import com.sk89q.worldedit.bukkit.WorldEditPlugin;
import com.sk89q.worldedit.regions.Region;
import com.sk89q.worldedit.world.World;
import com.sk89q.worldedit.bukkit.BukkitAdapter;

public final class LinhMachService {
    private final TuTienCore plugin;
    private final File file;
    private final Map<String, Mach> machs=new HashMap<>();
    public LinhMachService(TuTienCore plugin){this.plugin=plugin;file=new File(plugin.getDataFolder(),"linhmach.yml");load();}
    public boolean createFromSelection(Player p,String name,double bonus){
        WorldEditPlugin we=(WorldEditPlugin)plugin.getServer().getPluginManager().getPlugin("WorldEdit"); if(we==null)return false;
        try{Region r=we.getWorldEdit().getSessionManager().get(BukkitAdapter.adapt(p)).getSelection(BukkitAdapter.adapt(p).getWorld());
            if(r==null)return false; var min=r.getMinimumPoint(); var max=r.getMaximumPoint(); World w=r.getWorld();
            if (w == null) return false;
            machs.put(name,new Mach(name,w.getName(),min.x(),min.y(),min.z(),max.x(),max.y(),max.z(),bonus));save();return true;
        }catch(Exception ex){return false;}
    }
    public double bonusAt(Location l){for(Mach m:machs.values())if(m.contains(l))return m.bonus;return 0D;}
    public Collection<Mach> all(){return machs.values();}
    private void load(){if(!file.exists())return;YamlConfiguration y=YamlConfiguration.loadConfiguration(file);for(String n:y.getStringList("names")){String p="machs."+n; machs.put(n,new Mach(n,y.getString(p+".world","world"),y.getDouble(p+".min.x"),y.getDouble(p+".min.y"),y.getDouble(p+".min.z"),y.getDouble(p+".max.x"),y.getDouble(p+".max.y"),y.getDouble(p+".max.z"),y.getDouble(p+".bonus",0.25)));}}
    private void save(){YamlConfiguration y=new YamlConfiguration();y.set("names",new ArrayList<>(machs.keySet()));for(Mach m:machs.values()){String p="machs."+m.name; y.set(p+".world",m.world);y.set(p+".min.x",m.minX);y.set(p+".min.y",m.minY);y.set(p+".min.z",m.minZ);y.set(p+".max.x",m.maxX);y.set(p+".max.y",m.maxY);y.set(p+".max.z",m.maxZ);y.set(p+".bonus",m.bonus);}try{y.save(file);}catch(IOException e){plugin.getLogger().warning("Không lưu được Linh Mạch: "+e.getMessage());}}
    public static final class Mach{final String name,world;final double minX,minY,minZ,maxX,maxY,maxZ,bonus;Mach(String n,String w,double a,double b,double c,double d,double e,double f,double g){name=n;world=w;minX=Math.min(a,d);minY=Math.min(b,e);minZ=Math.min(c,f);maxX=Math.max(a,d);maxY=Math.max(b,e);maxZ=Math.max(c,f);bonus=g;}boolean contains(Location l){return l.getWorld()!=null&&l.getWorld().getName().equals(world)&&l.getX()>=minX&&l.getX()<=maxX&&l.getY()>=minY&&l.getY()<=maxY&&l.getZ()>=minZ&&l.getZ()<=maxZ;}}
}
