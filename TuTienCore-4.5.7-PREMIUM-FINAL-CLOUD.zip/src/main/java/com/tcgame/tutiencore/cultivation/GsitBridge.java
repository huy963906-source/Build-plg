package com.tcgame.tutiencore.cultivation;

import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;

/** GSit integration without a compile-time GSit dependency. */
public final class GsitBridge {
    private Class<?> api;
    private Method createSeat;
    private Method isSitting;
    private Method removeSeat;
    private Method getSeatByEntity;
    private Method stopPlayerSit;
    public boolean hook() {
        try {
            api=Class.forName("dev.geco.gsit.api.GSitAPI");
            createSeat=api.getMethod("createSeat", Block.class, org.bukkit.entity.LivingEntity.class);
            isSitting=api.getMethod("isEntitySitting", org.bukkit.entity.LivingEntity.class);
            getSeatByEntity=api.getMethod("getSeatByEntity", org.bukkit.entity.LivingEntity.class);
            removeSeat=api.getMethod("removeSeat", Class.forName("dev.geco.gsit.model.Seat"), Class.forName("dev.geco.gsit.model.StopReason"));
            stopPlayerSit=api.getMethod("stopPlayerSit", Player.class, Class.forName("dev.geco.gsit.model.StopReason"));
            return true;
        } catch (ReflectiveOperationException ex) { return false; }
    }
    public boolean sit(Player p) {
        if (api == null && !hook()) return false;
        try {
            if (Boolean.TRUE.equals(isSitting.invoke(null,p))) return true;
            Block block=p.getLocation().clone().subtract(0,1,0).getBlock();
            if (!block.getType().isSolid()) return false;
            Object seat=createSeat.invoke(null,block,p);
            return seat != null;
        } catch (ReflectiveOperationException ex) { return false; }
    }
    public boolean isSitting(Player p) { try { return api!=null && Boolean.TRUE.equals(isSitting.invoke(null,p)); } catch(Exception e){return false;} }
    public void stop(Player p) {
        if (api == null) return;
        try {
            Object seat=getSeatByEntity.invoke(null,p); if(seat!=null){ Class<?> reason=Class.forName("dev.geco.gsit.model.StopReason"); Object value=Enum.valueOf((Class<Enum>)reason.asSubclass(Enum.class), "PLUGIN"); removeSeat.invoke(null,seat,value); return; }
        } catch(Exception ignored) { }
    }
}
