package com.tcgame.tutiencore.cultivation;

import com.tcgame.tutiencore.TuTienCore;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.List;
import java.util.Map;

/** Persistent Linh Zone locations. Players inside receive a 1.2x Linh Khi gain. */
public final class LinhZoneManager {
    private final TuTienCore plugin;

    public LinhZoneManager(TuTienCore plugin) { this.plugin = plugin; }

    public boolean isInside(Location location) {
        if (location == null || location.getWorld() == null) return false;
        List<Map<?, ?>> zones = plugin.getConfig().getMapList("linhzone.zones");
        for (Map<?, ?> zone : zones) {
            Object worldObj = zone.get("world");
            if (worldObj == null || !location.getWorld().getName().equals(String.valueOf(worldObj))) continue;
            double x = number(zone.get("x"), Double.NaN);
            double y = number(zone.get("y"), Double.NaN);
            double z = number(zone.get("z"), Double.NaN);
            double radius = Math.max(1D, number(zone.get("radius"), plugin.getConfig().getDouble("linhzone.default-radius", 20D)));
            if (Double.isNaN(x) || Double.isNaN(y) || Double.isNaN(z)) continue;
            double dx = location.getX() - x;
            double dy = location.getY() - y;
            double dz = location.getZ() - z;
            if (dx * dx + dy * dy + dz * dz <= radius * radius) return true;
        }
        return false;
    }

    public void addZone(Location location, double radius) {
        List<Map<?, ?>> raw = plugin.getConfig().getMapList("linhzone.zones");
        java.util.List<Map<String, Object>> zones = new java.util.ArrayList<>();
        for (Map<?, ?> old : raw) {
            Map<String, Object> copy = new java.util.LinkedHashMap<>();
            for (Map.Entry<?, ?> e : old.entrySet()) copy.put(String.valueOf(e.getKey()), e.getValue());
            zones.add(copy);
        }
        Map<String, Object> zone = new java.util.LinkedHashMap<>();
        zone.put("world", location.getWorld().getName());
        zone.put("x", location.getX());
        zone.put("y", location.getY());
        zone.put("z", location.getZ());
        zone.put("radius", Math.max(1D, radius));
        zones.add(zone);
        plugin.getConfig().set("linhzone.zones", zones);
        plugin.saveConfig();
    }

    public int zoneCount() { return plugin.getConfig().getMapList("linhzone.zones").size(); }

    private double number(Object value, double fallback) {
        if (value instanceof Number n) return n.doubleValue();
        try { return value == null ? fallback : Double.parseDouble(String.valueOf(value)); }
        catch (NumberFormatException e) { return fallback; }
    }
}
