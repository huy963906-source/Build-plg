package com.tcgame.tutiencore.cultivation;

import org.bukkit.configuration.ConfigurationSection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Cảnh giới progression: cấp 1-100. PHAM_NHAN is the pre-unlock state;
 * all other realms map to the numbered progression below.
 */
public enum Realm {
    PHAM_NHAN("Phàm Nhân", false, 0, 0),
    LUYEN_KHI("Luyện Khí Kỳ", false, 1, 10),
    TRUC_CO("Trúc Cơ Kỳ", false, 11, 20),
    KIM_DAN("Kết Đan Kỳ / Kim Đan Kỳ", false, 21, 30),
    NGUYEN_ANH("Nguyên Anh Kỳ", false, 31, 40),
    HOA_THAN("Hóa Thần Kỳ", false, 41, 50),
    LUYEN_HU("Luyện Hư Kỳ", true, 51, 60),
    HOP_THE("Hợp Thể Kỳ", true, 61, 70),
    DO_KIEP("Độ Kiếp Kỳ", true, 71, 80),
    DAI_THUA("Đại Thừa Kỳ", true, 81, 90),
    CHAN_TIEN_HA("Chân Tiên Hạ Phẩm", true, 91, 91),
    CHAN_TIEN_TRUNG("Chân Tiên Trung Phẩm", true, 92, 92),
    CHAN_TIEN_THUONG("Chân Tiên Thượng Phẩm", true, 93, 93),
    KIM_TIEN_SO("Kim Tiên Sơ Kỳ", true, 94, 94),
    KIM_TIEN_HAU("Kim Tiên Hậu Kỳ", true, 95, 95),
    THAI_AT_NGOC_TIEN("Thái Ất Ngọc Tiên", true, 96, 96),
    DAI_LA_KIM_TIEN("Đại La Kim Tiên", true, 97, 97),
    CHUAN_THANH("Chuẩn Thánh / Bán Thánh", true, 98, 98),
    THANH_NHAN("Thánh Nhân", true, 99, 99),
    THIEN_DAO_CHU_TE("Thiên Đạo Chủ Tể", true, 100, 100);

    private static final Map<String, String> CUSTOM_DISPLAY_NAMES = new ConcurrentHashMap<>();

    private final String displayName;
    private final boolean requiresTribulation;
    private final int levelStart;
    private final int levelEnd;

    Realm(String displayName, boolean requiresTribulation, int levelStart, int levelEnd) {
        this.displayName = displayName;
        this.requiresTribulation = requiresTribulation;
        this.levelStart = levelStart;
        this.levelEnd = levelEnd;
    }

    public String displayName() { return CUSTOM_DISPLAY_NAMES.getOrDefault(name(), displayName); }

    /** Loads administrator-defined display labels from config without changing progression IDs. */
    public static void loadCustomDisplayNames(ConfigurationSection section) {
        CUSTOM_DISPLAY_NAMES.clear();
        if (section == null) return;
        for (Realm realm : values()) {
            String custom = section.getString(realm.name());
            if (custom != null && !custom.isBlank()) CUSTOM_DISPLAY_NAMES.put(realm.name(), custom.trim());
        }
    }

    /** Numbered editable slots: 1 = Luyện Khí, 2 = Trúc Cơ, ...; Phàm Nhân is not an editable rank slot. */
    public static Realm byRankIndex(int index) {
        if (index < 1) return null;
        int current = 0;
        for (Realm realm : values()) {
            if (realm == PHAM_NHAN) continue;
            if (++current == index) return realm;
        }
        return null;
    }
    public boolean requiresTribulation() { return requiresTribulation; }
    public int levelStart() { return levelStart; }
    public int levelEnd() { return levelEnd; }
    public int maxStage() { return levelEnd > levelStart ? 10 : 1; }

    public int levelForStage(int stage) {
        if (this == PHAM_NHAN) return 0;
        return levelStart + Math.max(1, Math.min(maxStage(), stage)) - 1;
    }

    public Realm next() {
        return ordinal() + 1 < values().length ? values()[ordinal() + 1] : null;
    }

    public static Realm byName(String s) {
        if (s == null) return null;
        for (Realm r : values()) {
            if (r.name().equalsIgnoreCase(s) || r.displayName().equalsIgnoreCase(s)) return r;
        }
        return null;
    }
}
