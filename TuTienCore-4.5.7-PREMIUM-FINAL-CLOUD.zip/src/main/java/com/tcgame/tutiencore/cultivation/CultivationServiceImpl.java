package com.tcgame.tutiencore.cultivation;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.CultivationService;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.spiritroot.SpiritRootQuality;
import com.tcgame.tutiencore.spiritroot.SpiritRootType;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class CultivationServiceImpl implements CultivationService {
    private final TuTienCore plugin;
    private final File folder;
    private final Map<UUID, PlayerData> cache = new ConcurrentHashMap<>();

    public CultivationServiceImpl(TuTienCore plugin) {
        this.plugin = plugin;
        folder = new File(plugin.getDataFolder(), "players");
        if (!folder.exists()) folder.mkdirs();
    }

    @Override public PlayerData getPlayerData(UUID uuid) { return cache.computeIfAbsent(uuid, this::load); }
    @Override public void addLinhKhi(UUID uuid, double amount) { getPlayerData(uuid).addLinhKhi(amount); }
    @Override public void setLinhKhi(UUID uuid, double amount) { getPlayerData(uuid).linhKhi(amount); }
    @Override public void setRealm(UUID uuid, Realm realm) { getPlayerData(uuid).realm(realm); }
    @Override public void setSpiritRoot(UUID uuid, SpiritRootType type, SpiritRootQuality quality) {
        PlayerData d = getPlayerData(uuid); d.spiritRoot(type); d.spiritRootQuality(quality);
    }

    private PlayerData load(UUID uuid) {
        PlayerData d = new PlayerData(uuid);
        File file = new File(folder, uuid + ".yml");
        if (!file.exists()) return d;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        Realm realm = Realm.byName(y.getString("realm", "PHAM_NHAN")); if (realm != null) d.realm(realm);
        d.realmStage(y.getInt("realm-stage", 1));
        // Migration: old files may contain tuvi. Linh Khí is the single cultivation resource.
        double savedLinhKhi = y.contains("linhkhi") ? y.getDouble("linhkhi", 0) : y.getDouble("tuvi", 0);
        d.linhKhi(savedLinhKhi);
        SpiritRootType rt = SpiritRootType.byName(y.getString("spirit-root.type", "NGU_HANH")); if (rt != null) d.spiritRoot(rt);
        String savedQuality = y.getString("spirit-root.quality", "NGUY_LINH_CAN");
        SpiritRootQuality rq = SpiritRootQuality.byName(savedQuality);
        if (rq == null) {
            rq = switch (savedQuality.toUpperCase()) {
                case "THUONG_PHAM" -> SpiritRootQuality.CAO_PHAM;
                case "CUC_PHAM" -> SpiritRootQuality.THIEN_PHAM;
                default -> SpiritRootQuality.NGUY_LINH_CAN;
            };
        }
        d.spiritRootQuality(rq);
        List<SpiritRootType> roots = new ArrayList<>();
        for (String name : y.getStringList("spirit-root.elements")) { SpiritRootType r = SpiritRootType.byName(name); if (r != null && r != SpiritRootType.NGU_HANH && r != SpiritRootType.BIEN_DI && !roots.contains(r)) roots.add(r); }
        if (!roots.isEmpty() || y.contains("spirit-root.elements")) d.spiritRoots(roots);
        d.canCot(y.getDouble("stats.can-cot", 1)); d.ngoTinh(y.getDouble("stats.ngo-tinh", 1));
        d.techniqueLevel(y.getInt("technique.level", 0)); d.techniqueExp(y.getLong("technique.exp", 0)); d.techniqueTalent(y.getInt("technique.talent", 0)); d.techniqueId(y.getString("technique.id", ""));
        d.swordSkills(y.getStringList("sword-skills.learned"));
        java.util.Map<String,Integer> skillLevels = new java.util.LinkedHashMap<>();
        if (y.isConfigurationSection("sword-skills.levels")) for (String key : y.getConfigurationSection("sword-skills.levels").getKeys(false)) skillLevels.put(key, y.getInt("sword-skills.levels." + key, 0));
        d.swordSkillLevels(skillLevels);
        d.cultivationClass(y.getString("cultivation-class", "KIEM_TU"));
        java.util.Map<String,Integer> classLevels = new java.util.LinkedHashMap<>();
        if (y.isConfigurationSection("class-skills.levels")) for (String key : y.getConfigurationSection("class-skills.levels").getKeys(false)) classLevels.put(key, y.getInt("class-skills.levels." + key, 0));
        d.classSkillLevels(classLevels);
        d.tamPhapLevel(y.getInt("tam-phap.level", 0));
        d.sectId(y.getString("sect.id", "")); d.sectContribution(y.getInt("sect.contribution", 0));
        d.petName(y.getString("pet.name", "")); d.petLevel(y.getInt("pet.level", 1)); d.petExp(y.getLong("pet.exp", 0));
        d.ownedPets(y.getStringList("pet.owned")); d.activePetId(y.getString("pet.active", ""));
        d.flightSkin(y.getString("flight.skin", "WOODEN")); d.ownedFlightSkins(y.getStringList("flight.owned-skins"));
        d.artifactQuality(y.getString("artifact.quality", "PHAM")); d.artifactLevel(y.getInt("artifact.level", 0));
        d.alchemyMultiplier(y.getDouble("alchemy.multiplier", 1)); d.alchemyBuffUntil(y.getLong("alchemy.buff-until", 0));
        d.dailyTrainingSeconds(y.getLong("quest.daily-training-seconds", 0)); d.weeklyTrainingSeconds(y.getLong("quest.weekly-training-seconds", 0));
        d.dailyProgressDay(y.getLong("quest.daily-progress-day", -1)); d.weeklyProgressKey(y.getLong("quest.weekly-progress-key", -1));
        d.dailyQuestClaim(y.getLong("quest.daily-claim", 0)); d.weeklyQuestClaim(y.getLong("quest.weekly-claim", 0));
        d.trainingSessionStarted(y.getLong("training.session-started", 0));
        d.rankLevel(y.getInt("rank.level", 1));
        d.luyenKhi1Unlocked(y.getBoolean("progress.luyen-khi-1-unlocked", false));
        d.finalTribulationPassed(y.getBoolean("progress.final-tribulation-passed", false));
        d.linhThao(y.getInt("resources.linh-thao", 0));
        d.linhThach(y.getInt("resources.linh-thach", 0));
        d.autoCatLinhThach(y.getBoolean("settings.auto-cat-linh-thach", false));
        d.tribulationCount(y.getInt("progress.tribulation-count", 0));
        d.spiritRootRolls(y.getInt("progress.spirit-root-rolls", 0));
        d.breakthroughCount(y.getInt("progress.breakthrough-count", 0));
        d.congDuc(y.getLong("karma.cong-duc", 0));
        d.nghiepLuc(y.getLong("karma.nghiep-luc", 0));
        d.thanLucLuanHoi(y.getLong("reincarnation.than-luc", 0));
        d.luanHoiCount(y.getInt("reincarnation.count", 0));
        d.hiddenDamagePercent(y.getDouble("reincarnation.hidden-damage-percent", 0));
        d.hiddenCooldownReductionPercent(y.getDouble("reincarnation.hidden-cooldown-percent", 0));
        d.stolenSkills(y.getStringList("reincarnation.stolen-skills"));
        d.thanThuc(y.getDouble("hyper430.than-thuc", 0D));
        d.catchupStartedAt(y.getLong("hyper430.catchup-started-at", 0L));
        d.ownedCosmetics(y.getStringList("hyper430.owned-cosmetics"));
        d.activeCosmetic(y.getString("hyper430.active-cosmetic", ""));
        return d;
    }

    @Override public void save(UUID uuid) {
        PlayerData d = cache.get(uuid); if (d == null) return;
        YamlConfiguration y = new YamlConfiguration();
        y.set("realm", d.realm().name()); y.set("realm-stage", d.realmStage()); y.set("linhkhi", d.linhKhi());
        y.set("spirit-root.type", d.spiritRoot().name()); y.set("spirit-root.quality", d.spiritRootQuality().name()); y.set("spirit-root.elements", d.spiritRoots().stream().map(Enum::name).toList());
        y.set("stats.can-cot", d.canCot()); y.set("stats.ngo-tinh", d.ngoTinh());
        y.set("technique.level", d.techniqueLevel()); y.set("technique.exp", d.techniqueExp()); y.set("technique.talent", d.techniqueTalent()); y.set("technique.id", d.techniqueId());
        y.set("sword-skills.learned", new java.util.ArrayList<>(d.swordSkills()));
        for (var entry : d.swordSkillLevels().entrySet()) y.set("sword-skills.levels." + entry.getKey(), entry.getValue());
        y.set("cultivation-class", d.cultivationClass());
        for (var entry : d.classSkillLevels().entrySet()) y.set("class-skills.levels." + entry.getKey(), entry.getValue());
        y.set("tam-phap.level", d.tamPhapLevel()); y.set("sect.id", d.sectId()); y.set("sect.contribution", d.sectContribution());
        y.set("pet.name", d.petName()); y.set("pet.level", d.petLevel()); y.set("pet.exp", d.petExp());
        y.set("pet.owned", d.ownedPets()); y.set("pet.active", d.activePetId());
        y.set("flight.skin", d.flightSkin()); y.set("flight.owned-skins", new java.util.ArrayList<>(d.ownedFlightSkins()));
        y.set("artifact.quality", d.artifactQuality()); y.set("artifact.level", d.artifactLevel());
        y.set("alchemy.multiplier", d.alchemyMultiplier()); y.set("alchemy.buff-until", d.alchemyBuffUntil());
        y.set("quest.daily-training-seconds", d.dailyTrainingSeconds()); y.set("quest.weekly-training-seconds", d.weeklyTrainingSeconds());
        y.set("quest.daily-progress-day", d.dailyProgressDay()); y.set("quest.weekly-progress-key", d.weeklyProgressKey());
        y.set("quest.daily-claim", d.dailyQuestClaim()); y.set("quest.weekly-claim", d.weeklyQuestClaim());
        y.set("training.session-started", d.trainingSessionStarted());
        y.set("rank.level", d.rankLevel());
        y.set("progress.luyen-khi-1-unlocked", d.luyenKhi1Unlocked());
        y.set("progress.final-tribulation-passed", d.finalTribulationPassed());
        y.set("resources.linh-thao", d.linhThao());
        y.set("resources.linh-thach", d.linhThach());
        y.set("settings.auto-cat-linh-thach", d.autoCatLinhThach());
        y.set("progress.tribulation-count", d.tribulationCount());
        y.set("progress.spirit-root-rolls", d.spiritRootRolls());
        y.set("progress.breakthrough-count", d.breakthroughCount());
        y.set("karma.cong-duc", d.congDuc());
        y.set("karma.nghiep-luc", d.nghiepLuc());
        y.set("reincarnation.than-luc", d.thanLucLuanHoi());
        y.set("reincarnation.count", d.luanHoiCount());
        y.set("reincarnation.hidden-damage-percent", d.hiddenDamagePercent());
        y.set("reincarnation.hidden-cooldown-percent", d.hiddenCooldownReductionPercent());
        y.set("reincarnation.stolen-skills", new ArrayList<>(d.stolenSkills()));
        y.set("hyper430.than-thuc", d.thanThuc());
        y.set("hyper430.catchup-started-at", d.catchupStartedAt());
        y.set("hyper430.owned-cosmetics", new ArrayList<>(d.ownedCosmetics()));
        y.set("hyper430.active-cosmetic", d.activeCosmetic());
        try { y.save(new File(folder, uuid + ".yml")); } catch (IOException e) { plugin.getLogger().warning("Không lưu được dữ liệu " + uuid + ": " + e.getMessage()); }
    }
    @Override public void saveAll() { cache.keySet().forEach(this::save); }
}
