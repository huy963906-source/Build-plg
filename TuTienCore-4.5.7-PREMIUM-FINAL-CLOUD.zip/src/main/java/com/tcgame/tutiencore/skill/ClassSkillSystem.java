package com.tcgame.tutiencore.skill;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Six cultivation paths, twelve skills each. Books teach a skill at level 1. */
public final class ClassSkillSystem implements Listener {
    public record Skill(String id, String name, String classId, int index, double damage, int cooldown, Material weapon) {}

    private final TuTienCore plugin;
    private final NamespacedKey bookKey;
    private final NamespacedKey weaponKey;
    private final Map<UUID, Map<String, Long>> cooldowns = new ConcurrentHashMap<>();
    private final Map<String, List<Skill>> skills = new LinkedHashMap<>();

    private static final List<String> CLASSES = List.of("KIEM_TU","MA_TU","QUY_TU","PHAT_TU","DOC_TU","TAN_TU");
    private static final Map<String,String> CLASS_NAMES = Map.of(
            "KIEM_TU", "Kiếm Tu", "MA_TU", "Ma Tu", "QUY_TU", "Quỷ Tu", "PHAT_TU", "Phật Tu", "DOC_TU", "Độc Tu", "TAN_TU", "Tán Tu");

    private static final String[][] NAMES = {
            {"Thanh Phong Kiếm","Liệt Không Trảm","Lưu Vân Kiếm Ý","Kiếm Khí Phá Sơn","Thiên Ảnh Kiếm","Cửu Kiếm Quy Nhất","Vạn Kiếm Quy Tông","Kiếm Vực","Thái Hư Kiếm","Tinh Hà Kiếm Vũ","Thiên Ngoại Phi Tiên","Kiếm Đạo Vô Song"},
            {"Ma Viêm Chưởng","Huyết Ma Trảo","U Minh Ma Ảnh","Ma Khí Bạo Phát","Thôn Linh","Huyết Hải","Ma Diễm Liên","Vạn Ma Triều Bái","Ma Vực","Thiên Ma Giáng Thế","Phệ Hồn","Ma Đạo Chí Tôn"},
            {"Quỷ Hỏa","Bách Quỷ Dạ Hành","U Hồn Trảo","Quỷ Ảnh","Âm Phong","Nhiếp Hồn","Quỷ Vực","Hoàng Tuyền Lộ","Lệ Quỷ Khiếu","Vạn Quỷ Thực Thể","Diêm La Lệnh","Quỷ Đế Hàng Lâm"},
            {"Kim Cang Quyền","Phật Quang Hộ Thể","La Hán Chưởng","Phạn Âm","Kim Cang Bất Hoại","Từ Bi Ấn","Phật Liên","Hàng Ma Trượng","Đại Quang Minh","Thiên Long Phạn Âm","Vạn Phật Triều Tông","Như Lai Thần Chưởng"},
            {"Độc Châm","Lục Độc Trảo","Độc Vụ","Xà Ảnh","Tâm Độc","Cốt Độc","Huyết Độc","Vạn Độc Quy Tông","Độc Vực","Thiên Hạt","Thực Cốt Độc","Vạn Độc Thánh Thể"},
            {"Tán Hoa Phiến","Lưu Vân Bộ","Hỗn Nguyên Kình","Tụ Khí Chưởng","Phong Vân","Địa Sát","Thiên Cương","Vô Danh Kiếm Ý","Ngũ Hành Tán Kình","Tiêu Dao Du","Hỗn Độn Kình","Tán Tiên Vô Cực"}
    };

    public ClassSkillSystem(TuTienCore plugin) {
        this.plugin = plugin;
        this.bookKey = new NamespacedKey(plugin, "class_skill_book");
        this.weaponKey = new NamespacedKey(plugin, "class_skill_weapon");
        for (int c=0;c<CLASSES.size();c++) {
            List<Skill> list = new ArrayList<>();
            for (int i=0;i<12;i++) {
                String id = CLASSES.get(c).toLowerCase(Locale.ROOT)+"-"+(i+1);
                list.add(new Skill(id, NAMES[c][i], CLASSES.get(c), i+1, 6D+i*1.6D, Math.max(2, 7-i/2), weaponFor(CLASS_NAMES.get(CLASSES.get(c)))));
            }
            skills.put(CLASSES.get(c), list);
        }
    }

    private Material weaponFor(String cls) {
        return switch (cls) {
            case "Kiếm Tu" -> Material.NETHERITE_SWORD;
            case "Ma Tu" -> Material.NETHERITE_AXE;
            case "Quỷ Tu" -> Material.NETHERITE_HOE;
            case "Phật Tu" -> Material.MACE;
            case "Độc Tu" -> Material.BOW;
            case "Tán Tu" -> Material.CROSSBOW;
            default -> Material.NETHERITE_SWORD;
        };
    }

    public List<String> classIds() { return CLASSES; }
    public String className(String id) { return CLASS_NAMES.getOrDefault(id.toUpperCase(Locale.ROOT), id); }
    public List<Skill> skills(String classId) { return skills.getOrDefault(classId.toUpperCase(Locale.ROOT), List.of()); }
    public Skill skill(String id) { for (List<Skill> list:skills.values()) for (Skill s:list) if (s.id().equalsIgnoreCase(id)) return s; return null; }

    public ItemStack createSkillBook(String classId, int index) {
        List<Skill> list=skills(classId); if (index<1 || index>list.size()) index=1; Skill s=list.get(index-1);
        ItemStack item=new ItemStack(Material.ENCHANTED_BOOK); ItemMeta m=item.getItemMeta();
        if(m!=null){
            m.setDisplayName("§d§l✦ Sách Kỹ Năng §f"+s.name());
            m.setLore(List.of("§7Phái: §f"+className(s.classId()),"§eChuột phải để học / tăng 1 cấp (tối đa 10)","§7Kỹ năng: §f"+s.name()));
            m.getPersistentDataContainer().set(bookKey,PersistentDataType.STRING,s.id());
            item.setItemMeta(m);
        }
        return item;
    }

    public ItemStack createClassWeapon(String classId) {
        classId=classId.toUpperCase(Locale.ROOT); List<Skill> list=skills(classId); Material mat=list.isEmpty()?Material.NETHERITE_SWORD:list.get(0).weapon();
        ItemStack item = createItemsAdderWeapon(classId);
        if (item == null || item.getType().isAir()) item = new ItemStack(mat);
        ItemMeta m=item.getItemMeta();
        if(m!=null){
            m.setDisplayName("§d§l✦ Vũ Khí "+className(classId));
            m.setLore(List.of("§7Phái: §f"+className(classId),"§7Chuột phải: dùng kỹ năng đã học","§8Skill được chọn bằng /phai skill <1-12>"));
            m.getPersistentDataContainer().set(weaponKey,PersistentDataType.STRING,classId);
            item.setItemMeta(m);
        }
        return item;
    }

    /** Optional ItemsAdder bridge without a hard compile-time dependency. */
    private ItemStack createItemsAdderWeapon(String classId) {
        if (!plugin.getConfig().getBoolean("itemsadder.enabled", true)
                || !plugin.getServer().getPluginManager().isPluginEnabled("ItemsAdder")) return null;
        String path = switch (classId.toUpperCase(Locale.ROOT)) {
            case "KIEM_TU" -> "kiem_tu";
            case "MA_TU" -> "ma_dao";
            case "QUY_TU" -> "quy_liem";
            case "PHAT_TU" -> "truong_phat";
            case "DOC_TU" -> "doc_nhan";
            case "TAN_TU" -> "linh_no";
            default -> null;
        };
        if (path == null) return null;
        String id = plugin.getConfig().getString("itemsadder.weapons." + classId.toUpperCase(Locale.ROOT), "hypervn:" + path);
        try {
            Class<?> customStack = Class.forName("dev.lone.itemsadder.api.CustomStack");
            Object custom = customStack.getMethod("getInstance", String.class).invoke(null, id);
            if (custom == null) {
                plugin.getLogger().warning("ItemsAdder item không tồn tại: " + id + ". Sử dụng vũ khí vanilla thay thế.");
                return null;
            }
            Object stack = customStack.getMethod("getItemStack").invoke(custom);
            if (stack instanceof ItemStack item) return item;
        } catch (ReflectiveOperationException | LinkageError ex) {
            plugin.getLogger().warning("Không thể tải ItemsAdder item " + id + ": " + ex.getClass().getSimpleName());
        }
        return null;
    }

    private static final String[] INPUTS = {"M1", "M2", "SHIFT_M2", "SHIFT_M1"};

    private String equippedSkill(Player p, String input) {
        return plugin.getConfig().getString("class-skill-slots." + p.getUniqueId() + "." + input, "");
    }

    public boolean equipSkill(Player p, String input, String skillId) {
        if (!Arrays.asList(INPUTS).contains(input)) return false;
        Skill skill = skill(skillId);
        PlayerData data = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (skill == null || data.classSkillLevel(skillId) <= 0) {
            p.sendMessage("§cBạn chưa học kỹ năng này."); return false;
        }
        if (!skill.classId().equalsIgnoreCase(data.cultivationClass())
                && !(data.cultivationClass().equalsIgnoreCase("TAN_TU") && data.hasStolenSkill(skill.id()))) {
            p.sendMessage("§cPhái hiện tại không thể trang bị kỹ năng này."); return false;
        }
        plugin.getConfig().set("class-skill-slots." + p.getUniqueId() + "." + input, skill.id());
        plugin.saveConfig();
        p.sendMessage("§aĐã trang bị §f" + skill.name() + " §avào §e" + input.replace('_', '+') + "§a.");
        return true;
    }

    @EventHandler public void onAnimation(PlayerAnimationEvent e) {
        if (e.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        Player p = e.getPlayer();
        ItemStack held = p.getInventory().getItemInMainHand();
        if (!isClassWeapon(held)) return;
        String classId = held.getItemMeta().getPersistentDataContainer().get(weaponKey, PersistentDataType.STRING);
        PlayerData data = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (classId == null || !data.cultivationClass().equalsIgnoreCase(classId)) return;
        if (p.isSneaking()) {
            String selected = equippedSkill(p, "SHIFT_M1");
            if (!selected.isBlank()) { Skill skill = skill(selected); if (skill != null) cast(p, skill); }
            return;
        }
        // M1 remains a normal vanilla melee hit, with a lightweight wuxia slash visual.
        Location at = p.getEyeLocation().add(p.getEyeLocation().getDirection().multiply(1.15));
        p.getWorld().spawnParticle(Particle.SWEEP_ATTACK, at, 2, .25, .18, .25, 0);
        p.getWorld().spawnParticle(Particle.CRIT, at, 8, .22, .2, .22, .12);
        p.playSound(at, Sound.ENTITY_PLAYER_ATTACK_SWEEP, .65f, 1.25f);
        String selected = equippedSkill(p, "M1");
        if (!selected.isBlank()) { Skill skill = skill(selected); if (skill != null) cast(p, skill); }
    }

    @EventHandler public void onInteract(PlayerInteractEvent e) {
        if(e.getHand()!=org.bukkit.inventory.EquipmentSlot.HAND) return;
        Action action = e.getAction();
        boolean right = action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK;
        if (!right) return;
        ItemStack item=e.getItem(); if(item==null || !item.hasItemMeta()) return; ItemMeta m=item.getItemMeta();
        String book=m.getPersistentDataContainer().get(bookKey,PersistentDataType.STRING);
        if(book!=null){e.setCancelled(true); learn(e.getPlayer(),item,book);return;}
        String weapon=m.getPersistentDataContainer().get(weaponKey,PersistentDataType.STRING);
        if(weapon==null) return;
        e.setCancelled(true);
        Player p=e.getPlayer(); PlayerData pd = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if(!pd.cultivationClass().equalsIgnoreCase(weapon)){p.sendMessage("§cVũ khí này chỉ dành cho §f"+className(weapon)+"§c."); return;}
        String input = p.isSneaking() ? "SHIFT_M2" : "M2";
        String selected = equippedSkill(p, input);
        if (selected.isBlank()) {
            // Compatibility fallback for players who have not configured the four slots yet.
            selected = plugin.getConfig().getString("class-skill-selected."+p.getUniqueId(), weapon.toLowerCase(Locale.ROOT)+"-1");
        }
        Skill s=skill(selected);
        if(s==null || (!s.classId().equalsIgnoreCase(weapon) && !(weapon.equalsIgnoreCase("TAN_TU") && pd.hasStolenSkill(s.id())))) {
            p.sendMessage("§eChưa trang bị skill cho §f"+input.replace('_','+')+"§e. Dùng /kinang."); return;
        }
        cast(p,s);
    }

    public void learn(Player p, ItemStack item, String id){
        Skill s=skill(id); if(s==null){p.sendMessage("§cKỹ năng không tồn tại.");return;}
        PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if(!d.cultivationClass().equalsIgnoreCase(s.classId())){p.sendMessage("§cBạn đang là §f"+className(d.cultivationClass())+"§c. Không thể học sách của §f"+className(s.classId()));return;}
        int oldLevel = d.classSkillLevel(s.id());
        int newLevel = Math.min(10, oldLevel + 1);
        d.classSkillLevel(s.id(),newLevel); plugin.getCultivationService().save(p.getUniqueId());
        if(item.getAmount()>1)item.setAmount(item.getAmount()-1);else p.getInventory().setItemInMainHand(null);
        p.sendMessage("§d✦ Kỹ năng: §f"+s.name()+" §a→ Cấp §e"+newLevel+" §7| Damage cơ bản ×"+String.format(java.util.Locale.ROOT,"%.0f",Math.pow(2,newLevel-1))); p.playSound(p.getLocation(),Sound.BLOCK_ENCHANTMENT_TABLE_USE,1f,1.4f); p.getWorld().spawnParticle(Particle.ENCHANT,p.getLocation().add(0,1,0),30,.5,.6,.5,.08);
    }

    /**
     * Select a cultivation path and replace any previous class-bound weapon.
     * Only items carrying this plugin's class_skill_weapon PDC tag are removed;
     * ordinary player weapons are never touched.
     */
    public boolean chooseClass(Player p,String id){
        id=id.toUpperCase(Locale.ROOT);
        if(!CLASSES.contains(id)) return false;
        PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if(plugin.getTrainingManager()!=null && plugin.getTrainingManager().isTraining(p.getUniqueId())) {
            plugin.getTrainingManager().stop(p);
        }
        d.cultivationClass(id);
        plugin.getCultivationService().save(p.getUniqueId());

        // Remove every plugin-issued class weapon first, preventing duplicates
        // even if the player changes back to the same class or has moved it
        // between inventory slots/offhand.
        for (int slot=0; slot<p.getInventory().getSize(); slot++) {
            ItemStack existing=p.getInventory().getItem(slot);
            if (isClassWeapon(existing)) p.getInventory().setItem(slot, null);
        }
        ItemStack weapon=createClassWeapon(id);
        Map<Integer, ItemStack> overflow=p.getInventory().addItem(weapon);
        for (ItemStack leftover:overflow.values()) {
            p.getWorld().dropItemNaturally(p.getLocation(),leftover);
        }
        p.sendMessage("§d✦ §aĐã chọn phái: §f"+className(id));
        p.sendMessage("§d✦ §aVũ khí phái mới đã được cấp: §f"+className(id)+"§a.");
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.25f);
        p.getWorld().spawnParticle(Particle.ENCHANT,p.getLocation().add(0,1,0),24,.45,.6,.45,.06);
        return true;
    }

    private boolean isClassWeapon(ItemStack item) {
        if (item==null || item.getType().isAir() || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(weaponKey, PersistentDataType.STRING);
    }
    public String equippedSkill(Player p, int slotIndex) { return equippedSkill(p, INPUTS[Math.max(0, Math.min(INPUTS.length - 1, slotIndex))]); }
    public String inputName(int slotIndex) { return INPUTS[Math.max(0, Math.min(INPUTS.length - 1, slotIndex))]; }

    public void selectSkill(Player p,int index){ PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId()); List<Skill> list=skills(d.cultivationClass()); if(index<1||index>list.size()){p.sendMessage("§cChọn skill từ 1-12.");return;} plugin.getConfig().set("class-skill-selected."+p.getUniqueId(),list.get(index-1).id()); plugin.saveConfig(); p.sendMessage("§aĐã chọn §f"+list.get(index-1).name()+" §a(Cấp "+d.classSkillLevel(list.get(index-1).id())+")."); }

    public void selectSkillId(Player p, String id){
        PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId());
        Skill s=skill(id);
        if(s==null){p.sendMessage("§cKhông tìm thấy kỹ năng: §f"+id);return;}
        if(s.classId().equalsIgnoreCase(d.cultivationClass()) || (d.cultivationClass().equals("TAN_TU") && d.hasStolenSkill(s.id()))){
            if(d.classSkillLevel(s.id())<=0){p.sendMessage("§cBạn chưa học kỹ năng này.");return;}
            plugin.getConfig().set("class-skill-selected."+p.getUniqueId(),s.id()); plugin.saveConfig();
            p.sendMessage("§aĐã chọn §f"+s.name()+" §a(Cấp "+d.classSkillLevel(s.id())+").");
        } else p.sendMessage("§cPhái hiện tại không thể dùng kỹ năng này.");
    }

    public void cast(Player p, Skill s){
        PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId());
        int level=d.classSkillLevel(s.id());
        if(level<=0){p.sendMessage("§cBạn chưa học kỹ năng này. Dùng sách tương ứng.");return;}
        long now=System.currentTimeMillis();
        long ready=cooldowns.computeIfAbsent(p.getUniqueId(),k->new ConcurrentHashMap<>()).getOrDefault(s.id(),0L);
        if(now<ready){p.sendMessage("§cKỹ năng hồi trong §f"+((ready-now+999)/1000)+"s");return;}
        long effectiveCooldown=3000L; // PvP/PvE skill cooldown standardized to 3 seconds.
        cooldowns.get(p.getUniqueId()).put(s.id(),now+effectiveCooldown);
        if (plugin.getHyperVN430System() != null) plugin.getHyperVN430System().onSkillUsed(p, s.id(), s.classId());
        if (s.classId().equals("KIEM_TU") && s.index()==7) { castVanKiemQuyTong(p, level); return; }

        // Mỗi level tăng gấp đôi damage: Lv1 x1, Lv2 x2, Lv3 x4...
        double damage=s.damage()*Math.pow(2D, level-1);
        int idx=s.index();
        Vector dir=p.getEyeLocation().getDirection().normalize();
        Location center=p.getLocation().clone().add(0,1,0);
        Particle part=switch(s.classId()){
            case "MA_TU"->Particle.SOUL_FIRE_FLAME; case "QUY_TU"->Particle.SCULK_SOUL;
            case "PHAT_TU"->Particle.END_ROD; case "DOC_TU"->Particle.SNEEZE;
            case "TAN_TU"->Particle.CLOUD; default->Particle.SWEEP_ATTACK;};
        // Main impact + class-colored signature pattern. Particle-only visuals
        // are deliberately used so the skill set works without a resource pack/model.
        p.getWorld().spawnParticle(part,center,70+idx*5,1.0,.8,1.0,.06);
        p.getWorld().spawnParticle(Particle.END_ROD, center, 22, .8, .9, .8, .08);
        p.getWorld().spawnParticle(Particle.CRIT, center, 35, .7, .7, .7, .22);
        p.getWorld().spawnParticle(Particle.FLASH, center, 1);
        p.playSound(center, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 0.65f);
        Particle accent = switch (s.classId()) {
            case "MA_TU" -> Particle.DRAGON_BREATH;
            case "QUY_TU" -> Particle.SOUL;
            case "PHAT_TU" -> Particle.FIREWORK;
            case "DOC_TU" -> Particle.COMPOSTER;
            case "TAN_TU" -> Particle.ELECTRIC_SPARK;
            default -> Particle.END_ROD;
        };
        // Three low-cost rings give each cast a readable MMORPG-style tell.
        for (int ring = 0; ring < 3; ring++) {
            double radius = 0.65 + ring * 0.42 + (idx % 3) * 0.08;
            for (int point = 0; point < 12; point++) {
                double angle = (Math.PI * 2.0 * point / 12.0) + (idx * 0.11) + (ring * 0.28);
                Location particleAt = center.clone().add(Math.cos(angle) * radius, 0.12 + ring * 0.22, Math.sin(angle) * radius);
                p.getWorld().spawnParticle(accent, particleAt, 1, 0.015, 0.025, 0.015, 0.0);
            }
        }
        // Higher-index techniques get a short directional streak, not a model dependency.
        if (idx >= 6) {
            for (int step = 1; step <= 7; step++) {
                Location streak = center.clone().add(dir.clone().multiply(step * 0.48));
                p.getWorld().spawnParticle(accent, streak, 2, .12, .12, .12, .015);
            }
        }
        p.playSound(center, switch(s.classId()){
            case "MA_TU"->Sound.ENTITY_WITHER_SHOOT; case "QUY_TU"->Sound.ENTITY_PHANTOM_FLAP;
            case "PHAT_TU"->Sound.BLOCK_BELL_USE; case "DOC_TU"->Sound.ENTITY_SPIDER_AMBIENT;
            case "TAN_TU"->Sound.ENTITY_BREEZE_WIND_BURST; default->Sound.ENTITY_PLAYER_ATTACK_SWEEP;},1f,1f+idx*.03f);

        // 12 skill được chia cơ chế để không còn cảm giác clone nhau.
        int pattern=idx%6;
        if(pattern==0){ // Đòn thẳng
            LivingEntity hit=null; double best=9*9;
            for(Entity ent:p.getNearbyEntities(9,3,9)) if(ent instanceof LivingEntity le&&!le.equals(p)&&!(le instanceof Player tp&&!canPlayersFight(p,tp))){
                Vector to=le.getLocation().add(0,1,0).toVector().subtract(center.toVector());
                if(to.lengthSquared()<=81 && dir.dot(to.normalize())>.72 && to.lengthSquared()<best){hit=le;best=to.lengthSquared();}}
            if(hit!=null){hit.damage(damage,p);hit.setVelocity(dir.clone().multiply(.35).setY(.15));}
        } else if(pattern==1){ // AOE lửa
            double radius=3.0+level*.15;
            for(Entity ent:p.getNearbyEntities(radius,2.5,radius)) if(ent instanceof LivingEntity le&&!le.equals(p)&&!(le instanceof Player tp&&!canPlayersFight(p,tp))){le.damage(damage*.85,p);le.setFireTicks(50+level*5);}
        } else if(pattern==2){ // Đạn năng lượng
            org.bukkit.entity.Snowball projectile=p.launchProjectile(org.bukkit.entity.Snowball.class);
            projectile.setVelocity(dir.multiply(1.8));
            projectile.setItem(new ItemStack(Material.AMETHYST_SHARD));
            projectile.getPersistentDataContainer().set(new NamespacedKey(plugin,"class_skill_damage"),PersistentDataType.DOUBLE,damage);
            projectile.getPersistentDataContainer().set(new NamespacedKey(plugin,"class_skill_owner"),PersistentDataType.STRING,p.getUniqueId().toString());
        } else if(pattern==3){ // Hút máu
            double dealt=0;
            for(Entity ent:p.getNearbyEntities(4.0,2.5,4.0)) if(ent instanceof LivingEntity le&&!le.equals(p)&&!(le instanceof Player tp&&!canPlayersFight(p,tp))){le.damage(damage*.75,p);dealt+=damage*.75;}
            if(dealt>0)p.setHealth(Math.min(p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue(),p.getHealth()+Math.min(4+level*.5,dealt*.12)));
        } else if(pattern==4){ // Khống chế
            for(Entity ent:p.getNearbyEntities(3.5,2.5,3.5)) if(ent instanceof LivingEntity le&&!le.equals(p)&&!(le instanceof Player tp&&!canPlayersFight(p,tp))){le.damage(damage*.7,p);le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,60+level*5,Math.min(4,1+level/3),true,false,false));}
        } else { // Vòng chém
            for(int ring=0;ring<3;ring++)p.getWorld().spawnParticle(part,center,20,1.5+ring,.35,1.5+ring,.02);
            for(Entity ent:p.getNearbyEntities(5.5,3,5.5)) if(ent instanceof LivingEntity le&&!le.equals(p)&&!(le instanceof Player tp&&!canPlayersFight(p,tp))){le.damage(damage,p);le.setVelocity(le.getLocation().toVector().subtract(center.toVector()).normalize().multiply(.45).setY(.2));}
        }
        if(s.classId().equals("DOC_TU")) for(Entity ent:p.getNearbyEntities(5,3,5)) if(ent instanceof LivingEntity le&&!le.equals(p)&&!(le instanceof Player tp&&!canPlayersFight(p,tp))) le.addPotionEffect(new PotionEffect(PotionEffectType.POISON,80+idx*5,Math.min(4,idx/3),true,false,false));
        p.sendActionBar("§d✦ "+className(s.classId())+" §f| §e"+s.name()+" §7Cấp §f"+level+" §8| §cDMG "+String.format(java.util.Locale.ROOT,"%.1f",damage));
    }

    private boolean canPlayersFight(Player a, Player b) {
        String ca = plugin.getCultivationService().getPlayerData(a.getUniqueId()).cultivationClass();
        String cb = plugin.getCultivationService().getPlayerData(b.getUniqueId()).cultivationClass();
        if (isDemonic(ca) && isDemonic(cb)) return false;
        return plugin.getServerFeatureSystem() != null && plugin.getServerFeatureSystem().isDuel(a) && plugin.getServerFeatureSystem().isDuel(b);
    }
    private boolean isDemonic(String id) { return id.equalsIgnoreCase("MA_TU") || id.equalsIgnoreCase("QUY_TU"); }

    private void castVanKiemQuyTong(Player p, int level) {
        Vector dir=p.getEyeLocation().getDirection().normalize(); Location origin=p.getLocation().clone().add(0,1.0,0);
        p.playSound(origin, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1.35f);
        p.getWorld().spawnParticle(Particle.END_ROD, origin, 45, .8,.8,.8,.08);
        List<ItemDisplay> swords=new ArrayList<>();
        int count=18;
        for(int i=0;i<count;i++){
            double t=i/(double)(count-1); double side=(t-.5)*8.0; double y=2.8+Math.sin(t*Math.PI)*2.0; Location start=origin.clone().add(dir.clone().multiply(-1.8));
            Vector right=new Vector(-dir.getZ(),0,dir.getX()); if(right.lengthSquared()<.01) right=new Vector(1,0,0); right.normalize();
            start.add(right.multiply(side)).add(0,y,0);
            ItemDisplay display=p.getWorld().spawn(start, ItemDisplay.class);
            display.setItemStack(new ItemStack(Material.GOLDEN_SWORD)); display.setBillboard(Display.Billboard.FIXED);
            float roll=(float)(Math.PI/2 + (t-.5)*0.7);
            Quaternionf rot=new Quaternionf().rotateY((float)Math.atan2(-dir.getX(), -dir.getZ())).rotateX((float)Math.atan2(dir.getY(), Math.sqrt(dir.getX()*dir.getX()+dir.getZ()*dir.getZ()))).rotateZ(roll);
            display.setTransformation(new Transformation(new Vector3f(),rot,new Vector3f(.65f,.65f,.65f),new Quaternionf()));
            display.setInterpolationDuration(2); display.setTeleportDuration(1); display.setGravity(false); swords.add(display);
        }
        Location target=origin.clone().add(dir.clone().multiply(14));
        new BukkitRunnable(){int tick=0; @Override public void run(){
            if(!p.isOnline()){cleanup();cancel();return;}
            tick++;
            for(int i=0;i<swords.size();i++){
                ItemDisplay d=swords.get(i); if(!d.isValid()) continue; double start=(i/(double)Math.max(1,swords.size()-1)); double phase=Math.min(1,tick/18.0 + start*.22); Location pos=d.getLocation().clone().add(dir.clone().multiply(0.8 + phase*1.0));
                if(phase>0.55) { double converge=(phase-.55)/.45; Location sideTarget=target.clone().add(new Vector((i-8.5)*.18,(i%3-1)*.2,0)); pos=pos.clone().add(target.clone().subtract(pos).multiply(converge)); }
                d.teleport(pos); p.getWorld().spawnParticle(Particle.END_ROD,pos,2,.05,.05,.05,.01);
            }
            if(tick%2==0) p.getWorld().spawnParticle(Particle.SWEEP_ATTACK,target,3,1.2,.6,1.2,.02);
            if(tick>=22){
                for(Entity ent:p.getNearbyEntities(5,4,5)){ if(!(ent instanceof LivingEntity targetEntity)||targetEntity.equals(p))continue; if(targetEntity instanceof Player tp && !canPlayersFight(p,tp))continue; targetEntity.damage(24D*(1+(level-1)*.1),p); }
                p.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER,target,1); p.getWorld().spawnParticle(Particle.END_ROD,target,70,2,1.5,2,.1); p.playSound(target,Sound.ENTITY_PLAYER_ATTACK_CRIT,1f,.6f); cleanup(); cancel();
            }
        } public void cleanup(){for(ItemDisplay d:swords)if(d!=null&&d.isValid())d.remove();}}.runTaskTimer(plugin,0L,1L);
        p.sendActionBar("§6⚔ §eVẠN KIẾM QUY TÔNG §7| §fCấp "+level);
    }
}
