package com.tcgame.tutiencore.skill;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Combat skill swords + right-click skill books. */
public final class SkillSwordSystem implements Listener {
    private final TuTienCore plugin;
    private final NamespacedKey swordSkillKey;
    private final NamespacedKey skillBookKey;
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();

    public SkillSwordSystem(TuTienCore plugin) {
        this.plugin = plugin;
        swordSkillKey = new NamespacedKey(plugin, "sword_skill");
        skillBookKey = new NamespacedKey(plugin, "skill_book");
    }

    public Set<String> skills() {
        var sec = plugin.getConfig().getConfigurationSection("sword-skills.skills");
        if (sec == null) return Set.of("liet-hoa-tram", "phong-loi-tram", "bang-nguyet-tram");
        return sec.getKeys(false);
    }

    public String skillName(String id) { return ChatColor.translateAlternateColorCodes('&', plugin.getConfig().getString("sword-skills.skills."+id+".name", id)); }
    public int skillCooldown(String id) { return Math.max(1, plugin.getConfig().getInt("sword-skills.skills."+id+".cooldown", 5)); }
    public double skillDamage(String id) { return plugin.getConfig().getDouble("sword-skills.skills."+id+".damage", 8D); }

    public ItemStack createSword(String id) {
        if (!skills().contains(id)) id = skills().iterator().next();
        ItemStack item = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§d§l✦ Kiếm Kỹ §f" + skillName(id));
            meta.setLore(List.of("§7Skill: §f" + id, "§7Chuột phải để thi triển", "§7Cấp skill của bạn: §e0"));
            meta.getPersistentDataContainer().set(swordSkillKey, PersistentDataType.STRING, id);
            item.setItemMeta(meta);
        }
        return item;
    }

    public ItemStack createSkillBook(String id) {
        if (!skills().contains(id)) id = skills().iterator().next();
        ItemStack item = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§d§lSách Kiếm Kỹ §f" + skillName(id));
            meta.setLore(List.of("§7Chuột phải để học/cộng 1 cấp skill", "§7Skill: §f" + id));
            meta.getPersistentDataContainer().set(skillBookKey, PersistentDataType.STRING, id);
            item.setItemMeta(meta);
        }
        return item;
    }

    @EventHandler public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (item == null || !item.hasItemMeta()) return;
        ItemMeta meta = item.getItemMeta();
        String book = meta.getPersistentDataContainer().get(skillBookKey, PersistentDataType.STRING);
        if (book != null) {
            e.setCancelled(true);
            learnFromBook(e.getPlayer(), item, book);
            return;
        }
        String skill = meta.getPersistentDataContainer().get(swordSkillKey, PersistentDataType.STRING);
        if (skill != null) {
            e.setCancelled(true);
            cast(e.getPlayer(), skill);
        }
    }

    private void learnFromBook(Player p, ItemStack item, String skill) {
        if (!skills().contains(skill)) { p.sendMessage("§cSkill không tồn tại: §f" + skill); return; }
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (!d.cultivationClass().equalsIgnoreCase("KIEM_TU")) { p.sendMessage("§c✦ Kiếm Kỹ chỉ dành cho §fKiếm Tu§c."); return; }
        if (!d.hasSwordSkill(skill)) { d.learnSwordSkill(skill); d.swordSkillLevel(skill, 1); p.sendMessage("§d✦ Đã học Kiếm Kỹ: §f"+skillName(skill)+" §d(Cấp 1)"); }
        else { int next=d.swordSkillLevel(skill)+1; d.swordSkillLevel(skill,next); p.sendMessage("§a✦ Kiếm Kỹ §f"+skillName(skill)+" §a+1 cấp → §e"+next); }
        plugin.getCultivationService().save(p.getUniqueId());
        if (item.getAmount() > 1) item.setAmount(item.getAmount()-1); else p.getInventory().setItemInMainHand(null);
        p.playSound(p.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 0.8f, 1.4f);
        p.getWorld().spawnParticle(Particle.ENCHANT, p.getLocation().add(0,1,0), 25, .4,.5,.4,.08);
    }

    private void cast(Player p, String skill) {
        PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (!d.cultivationClass().equalsIgnoreCase("KIEM_TU")) { p.sendMessage("§c✦ Kiếm Kỹ chỉ dành cho §fKiếm Tu§c."); return; }
        int level=d.swordSkillLevel(skill);
        if (!d.hasSwordSkill(skill) || level <= 0) { p.sendMessage("§cBạn chưa học Kiếm Kỹ này. Dùng sách tương ứng."); return; }
        long now=System.currentTimeMillis();
        long ready=cooldowns.getOrDefault(p.getUniqueId(),0L);
        if (now<ready) { p.sendMessage("§cKiếm Kỹ đang hồi: §f"+((ready-now+999)/1000)+"s"); return; }
        cooldowns.put(p.getUniqueId(), now+skillCooldown(skill)*1000L);
        double damage=skillDamage(skill)*(1D+(level-1)*0.08D);
        Vector dir=p.getEyeLocation().getDirection().normalize();
        var center=p.getLocation().clone().add(0,1,0);
        switch(skill.toLowerCase(Locale.ROOT)) {
            case "liet-hoa-tram" -> { p.getWorld().spawnParticle(Particle.FLAME, center, 35, .7,.5,.7,.03); p.playSound(center,Sound.ENTITY_BLAZE_SHOOT,1f,1.1f); }
            case "phong-loi-tram" -> { p.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, center, 40, .8,.6,.8,.08); p.playSound(center,Sound.ENTITY_LIGHTNING_BOLT_THUNDER,.5f,1.6f); }
            case "bang-nguyet-tram" -> { p.getWorld().spawnParticle(Particle.SNOWFLAKE, center, 45, .8,.6,.8,.04); p.playSound(center,Sound.BLOCK_GLASS_BREAK,.8f,1.8f); }
            default -> { p.getWorld().spawnParticle(Particle.CRIT, center, 30, .6,.4,.6,.15); }
        }
        for(Entity ent:p.getNearbyEntities(4.5,2.5,4.5)) {
            if (!(ent instanceof LivingEntity target) || target.equals(p) || target instanceof Player && !plugin.getConfig().getBoolean("sword-skills.allow-player-damage", false)) continue;
            Vector to=target.getLocation().toVector().subtract(p.getLocation().toVector());
            if (to.lengthSquared()>24) continue;
            target.damage(damage,p);
            target.setVelocity(dir.clone().multiply(.45).setY(.18));
        }
        p.sendActionBar("§d✦ "+skillName(skill)+" §7Cấp §e"+level);
    }
}
