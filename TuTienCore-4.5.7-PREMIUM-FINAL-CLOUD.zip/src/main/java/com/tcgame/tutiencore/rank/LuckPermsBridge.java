package com.tcgame.tutiencore.rank;

import com.tcgame.tutiencore.TuTienCore;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.ChatColor;

/** Uses LuckPerms commands so TuTienCore has no hard dependency on LuckPerms API. */
public final class LuckPermsBridge {
    private final TuTienCore plugin;
    public LuckPermsBridge(TuTienCore plugin) { this.plugin = plugin; }
    public boolean available() { return plugin.getServer().getPluginManager().isPluginEnabled("LuckPerms"); }

    public void deleteGroup(int level) {
        run("lp deletegroup " + Math.max(1, Math.min(30, level)));
    }

    public void ensureGroup(int level, String name, String prefix) {
        String group = String.valueOf(level);
        run("lp creategroup " + group);
        String translated = ChatColor.translateAlternateColorCodes('&', prefix);
        run("lp group " + group + " meta setprefix " + (100 + level) + " \"" + translated + "\"");
        if (level > 1) run("lp group " + group + " parent add " + (level - 1));
    }

    public void setupStaffGroups() {
        // Staff ladder is completely separate from the numeric cultivation ranks 1-30.
        // These groups use their own permission nodes and never inherit rank 1-30.
        String[][] groups = {
                {"internhelper", "&7[Helper Thực Tập] ", "internhelper", ""},
                {"police", "&9[Police] ", "police", "internhelper"},
                {"helper", "&a[Helper] ", "helper", "police"},
                {"mod", "&2[Mod] ", "mod", "helper"},
                {"admin", "&c[Admin] ", "admin", "mod"}
        };
        int weight = 300;
        for (String[] group : groups) {
            String name = group[0];
            run("lp creategroup " + name);
            String translated = ChatColor.translateAlternateColorCodes('&', group[1]);
            run("lp group " + name + " meta setprefix " + weight++ + " \"" + translated + "\"");
            run("lp group " + name + " permission set " + group[2] + " true");
            if (name.equals("admin")) run("lp group admin permission set * true");
            if (!group[3].isEmpty()) {
                run("lp group " + name + " parent add " + group[3]);
            }
        }
    }

    public void syncPlayer(Player player, int level) {
        // Intentionally disabled in 2.6.0: TuTienCore never changes a player's LuckPerms groups.
        // Rank/staff groups are managed manually by the server owner.
    }

    private void run(String command) {
        try { Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command); }
        catch (Exception ex) { plugin.getLogger().warning("LuckPerms command failed: " + command + " | " + ex.getMessage()); }
    }
}
