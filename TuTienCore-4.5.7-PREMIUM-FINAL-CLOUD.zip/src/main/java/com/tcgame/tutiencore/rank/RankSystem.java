package com.tcgame.tutiencore.rank;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.entity.Player;

/** Sequential rank ladder. Rank purchases use PlayerPoints, not Vault money. */
public final class RankSystem {
    private final TuTienCore plugin;
    private final LuckPermsBridge luckPerms;
    private final PlayerPointsBridge playerPoints;

    public RankSystem(TuTienCore plugin) {
        this.plugin = plugin;
        this.luckPerms = new LuckPermsBridge(plugin);
        this.playerPoints = new PlayerPointsBridge(plugin);
    }

    public String name(int level) {
        return plugin.getConfig().getString("ranks." + level + ".name", "Rank " + level);
    }

    public String prefix(int level) {
        return plugin.getConfig().getString("ranks." + level + ".prefix", "&7[" + name(level) + "] ");
    }

    /** Rank 2 costs base-cost-points, rank 3 costs 2x, etc. */
    public int costForNext(int current) {
        int base = Math.max(0, plugin.getConfig().getInt("ranks.base-cost-points", 10));
        return Math.max(0, current * base);
    }

    public int visibleMaxRank() {
        int configured = plugin.getConfig().getInt("ranks.visible-ranks", 8);
        return Math.max(1, Math.min(30, configured));
    }

    /** Rank cultivation multiplier: rank 1 = 1.0x, rank 2 = 1.2x, rank 3 = 1.44x, etc. */
    public double cultivationMultiplier(int level) {
        double perRank = Math.max(1.0D, plugin.getConfig().getDouble("ranks.linh-khi-multiplier-per-rank", 1.2D));
        int steps = Math.max(0, level - 1);
        return Math.pow(perRank, steps);
    }

    public long trainingSeconds(int level) {
        return Math.max(1L,
                plugin.getConfig().getLong("training.base-cycle-seconds", 200L)
                        - ((long) Math.max(0, level - 1)
                        * plugin.getConfig().getLong("ranks.training-seconds-per-rank", 10L)));
    }

    public void setupLuckPermsGroups() {
        // 2.6.0: LuckPerms is read-only from TuTienCore.
        // No groups are created/deleted and no prefixes/parents are changed.
        if (plugin.getConfig().getBoolean("integrations.luckperms-auto-manage", false)) {
            plugin.getLogger().warning("luckperms-auto-manage=true is intentionally unsupported in 2.6.0; no LuckPerms mutations will be performed.");
        }
    }

    public void setupStaffGroups() {
        // Staff groups are configured manually with LuckPerms commands.
    }

    public boolean purchase(Player p) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        int current = Math.max(1, d.rankLevel());
        int max = visibleMaxRank();

        if (current >= max) {
            p.sendMessage("§6§lRank §7| §f" + name(current) + " §7| §eHiện tại chỉ mở đến rank " + max + ".");
            return false;
        }

        int next = current + 1;
        int cost = costForNext(current);
        if (!playerPoints.available()) {
            p.sendMessage("§cPlayerPoints chưa được cài hoặc chưa bật. Không thể mua rank.");
            return false;
        }

        int balance = playerPoints.balance(p);
        if (balance < cost) {
            p.sendMessage("§cCần §e" + cost + " PlayerPoints §cđể lên §f" + name(next)
                    + "§c. Bạn đang có §e" + balance + "§c.");
            return false;
        }

        if (!playerPoints.take(p, cost)) {
            p.sendMessage("§cTrừ PlayerPoints thất bại. Vui lòng thử lại.");
            return false;
        }

        d.rankLevel(next);
        plugin.getCultivationService().save(p.getUniqueId());

        long reduction = (long) (next - 1)
                * plugin.getConfig().getLong("ranks.training-seconds-per-rank", 10L);
        p.sendMessage("§a✦ Mua thành công: §f" + name(next)
                + " §7(-" + reduction + "s/cycle) §8| §d-" + cost + " PlayerPoints");
        return true;
    }

    public void ensurePlayerRank(Player p) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (d.rankLevel() < 1) d.rankLevel(1);
    }

    public LuckPermsBridge luckPerms() { return luckPerms; }
    public PlayerPointsBridge playerPoints() { return playerPoints; }
}
