package com.tcgame.tutiencore.rank;

import com.tcgame.tutiencore.TuTienCore;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.util.UUID;

/**
 * Optional runtime bridge to PlayerPoints without a compile-time dependency.
 * This keeps TuTienCore buildable while allowing PlayerPoints to be installed on the server.
 */
public final class PlayerPointsBridge {
    private final TuTienCore plugin;

    public PlayerPointsBridge(TuTienCore plugin) {
        this.plugin = plugin;
    }

    public boolean available() {
        return Bukkit.getPluginManager().isPluginEnabled("PlayerPoints");
    }

    public int balance(Player player) {
        if (player == null || !available()) return 0;
        try {
            Object pp = Bukkit.getPluginManager().getPlugin("PlayerPoints");
            Method getApi = pp.getClass().getMethod("getAPI");
            Object api = getApi.invoke(pp);
            Method look = api.getClass().getMethod("look", UUID.class);
            Object value = look.invoke(api, player.getUniqueId());
            return value instanceof Number n ? Math.max(0, n.intValue()) : 0;
        } catch (ReflectiveOperationException | RuntimeException ex) {
            plugin.getLogger().warning("PlayerPoints API look failed: " + ex.getMessage());
            return 0;
        }
    }

    public boolean take(Player player, int amount) {
        if (player == null || amount < 0 || !available()) return false;
        if (amount == 0) return true;
        try {
            Object pp = Bukkit.getPluginManager().getPlugin("PlayerPoints");
            Method getApi = pp.getClass().getMethod("getAPI");
            Object api = getApi.invoke(pp);
            Method take = api.getClass().getMethod("take", UUID.class, int.class);
            Object result = take.invoke(api, player.getUniqueId(), amount);
            return Boolean.TRUE.equals(result);
        } catch (ReflectiveOperationException | RuntimeException ex) {
            plugin.getLogger().warning("PlayerPoints API take failed: " + ex.getMessage());
            return false;
        }
    }
}
