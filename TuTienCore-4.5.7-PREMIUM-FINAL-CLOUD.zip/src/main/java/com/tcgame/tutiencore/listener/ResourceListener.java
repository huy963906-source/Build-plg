package com.tcgame.tutiencore.listener;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import org.bukkit.Bukkit;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Resource drops, AFK rewards and automatic Linh Thạch banking. */
public final class ResourceListener implements Listener {
    private final TuTienCore plugin;
    private final Map<UUID, Integer> afkSeconds = new HashMap<>();
    private final BukkitTask task;
    private final Map<UUID, Long> playerKillCooldown = new ConcurrentHashMap<>();

    public ResourceListener(TuTienCore plugin) {
        this.plugin = plugin;
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    @EventHandler
    public void onMobDeath(EntityDeathEvent e) {
        if (!(e.getEntity() instanceof LivingEntity) || e.getEntity() instanceof Player) return;
        Player killer = e.getEntity().getKiller();
        awardDemonicLinhKhi(killer, false);
        if (!plugin.getConfig().getBoolean("linh-thach.mob-drop.enabled", true)) return;
        double chance = plugin.getConfig().getDouble("linh-thach.mob-drop.chance", 100D);
        if (Math.random() * 100D > chance) return;
        int min = Math.max(1, plugin.getConfig().getInt("linh-thach.mob-drop.min", 1));
        int max = Math.max(min, plugin.getConfig().getInt("linh-thach.mob-drop.max", 3));
        int amount = min + (int)(Math.random() * (max - min + 1));
        e.getDrops().add(plugin.getAlchemySystem().createLinhThachItem(amount));
    }

    @EventHandler
    public void onPlayerDeath(EntityDeathEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        awardDemonicLinhKhi(victim.getKiller(), true);
    }

    @EventHandler
    public void preventDemonicPvP(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = null;
        if (e.getDamager() instanceof Player p) attacker = p;
        else if (e.getDamager() instanceof org.bukkit.entity.Projectile projectile && projectile.getShooter() instanceof Player p) attacker = p;
        if (attacker == null) return;
        PlayerData a = plugin.getCultivationService().getPlayerData(attacker.getUniqueId());
        PlayerData v = plugin.getCultivationService().getPlayerData(victim.getUniqueId());
        if (isDemonic(a) && isDemonic(v)) {
            e.setCancelled(true);
            attacker.sendActionBar("§c✦ Ma Tu và Quỷ Tu không thể giao chiến với nhau.");
        }
    }

    private boolean isDemonic(PlayerData d) { return d.cultivationClass().equalsIgnoreCase("MA_TU") || d.cultivationClass().equalsIgnoreCase("QUY_TU"); }

    private void awardDemonicLinhKhi(Player killer, boolean playerKill) {
        if (killer == null || !killer.isOnline()) return;
        PlayerData d = plugin.getCultivationService().getPlayerData(killer.getUniqueId());
        if (!isDemonic(d)) return;
        if (playerKill) {
            long now = System.currentTimeMillis();
            Long last = playerKillCooldown.get(killer.getUniqueId());
            long cooldown = Math.max(0L, plugin.getConfig().getLong("demonic-cultivation.player-kill-cooldown-seconds", 60L)) * 1000L;
            if (last != null && now - last < cooldown) {
                killer.sendActionBar("§7✦ Đối tượng này chưa thể cho thêm Linh Khí.");
                return;
            }
            playerKillCooldown.put(killer.getUniqueId(), now);
        }
        String path = playerKill ? "demonic-cultivation.player-kill-linh-khi" : (d.cultivationClass().equalsIgnoreCase("MA_TU") ? "demonic-cultivation.ma-tu.mob-linh-khi" : "demonic-cultivation.quy-tu.mob-linh-khi");
        double amount = Math.max(0D, plugin.getConfig().getDouble(path, playerKill ? 150D : 30D));
        d.addLinhKhi(amount);
        plugin.getCultivationService().save(killer.getUniqueId());
        killer.sendActionBar("§5☠ +" + String.format(java.util.Locale.ROOT, "%.0f", amount) + " Linh Khí từ sát sinh §7| §f" + String.format(java.util.Locale.ROOT, "%.0f", d.linhKhi()) + "/" + d.maxLinhKhi());
        killer.getWorld().spawnParticle(org.bukkit.Particle.SOUL, killer.getLocation().add(0,1,0), 18, .45,.7,.45,.03);
    }

    /** Prevent intentionally throwing Linh Thạch stacks onto the ground, which can be abused to create huge item-entity counts. */
    @EventHandler
    public void onLinhThachDrop(PlayerDropItemEvent e) {
        ItemStack stack = e.getItemDrop().getItemStack();
        if (!plugin.getAlchemySystem().isLinhThach(stack)) return;
        if (!plugin.getConfig().getBoolean("auto-cat-linh-thach.prevent-manual-drop", true)) return;
        int amount = stack.getAmount();
        // The drop event has already detached the stack from the inventory. Do not cancel
        // the event, otherwise some servers restore the stack and create a duplication bug.
        e.getItemDrop().remove();
        deposit(e.getPlayer(), amount, false);
        e.getPlayer().sendActionBar("§e✦ Linh Thạch không thể vứt ra đất — đã cất vào Không Gian Linh Thạch.");
    }

    private void tick() {
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            autoCollectLinhThach(p);

            AfkReward reward = getAfkReward(p);
            if (reward == null) {
                afkSeconds.remove(p.getUniqueId());
                continue;
            }

            int interval = Math.max(10, plugin.getConfig().getInt("afk.interval-seconds", 120));
            int seconds = afkSeconds.merge(p.getUniqueId(), 1, Integer::sum);
            int left = Math.max(0, interval - seconds);
            int mm = left / 60, ss = left % 60;
            p.sendTitle("§d§l✦ AFK ✦", String.format("§f%02d:%02d", mm, ss), 0, 20, 0);
            if (seconds < interval) continue;
            afkSeconds.put(p.getUniqueId(), 0);
            p.sendTitle("§a§l✦ AFK HOÀN TẤT ✦", "§f+ phần thưởng", 0, 25, 5);

            int mult = rankMultiplier(plugin.getCultivationService().getPlayerData(p.getUniqueId()).rankLevel());
            if (reward.money()) {
                double amount = plugin.getConfig().getDouble("afk.money-base", 700D) * mult;
                if (plugin.getEconomyService().deposit(p, amount)) {
                    p.sendMessage("§6✦ AFK §7| §a+§f" + format(amount) + " §aTiền");
                }
            }
            if (reward.linhThach()) {
                int amount = plugin.getConfig().getInt("afk.linh-thach-base", 2) * mult;
                // AFK rewards go straight to the Linh Thạch bank; they never create item entities.
                plugin.getLinhThachBankService().deposit(p.getUniqueId(), BigInteger.valueOf(amount));
                p.sendMessage("§b✦ AFK §7| §a+§f" + amount + " §bLinh Thạch");
            }
        }
    }

    private void autoCollectLinhThach(Player p) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (!d.autoCatLinhThach()) return;

        int total = 0;
        // Inventory -> bank.
        for (int slot = 0; slot < p.getInventory().getSize(); slot++) {
            ItemStack item = p.getInventory().getItem(slot);
            if (!plugin.getAlchemySystem().isLinhThach(item)) continue;
            total += item.getAmount();
            p.getInventory().setItem(slot, null);
        }

        // Ground Linh Thạch within 5 blocks -> bank. Remove the entity before depositing.
        double radius = Math.max(1D, plugin.getConfig().getDouble("auto-cat-linh-thach.radius", 5D));
        for (Item item : p.getWorld().getNearbyEntitiesByType(Item.class, p.getLocation(), radius, radius, radius)) {
            if (!item.isValid() || !plugin.getAlchemySystem().isLinhThach(item.getItemStack())) continue;
            total += item.getItemStack().getAmount();
            item.remove();
        }

        if (total > 0) {
            deposit(p, total, true);
        }
    }

    private void deposit(Player p, int amount, boolean actionBar) {
        if (amount <= 0) return;
        BigInteger balance = plugin.getLinhThachBankService().deposit(p.getUniqueId(), BigInteger.valueOf(amount));
        plugin.getLinhThachBankService().save();
        if (actionBar) p.sendActionBar("§e✦ +" + amount + " Linh Thạch → Không Gian Linh Thạch §7(" + balance + ")");
    }

    private AfkReward getAfkReward(Player player) {
        if (!plugin.getServer().getPluginManager().isPluginEnabled("WorldGuard")) return null;
        RegionManager manager = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(player.getWorld()));
        if (manager == null) return null;
        var applicable = manager.getApplicableRegions(BukkitAdapter.asBlockVector(player.getLocation()));
        boolean money = false;
        boolean linhThach = false;
        for (ProtectedRegion region : applicable) {
            String id = region.getId().toLowerCase(java.util.Locale.ROOT);
            if (id.startsWith("tutien_afk_money_")) money = true;
            if (id.startsWith("tutien_afk_linhthach_")) linhThach = true;
        }
        if (!money && !linhThach) return null;
        return new AfkReward(money, linhThach);
    }

    private record AfkReward(boolean money, boolean linhThach) {}

    private int rankMultiplier(int rank) {
        int base = Math.max(1, plugin.getConfig().getInt("afk.rank-multiplier-base", 2));
        int steps = Math.max(0, rank - 1);
        return (int)Math.min(1024L, Math.round(Math.pow(base, steps)));
    }

    private String format(double d) { return String.format(java.util.Locale.ROOT, "%,.0f", d); }
    public void shutdown() { task.cancel(); afkSeconds.clear(); }
}
