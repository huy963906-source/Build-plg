package com.tcgame.tutiencore.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.CraftingInventory;

/**
 * Keeps vanilla player crafting usable.
 *
 * Some inventory listeners can accidentally cancel clicks/drags in the
 * vanilla 2x2/3x3 crafting inventory. This listener only touches
 * CraftingInventory events and leaves custom TuTienCore menus alone.
 */
public final class CraftingFixListener implements Listener {

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCraftClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        if (event.getView().getTopInventory() instanceof CraftingInventory) {
            event.setCancelled(false);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCraftDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        if (event.getView().getTopInventory() instanceof CraftingInventory) {
            event.setCancelled(false);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        if (!(event.getInventory() instanceof CraftingInventory)) return;
        if (event.getRecipe() != null && event.getInventory().getResult() == null) {
            event.getInventory().setResult(event.getRecipe().getResult().clone());
        }
    }
}
