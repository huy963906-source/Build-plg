package com.tcgame.tutiencore.listener;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.menu.AdminMenu;
import com.tcgame.tutiencore.menu.CultivationMenu;
import com.tcgame.tutiencore.menu.SpiritRootMenu;
import com.tcgame.tutiencore.menu.BreakthroughMenu;
import com.tcgame.tutiencore.menu.SectMenu;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockBreakEvent;

public final class CoreListener implements Listener {
    private final TuTienCore plugin;
    public CoreListener(TuTienCore plugin) { this.plugin = plugin; }


    @EventHandler public void onBeaconPlace(BlockPlaceEvent e) {
        if (e.getBlockPlaced().getType() != Material.BEACON) return;
        if (plugin.getSectSystem().isSectCoreItem(e.getItemInHand())) {
            if (!plugin.getSectSystem().placeSectCore(e.getPlayer(), e.getBlockPlaced())) e.setCancelled(true);
            return;
        }
        if (!plugin.getSectSystem().createFromBeacon(e.getPlayer(), e.getBlockPlaced())) {
            e.setCancelled(true);
        }
    }

    @EventHandler public void onLibraryCorePlace(BlockPlaceEvent e) {
        if (!plugin.getSectSystem().isLibraryCoreItem(e.getItemInHand())) return;
        if (!plugin.getSectSystem().createLibraryCore(e.getPlayer(), e.getBlockPlaced())) { e.setCancelled(true); }
    }

    @EventHandler public void onLibraryCoreBreak(BlockBreakEvent e) {
        if (!plugin.getSectSystem().isLibraryCore(e.getBlock())) return;
        e.setCancelled(true);
        e.getPlayer().sendMessage("§cĐây là Tàng Kinh Các Core, không thể phá.");
    }

    @EventHandler public void onSectCoreBreak(BlockBreakEvent e) {
        if (!plugin.getSectSystem().isCore(e.getBlock())) return;
        e.setCancelled(true);
        e.getPlayer().sendMessage("§cDay la Tam Tông Môn, khong the pha.");
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) { plugin.getRankSystem().ensurePlayerRank(e.getPlayer()); plugin.getBreakthroughService().applyPermanentStats(e.getPlayer()); }

    @EventHandler public void onElder(PlayerInteractEntityEvent e) {
        plugin.getInitiationSystem().handleElderInteraction(e);
    }

    @EventHandler public void onBookUse(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (e.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        if (!plugin.getInitiationSystem().isLuyenKhiBook(e.getItem())) return;
        e.setCancelled(true);
        plugin.getInitiationSystem().handleBookUse(e.getPlayer(), e.getItem());
    }


    @EventHandler public void onQuit(PlayerQuitEvent e) {
        plugin.getTrainingManager().stop(e.getPlayer());
        plugin.getPetSystem().removeActive(e.getPlayer());
        plugin.getCultivationService().save(e.getPlayer().getUniqueId());
    }

    @EventHandler public void click(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String title = e.getView().getTitle();
        if (title.equals(CultivationMenu.TITLE)) {
            e.setCancelled(true);
            if (e.getRawSlot() == 23) plugin.getCuaHangMenu().openPet(p);
            else if (e.getRawSlot() == 25) plugin.getCuaHangMenu().openRank(p);
            return;
        }
        if (title.equals(BreakthroughMenu.TITLE)) {
            e.setCancelled(true);
            if (e.getRawSlot() == 11) {
                p.closeInventory();
                plugin.getBreakthroughService().attempt(p);
            } else if (e.getRawSlot() == 15) {
                p.closeInventory();
                plugin.getBreakthroughService().quickAttempt(p);
            } else if (e.getRawSlot() == 22) {
                p.closeInventory();
            }
            return;
        }
        if (title.equals(SectMenu.TITLE)) {
            e.setCancelled(true);
            if (e.getRawSlot() == 19) {
                plugin.getSectSystem().teleportHome(p);
                return;
            }
            if (e.getRawSlot() == 21 || e.getRawSlot() == 25 || e.getRawSlot() == 40) { return; }
            if (e.getRawSlot() == 31) { plugin.getSectSystem().teleportHome(p); return; }
            if (e.getRawSlot() == 23 || e.getRawSlot() == 24) {
                int amount = e.getRawSlot() == 23 ? 100 : 1000;
                if (plugin.getSectSystem().contribute(p, amount)) p.sendMessage("§a✦ Đã đóng góp §e" + amount + " §atiền vào Tông Môn.");
                else p.sendMessage("§cKhông thể đóng góp. Kiểm tra số dư hoặc Tông Môn.");
                plugin.getSectMenu().open(p);
                return;
            }
            if (e.getRawSlot() == 30) {
                PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
                var sect = plugin.getSectSystem().get(d.sectId());
                if (sect != null && sect.owner().equals(p.getUniqueId())) {
                    if (!sect.hasLibraryCore()) {
                        p.getInventory().addItem(plugin.getSectSystem().createLibraryCoreItem());
                        p.sendMessage("§5✦ Đã nhận Tàng Kinh Các Core. §7Đặt xuống để đăng ký Core.");
                    } else p.sendMessage("§7Tông Môn đã có Tàng Kinh Các Core.");
                } else p.sendMessage("§cChỉ Tông Chủ mới nhận được Core.");
                return;
            }
            if (e.getRawSlot() == 32) {
                if (plugin.getSectSystem().leave(p)) p.sendMessage("§aĐã rời Tông Môn.");
                else p.sendMessage("§cKhông thể rời Tông Môn (Tông Chủ phải xử lý Tông Môn trước).");
                p.closeInventory();
                return;
            }
            if (e.getRawSlot() == 49) { p.closeInventory(); return; }
            return;
        }
        if (title.equals(SpiritRootMenu.TITLE)) {
            e.setCancelled(true);
            if (e.getRawSlot() == 22) {
                plugin.getSpiritRootMenu().startRoll(p);
            } else if (e.getRawSlot() == 44) {
                plugin.getSpiritRootMenu().stopAnimation(p);
                plugin.getSpiritRootMenu().stopRoll(p);
                p.closeInventory();
            }
            return;
        }
        if (title.equals(AdminMenu.SELECT_TITLE)) {
            e.setCancelled(true);
            if (e.getRawSlot() < 45) {
                Player target = plugin.getAdminMenu().select(p, e.getRawSlot());
                if (target != null) plugin.getAdminMenu().open(p, target);
            }
            return;
        }
        if (!title.equals(AdminMenu.TITLE)) return;
        e.setCancelled(true);
        ItemStack item = e.getCurrentItem();
        if (item == null || item.getType() == Material.AIR) return;
        if (e.getRawSlot() == 7) { plugin.getAdminMenu().openSelector(p); return; }
        Player target = plugin.getAdminMenu().target(p);
        PlayerData d = plugin.getCultivationService().getPlayerData(target.getUniqueId());
        switch (e.getRawSlot()) {
            case 10 -> d.addLinhKhi(100);
            case 11 -> d.addLinhKhi(1000);
            case 12 -> { plugin.getAdminMenu().input(p, AdminMenu.InputType.LINHKHI_SET); return; }
            case 20 -> giveLinhThach(target, 1000);
            case 21 -> { plugin.getAdminMenu().input(p, AdminMenu.InputType.LINHTHACH_SET); return; }
            case 23, 30 -> d.canCot(d.canCot() + 1);
            case 24 -> { plugin.getBreakthroughService().attempt(target); return; }
            case 25 -> { var next = d.realm().next(); if (next != null) plugin.getTribulationSystem().start(target, next); return; }
            case 26 -> { if (d.realm().name().equals("DO_KIEP") && d.realmStage() >= d.realm().maxStage()) plugin.getTribulationSystem().startFinalAscent(target); return; }
            case 31 -> d.ngoTinh(d.ngoTinh() + 1);
            case 32 -> {
                plugin.getInitiationSystem().unlock(target, true);
                return;
            }
            case 33 -> {
                if (d.realm() == com.tcgame.tutiencore.cultivation.Realm.PHAM_NHAN) {
                    d.realm(com.tcgame.tutiencore.cultivation.Realm.LUYEN_KHI);
                    d.realmStage(1);
                } else if (d.realmStage() < d.realm().maxStage()) {
                    d.realmStage(d.realmStage() + 1);
                } else {
                    var next = d.realm().next();
                    if (next != null) {
                        d.realm(next);
                        d.realmStage(1);
                    }
                }
                d.linhKhi(0);
                p.sendMessage("§d✦ Đã tăng Cảnh Giới của §f" + target.getName() + "§d: §f" + d.realmDisplay());
                target.sendMessage("§d✦ Admin đã tăng Cảnh Giới của bạn lên §f" + d.realmDisplay());
                return;
            }
            case 40 -> { p.closeInventory(); return; }
            default -> { }
        }
        plugin.getCultivationService().save(target.getUniqueId());
        plugin.getAdminMenu().open(p, target);
    }

    private void giveLinhThach(Player player, int amount) {
        int left = amount;
        while (left > 0) {
            int stack = Math.min(64, left);
            for (ItemStack leftover : player.getInventory().addItem(plugin.getAlchemySystem().createLinhThachItem(stack)).values()) player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            left -= stack;
        }
    }

    private void removeAllLinhThach(Player player) {
        for (int slot = 0; slot < player.getInventory().getSize(); slot++) {
            ItemStack item = player.getInventory().getItem(slot);
            if (plugin.getAlchemySystem().isLinhThach(item)) player.getInventory().setItem(slot, null);
        }
    }

    @EventHandler public void drag(InventoryDragEvent e) {
        String title = e.getView().getTitle();
        if (title.equals(AdminMenu.TITLE) || title.equals(AdminMenu.SELECT_TITLE) ||
                title.equals(CultivationMenu.TITLE) || title.equals(BreakthroughMenu.TITLE) ||
                title.equals(SectMenu.TITLE) || title.equals(SpiritRootMenu.TITLE)) e.setCancelled(true);
    }

    @EventHandler public void closeSpiritRootMenu(org.bukkit.event.inventory.InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        if (e.getView().getTitle().equals(SpiritRootMenu.TITLE)) { plugin.getSpiritRootMenu().stopAnimation(p); plugin.getSpiritRootMenu().stopRoll(p); }
    }

    @EventHandler public void chat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        AdminMenu.InputType type = plugin.getAdminMenu().waiting(p);
        if (type == null) return;
        e.setCancelled(true);
        String msg = ChatColor.stripColor(e.getMessage()).trim();
        plugin.getServer().getScheduler().runTask(plugin, () -> handleInput(p, type, msg));
        plugin.getAdminMenu().clear(p);
    }

    private void handleInput(Player p, AdminMenu.InputType type, String msg) {
        if (msg.equalsIgnoreCase("\\cancel")) { p.sendMessage("§7Đã hủy."); return; }
        Player t = plugin.getAdminMenu().target(p);
        try {
            switch (type) {
                case LINHKHI_SET -> plugin.getCultivationService().setLinhKhi(t.getUniqueId(), Double.parseDouble(msg));
                case LINHTHACH_SET -> {
                    int desired = Integer.parseInt(msg);
                    removeAllLinhThach(t);
                    if (desired > 0) giveLinhThach(t, desired);
                }
                case CANCOT_SET -> plugin.getCultivationService().getPlayerData(t.getUniqueId()).canCot(Double.parseDouble(msg));
                case NGOTINH_SET -> plugin.getCultivationService().getPlayerData(t.getUniqueId()).ngoTinh(Double.parseDouble(msg));
            }
            plugin.getCultivationService().save(t.getUniqueId());
            p.sendMessage("§aĐã cập nhật.");
            plugin.getAdminMenu().open(p, t);
        } catch (NumberFormatException ex) { p.sendMessage("§cGiá trị không hợp lệ."); }
    }
}
