package com.tcgame.tutiencore.dungeon;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.entity.Player;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class DungeonSystem {
    private final TuTienCore plugin;
    private final Map<UUID, Integer> wave = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> seconds = new ConcurrentHashMap<>();
    public DungeonSystem(TuTienCore plugin){this.plugin=plugin;plugin.getServer().getScheduler().runTaskTimer(plugin,this::tick,20L,20L);}
    public boolean enter(Player p){if(wave.containsKey(p.getUniqueId()))return false;wave.put(p.getUniqueId(),1);seconds.put(p.getUniqueId(),plugin.getConfig().getInt("dungeon.duration-seconds",60));p.sendMessage("§5✦ Bạn bước vào Bí Cảnh. Wave 1 bắt đầu.");return true;}
    private void tick(){for(UUID u:new ArrayList<>(wave.keySet())){Player p=plugin.getServer().getPlayer(u);if(p==null||!p.isOnline()){wave.remove(u);seconds.remove(u);continue;}int left=seconds.merge(u,-1,Integer::sum);if(left<=0){reward(p);wave.remove(u);seconds.remove(u);continue;}if(left%10==0){int next=wave.merge(u,1,Integer::sum);p.sendMessage("§dBí Cảnh §7| Wave §f"+next);PlayerData d=plugin.getCultivationService().getPlayerData(u);d.addLinhKhi(plugin.getConfig().getDouble("dungeon.reward-linhkhi-per-wave",25));}p.sendActionBar("§5Bí Cảnh §7| Wave §d"+wave.get(u)+" §7| Còn §f"+left+"s");}}
    private void reward(Player p){PlayerData d=plugin.getCultivationService().getPlayerData(p.getUniqueId());double reward = plugin.getConfig().getDouble("dungeon.finish-reward-linhkhi",1000); d.addLinhKhi(reward); p.sendMessage("§6✦ Hoàn thành Bí Cảnh! §f+" + String.format("%.0f", reward) + " Linh Khí");}
}
