package com.tcgame.tutiencore.economy;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

public final class EconomyService {
    private Economy economy;
    public boolean hook() {
        RegisteredServiceProvider<Economy> provider = Bukkit.getServicesManager().getRegistration(Economy.class);
        economy = provider == null ? null : provider.getProvider();
        return economy != null;
    }
    public boolean available() { return economy != null; }
    public double balance(OfflinePlayer player) { return economy == null ? 0D : economy.getBalance(player); }
    public boolean deposit(OfflinePlayer player, double amount) { return economy != null && economy.depositPlayer(player, amount).transactionSuccess(); }
    public boolean withdraw(OfflinePlayer player, double amount) { return economy != null && economy.withdrawPlayer(player, amount).transactionSuccess(); }
}
