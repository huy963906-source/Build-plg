package com.tcgame.tutiencore.economy;

import com.tcgame.tutiencore.TuTienCore;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Separate Linh Thạch currency bank. Stored independently from Vault money and PlayerPoints. */
public final class LinhThachBankService {
    private final TuTienCore plugin;
    private final File file;
    private final Map<UUID, BigInteger> balances = new ConcurrentHashMap<>();

    public LinhThachBankService(TuTienCore plugin) {
        this.plugin = plugin;
        file = new File(plugin.getDataFolder(), "linhthach.yml");
        load();
    }

    public BigInteger balance(UUID uuid) { return balances.getOrDefault(uuid, BigInteger.ZERO); }

    public BigInteger deposit(UUID uuid, BigInteger amount) {
        if (amount == null || amount.signum() <= 0) return balance(uuid);
        BigInteger next = balance(uuid).add(amount);
        balances.put(uuid, next);
        return next;
    }

    public BigInteger deposit(UUID uuid, long amount) { return deposit(uuid, BigInteger.valueOf(amount)); }

    public boolean withdraw(UUID uuid, BigInteger amount) {
        if (amount == null || amount.signum() <= 0) return false;
        BigInteger current = balance(uuid);
        if (current.compareTo(amount) < 0) return false;
        balances.put(uuid, current.subtract(amount));
        return true;
    }

    public void set(UUID uuid, BigInteger amount) {
        balances.put(uuid, amount == null || amount.signum() < 0 ? BigInteger.ZERO : amount);
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, BigInteger> e : balances.entrySet()) y.set("players." + e.getKey(), e.getValue().toString());
        try { y.save(file); } catch (IOException e) { plugin.getLogger().warning("Không lưu được linhthach.yml: " + e.getMessage()); }
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        if (!y.isConfigurationSection("players")) return;
        for (String key : y.getConfigurationSection("players").getKeys(false)) {
            try { balances.put(UUID.fromString(key), new BigInteger(y.getString("players." + key, "0"))); }
            catch (Exception ignored) { }
        }
    }
}
