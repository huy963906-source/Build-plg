package com.tcgame.tutiencore.feature;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.rank.PlayerPointsBridge;
import com.tcgame.tutiencore.cultivation.Realm;
import org.bukkit.*;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.time.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * HyperVN 3.0.0 gameplay layer.  It deliberately sits above the existing
 * TuTienCore systems: survival remains vanilla, while combat/ultimate/event
 * mechanics are added as an RPG layer. Cosmetics never modify combat stats.
 */
public final class HyperVN430System implements Listener {
    public static final int COSMETIC_PRICE = 10;
    private static final long COMBO_WINDOW_MS = 1200L;
    private static final long ULTIMATE_MS = 18_000L;
    private static final double ADVANTAGE = 0.12D;
    private static final String[] CLASSES = {"KIEM_TU","MA_TU","QUY_TU","PHAT_TU","DOC_TU","TAN_TU"};
    private static final Map<String,String> COUNTERS = Map.of(
            "KIEM_TU", "DOC_TU", "DOC_TU", "KIEM_TU",
            "MA_TU", "PHAT_TU", "PHAT_TU", "MA_TU",
            "QUY_TU", "TAN_TU", "TAN_TU", "QUY_TU");

    private final TuTienCore plugin;
    private final PlayerPointsBridge points;
    private final NamespacedKey visualKey;
    private final Map<UUID, ComboState> combos = new ConcurrentHashMap<>();
    private final Map<UUID, Long> ultimateUntil = new ConcurrentHashMap<>();
    private final Map<UUID, String> ultimateType = new ConcurrentHashMap<>();
    private final Set<UUID> catchup = ConcurrentHashMap.newKeySet();
    private final Set<UUID> tidal = ConcurrentHashMap.newKeySet();
    private final Set<Entity> visuals = ConcurrentHashMap.newKeySet();
    private Location tidalLocation;
    private BukkitTask ticker;
    private long catchupDay = -1L;

    public HyperVN430System(TuTienCore plugin) {
        this.plugin = plugin;
        this.points = new PlayerPointsBridge(plugin);
        this.visualKey = new NamespacedKey(plugin, "hypervn430_visual");
        ticker = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 1L, 5L);
        plugin.getServer().getScheduler().runTaskTimer(plugin, this::weeklyEventTick, 20L * 60L, 20L * 60L);
    }

    private void tick() {
        long now = System.currentTimeMillis();
        combos.entrySet().removeIf(e -> e.getValue().expiresAt < now);
        for (UUID id : new ArrayList<>(ultimateUntil.keySet())) {
            if (ultimateUntil.getOrDefault(id, 0L) <= now) endUltimate(id, true);
        }
        updateCatchup();
        if (tidalLocation != null) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                boolean inside = p.getWorld().equals(tidalLocation.getWorld()) && p.getLocation().distanceSquared(tidalLocation) <= 40D * 40D;
                if (inside) tidal.add(p.getUniqueId()); else tidal.remove(p.getUniqueId());
            }
        }
    }

    /** Called by TrainingManager: 1.5x catch-up, 2x weekly event, never multiplicative with money. */
    public double trainingMultiplier(Player p) {
        double m = catchup.contains(p.getUniqueId()) ? 1.50D : 1.0D;
        if (tidal.contains(p.getUniqueId())) m *= 2.0D;
        return m;
    }

    public boolean hasCatchup(Player p) { return catchup.contains(p.getUniqueId()); }
    public boolean inTidalEvent(Player p) { return tidal.contains(p.getUniqueId()); }

    private void updateCatchup() {
        long day = LocalDate.now(ZoneId.systemDefault()).toEpochDay();
        if (day == catchupDay && !catchup.isEmpty()) return;
        catchupDay = day;
        List<Player> online = new ArrayList<>(Bukkit.getOnlinePlayers());
        if (online.isEmpty()) return;
        double avg = online.stream().mapToInt(p -> plugin.getCultivationService().getPlayerData(p.getUniqueId()).cultivationLevel()).average().orElse(0D);
        for (Player p : online) {
            PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
            boolean eligible = avg - d.cultivationLevel() >= 20D;
            // 14-day lifetime is tracked by PlayerData; if an old account has no start, set it now.
            if (eligible) {
                if (d.catchupStartedAt() == 0L) { d.catchupStartedAt(System.currentTimeMillis()); plugin.getCultivationService().save(p.getUniqueId()); }
                eligible = System.currentTimeMillis() - d.catchupStartedAt() <= 14L * 86_400_000L;
            } else if (d.catchupStartedAt() != 0L && avg - d.cultivationLevel() < 20D) {
                d.catchupStartedAt(0L); plugin.getCultivationService().save(p.getUniqueId());
            }
            if (eligible) catchup.add(p.getUniqueId()); else catchup.remove(p.getUniqueId());
        }
    }

    private void weeklyEventTick() {
        LocalDate now = LocalDate.now(ZoneId.systemDefault());
        // Monday 20:00 local time is the weekly event start; keep the event alive for 24 hours.
        if (now.getDayOfWeek() != DayOfWeek.MONDAY) return;
        LocalTime time = LocalTime.now();
        if (time.getHour() != 20 || time.getMinute() > 2) return;
        World world = Bukkit.getWorlds().stream().filter(w -> w.getEnvironment() == World.Environment.NORMAL).findFirst().orElse(null);
        if (world == null) return;
        Random r = new Random(now.toEpochDay());
        Location spawn = world.getSpawnLocation();
        tidalLocation = new Location(world, spawn.getBlockX() + r.nextInt(2001) - 1000, world.getHighestBlockYAt(spawn.getBlockX() + r.nextInt(2001) - 1000, spawn.getBlockZ() + r.nextInt(2001) - 1000) + 2, spawn.getBlockZ() + r.nextInt(2001) - 1000);
        Bukkit.broadcastMessage("§b§l✦ LINH MẠCH TRIỀU TỊCH ✦ §fđã xuất hiện tại §e" + tidalLocation.getBlockX() + ", " + tidalLocation.getBlockY() + ", " + tidalLocation.getBlockZ() + "§f!");
        Bukkit.broadcastMessage("§7Khu vực 40 block quanh Linh Mạch nhận §b×2 Linh Khí§7. Ngự kiếm lên đường!");
    }

    /** Called by ClassSkillSystem after a skill is used. */
    public void onSkillUsed(Player p, String skillId, String classId) {
        ComboState state = combos.computeIfAbsent(p.getUniqueId(), k -> new ComboState());
        long now = System.currentTimeMillis();
        if (now > state.expiresAt) state.index = 0;
        state.index++;
        state.lastSkill = skillId;
        state.expiresAt = now + COMBO_WINDOW_MS;
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        double gain = state.index >= 4 ? 8D : 3D;
        d.addThanThuc(gain);
        if (state.index >= 4) {
            p.sendActionBar("§d✦ COMBO " + state.index + " §7| §bThần Thức §f" + Math.min(100, (int)d.thanThuc()) + "%");
            state.index = 0;
        }
        plugin.getCultivationService().save(p.getUniqueId());
    }

    public boolean useUltimate(Player p) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (d.thanThuc() < 100D) {
            p.sendMessage("§c✦ Thần Thức chưa đầy. §7Hiện tại: §d" + (int)d.thanThuc() + "%");
            return false;
        }
        if (ultimateUntil.containsKey(p.getUniqueId())) {
            p.sendMessage("§cThần Thông đang duy trì."); return false;
        }
        String cls = d.cultivationClass().toUpperCase(Locale.ROOT);
        String type = switch (cls) {
            case "PHAT_TU" -> "THAN_PHAT";
            case "MA_TU", "KIEM_TU" -> "PHAP_THIEN";
            case "QUY_TU" -> "U_MINH";
            case "DOC_TU" -> "VAN_DOC";
            default -> "THIEN_DIEN";
        };
        ultimateUntil.put(p.getUniqueId(), System.currentTimeMillis() + ULTIMATE_MS);
        ultimateType.put(p.getUniqueId(), type);
        d.thanThuc(0D);
        plugin.getCultivationService().save(p.getUniqueId());
        p.sendTitle(type.equals("THAN_PHAT") ? "§6☸ THÂN PHẬT KIM CANG" : "§4✦ PHÁP THIÊN TƯỢNG ĐỊA", "§7THẦN THÔNG TỐI THƯỢNG", 5, 30, 10);
        p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.8f, type.equals("THAN_PHAT") ? 1.3f : 0.7f);
        spawnUltimateVisual(p, type);
        return true;
    }

    private void spawnUltimateVisual(Player p, String type) {
        cleanupVisuals(p.getUniqueId());
        Location base = p.getLocation().add(0, 0.1, 0);
        Material mat = switch (type) {
            case "THAN_PHAT" -> Material.GOLD_BLOCK;
            case "PHAP_THIEN" -> Material.OBSIDIAN;
            case "U_MINH" -> Material.CRYING_OBSIDIAN;
            case "VAN_DOC" -> Material.EMERALD_BLOCK;
            default -> Material.QUARTZ_BLOCK;
        };
        ItemDisplay body = p.getWorld().spawn(base, ItemDisplay.class);
        body.getPersistentDataContainer().set(visualKey, PersistentDataType.STRING, p.getUniqueId().toString());
        body.setItemStack(new org.bukkit.inventory.ItemStack(mat));
        body.setBillboard(Display.Billboard.CENTER);
        float scale = type.equals("THAN_PHAT") ? 4.8f : 4.0f;
        body.setTransformation(new Transformation(new Vector3f(0, 1.2f, 0), new Quaternionf(), new Vector3f(scale, scale, scale), new Quaternionf()));
        visuals.add(body);
        for (int i = 0; i < 3; i++) {
            Location ring = base.clone().add(0, 1.5 + i * 1.1, 0);
            ItemDisplay aura = p.getWorld().spawn(ring, ItemDisplay.class);
            aura.getPersistentDataContainer().set(visualKey, PersistentDataType.STRING, p.getUniqueId().toString());
            aura.setItemStack(new org.bukkit.inventory.ItemStack(type.equals("THAN_PHAT") ? Material.SUNFLOWER : Material.REDSTONE_BLOCK));
            aura.setBillboard(Display.Billboard.CENTER);
            aura.setTransformation(new Transformation(new Vector3f(), new Quaternionf().rotateY(i), new Vector3f(1.5f + i, .15f, 1.5f + i), new Quaternionf()));
            visuals.add(aura);
        }
    }

    private void animateUltimate(Player p) {
        String type = ultimateType.get(p.getUniqueId());
        if (type == null) return;
        Location c = p.getLocation().add(0, 1, 0);
        Particle particle = switch (type) {
            case "THAN_PHAT" -> Particle.END_ROD;
            case "VAN_DOC" -> Particle.DUST;
            case "U_MINH" -> Particle.SOUL;
            case "THIEN_DIEN" -> Particle.ENCHANT;
            default -> Particle.CRIMSON_SPORE;
        };
        if (particle == Particle.DUST) {
            Particle.DustOptions d = new Particle.DustOptions(Color.fromRGB(80, 220, 80), 1.5f);
            p.getWorld().spawnParticle(particle, c, 18, 3, 2.5, 3, 0, d);
        } else p.getWorld().spawnParticle(particle, c, 18, 3, 2.5, 3, .02);
        if (p.getWorld().getGameTime() % 20 == 0) p.playSound(c, Sound.BLOCK_BEACON_AMBIENT, .25f, type.equals("THAN_PHAT") ? 1.5f : .7f);
    }

    private void endUltimate(UUID id, boolean expired) {
        Player p = Bukkit.getPlayer(id);
        cleanupVisuals(id);
        ultimateUntil.remove(id); ultimateType.remove(id);
        if (p != null && p.isOnline()) {
            p.sendActionBar("§7✦ Thần Thông kết thúc.");
            if (expired) p.playSound(p.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, .5f, 1f);
        }
    }

    private void cleanupVisuals(UUID owner) {
        for (Entity e : new ArrayList<>(visuals)) {
            String raw = e.getPersistentDataContainer().get(visualKey, PersistentDataType.STRING);
            if (owner.toString().equals(raw)) { e.remove(); visuals.remove(e); }
        }
    }

    public boolean isUltimateActive(Player p) { return ultimateUntil.containsKey(p.getUniqueId()); }
    public double combatMultiplier(Player attacker, Player victim) {
        String a = plugin.getCultivationService().getPlayerData(attacker.getUniqueId()).cultivationClass();
        String b = plugin.getCultivationService().getPlayerData(victim.getUniqueId()).cultivationClass();
        if (COUNTERS.getOrDefault(a, "").equalsIgnoreCase(b)) return 1D + ADVANTAGE;
        return 1D;
    }

    public int pointBalance(Player p) { return points.balance(p); }
    public boolean buyCosmetic(Player p, String id) {
        if (!points.available()) { p.sendMessage("§cPlayerPoints chưa được bật."); return false; }
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        if (d.ownsCosmetic(id)) { d.activeCosmetic(id); plugin.getCultivationService().save(p.getUniqueId()); p.sendMessage("§aĐã chọn cosmetic §f" + id + "§a."); return true; }
        if (!points.take(p, COSMETIC_PRICE)) { p.sendMessage("§cCần §e10 PlayerPoints§c."); return false; }
        d.addCosmetic(id); d.activeCosmetic(id); plugin.getCultivationService().save(p.getUniqueId());
        p.sendMessage("§a✦ Đã mua §f" + id + " §avới giá §d10 PlayerPoints§a.");
        return true;
    }

    public static List<String> cosmeticIds() {
        return List.of("PHAP_TUONG_KIEM", "PHAP_TUONG_MA", "PHAP_TUONG_QUY", "PHAP_TUONG_PHAT", "PHAP_TUONG_DOC", "PHAP_TUONG_TAN",
                "PHI_KIEM_THANH_VAN", "PHI_KIEM_HUYET_NGUYET", "PHI_KIEM_CUU_THIEN", "AURA_THIEN_DAO", "AURA_HAC_KIM", "AURA_TINH_HA",
                "THIEN_KIEP_HAC_LONG", "THIEN_KIEP_XICH_LOI", "THIEN_KIEP_TINH_HA");
    }

    private void animateAndDraw() { for (Player p : Bukkit.getOnlinePlayers()) if (isUltimateActive(p)) animateUltimate(p); }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void command(PlayerCommandPreprocessEvent e) {
        String raw = e.getMessage().trim();
        if (!raw.startsWith("/")) return;
        String[] a = raw.substring(1).split("\\s+");
        String cmd = a[0].toLowerCase(Locale.ROOT);
        Player p = e.getPlayer();
        if (cmd.equals("thanthuc") || cmd.equals("thongthan") || cmd.equals("phaptuong")) {
            e.setCancelled(true); useUltimate(p);
        } else if (cmd.equals("combo")) {
            e.setCancelled(true); PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
            p.sendMessage("§d✦ Combo §f4 phím • §bThần Thức §f" + (int)d.thanThuc() + "% • §7Cửa sổ §f1.2s");
        } else if (cmd.equals("hyper430")) {
            e.setCancelled(true); p.sendMessage("§b§lHYPERVN 3.0.0 §7| §f6 Phái • 72 Skill • Combo • Khắc chế 12% • Thần Thông • P2S 10 Point");
        }
    }

    public void shutdown() {
        if (ticker != null) ticker.cancel();
        for (Entity e : new ArrayList<>(visuals)) if (e != null && e.isValid()) e.remove();
        visuals.clear(); combos.clear(); ultimateUntil.clear(); ultimateType.clear();
    }

    private static final class ComboState { int index; String lastSkill = ""; long expiresAt; }
}
