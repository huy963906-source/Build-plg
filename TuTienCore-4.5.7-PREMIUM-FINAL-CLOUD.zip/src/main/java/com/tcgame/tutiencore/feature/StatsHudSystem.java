package com.tcgame.tutiencore.feature;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Unified RPG stats + floating HUD.
 *
 * Rules locked by the server design:
 * - Armor increases Max Health.
 * - Cultivation level (Tu Vi/Cảnh Giới + Tầng) increases Max Health and Physical Damage.
 * - Linh Khí remains a cultivation resource and is never converted into HP or damage.
 */
public final class StatsHudSystem implements Listener {
    private static final String HEALTH_MOD = "tutien_armor_tuvi_health";
    private static final String DAMAGE_MOD = "tutien_tuvi_physical_damage";

    private final TuTienCore plugin;
    private final Map<UUID, TextDisplay> displays = new HashMap<>();
    private final Map<UUID, String> lastText = new HashMap<>();
    private BukkitTask task;

    public StatsHudSystem(TuTienCore plugin) {
        this.plugin = plugin;
    }

    public void start() {
        if (task != null) return;
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 2L, 5L);
        for (Player player : Bukkit.getOnlinePlayers()) ensureDisplay(player);
    }

    public void shutdown() {
        if (task != null) task.cancel();
        task = null;
        for (TextDisplay display : displays.values()) if (!display.isDead()) display.remove();
        displays.clear();
        lastText.clear();
        for (Player player : Bukkit.getOnlinePlayers()) resetModifiers(player);
    }

    private void tick() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            updateStats(player);
            updateHud(player);
        }
    }

    private void updateStats(Player player) {
        PlayerData data = plugin.getCultivationService().getPlayerData(player.getUniqueId());
        int level = Math.max(0, data.cultivationLevel());
        double armor = getArmorPoints(player);
        double healthPerArmor = plugin.getConfig().getDouble("stats.health-per-armor", 1.0D);
        double healthPerTuVi = plugin.getConfig().getDouble("stats.health-per-tuvi-level", 2.0D);
        double damagePerTuVi = plugin.getConfig().getDouble("stats.damage-per-tuvi-level", 0.5D);

        double bonusHealth = armor * healthPerArmor + level * healthPerTuVi;
        double bonusDamage = level * damagePerTuVi;

        replaceModifier(player, Attribute.MAX_HEALTH, HEALTH_MOD, bonusHealth);
        replaceModifier(player, Attribute.ATTACK_DAMAGE, DAMAGE_MOD, bonusDamage);

        AttributeInstance max = player.getAttribute(Attribute.MAX_HEALTH);
        if (max != null && player.getHealth() > max.getValue()) player.setHealth(max.getValue());
    }

    private double getArmorPoints(Player player) {
        AttributeInstance armor = player.getAttribute(Attribute.ARMOR);
        return armor == null ? 0D : Math.max(0D, armor.getValue());
    }

    private void replaceModifier(Player player, Attribute attribute, String name, double amount) {
        AttributeInstance instance = player.getAttribute(attribute);
        if (instance == null) return;
        for (AttributeModifier modifier : instance.getModifiers()) {
            if (name.equals(modifier.getName())) instance.removeModifier(modifier);
        }
        if (Math.abs(amount) > 0.00001D) {
            instance.addModifier(new AttributeModifier(UUID.nameUUIDFromBytes((name + player.getUniqueId()).getBytes()), name,
                    amount, AttributeModifier.Operation.ADD_NUMBER));
        }
    }

    private void resetModifiers(Player player) {
        removeModifier(player, Attribute.MAX_HEALTH, HEALTH_MOD);
        removeModifier(player, Attribute.ATTACK_DAMAGE, DAMAGE_MOD);
    }

    private void removeModifier(Player player, Attribute attribute, String name) {
        AttributeInstance instance = player.getAttribute(attribute);
        if (instance == null) return;
        for (AttributeModifier modifier : instance.getModifiers()) {
            if (name.equals(modifier.getName())) instance.removeModifier(modifier);
        }
    }

    private void updateHud(Player player) {
        PlayerData data = plugin.getCultivationService().getPlayerData(player.getUniqueId());
        AttributeInstance max = player.getAttribute(Attribute.MAX_HEALTH);
        AttributeInstance attack = player.getAttribute(Attribute.ATTACK_DAMAGE);
        AttributeInstance armor = player.getAttribute(Attribute.ARMOR);

        double maxHealth = max == null ? 20D : max.getValue();
        double damage = attack == null ? 1D : attack.getValue();
        double armorValue = armor == null ? 0D : armor.getValue();

        String text = ChatColor.RED + "❤ " + fmt(player.getHealth()) + "/" + fmt(maxHealth)
                + ChatColor.DARK_GRAY + " | "
                + ChatColor.WHITE + "⚔ " + fmt(damage)
                + ChatColor.DARK_GRAY + " | "
                + ChatColor.GRAY + "🛡 " + fmt(armorValue)
                + ChatColor.DARK_GRAY + " | "
                + ChatColor.AQUA + "☯ " + fmt(data.linhKhi()) + "/" + fmt(data.maxLinhKhi())
                + "\n"
                + ChatColor.LIGHT_PURPLE + "✦ Tu Vi: " + ChatColor.WHITE + data.realmDisplay();

        TextDisplay display = ensureDisplay(player);
        if (!text.equals(lastText.get(player.getUniqueId()))) {
            display.text(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(text));
            lastText.put(player.getUniqueId(), text);
        }
        display.teleport(player.getLocation().add(0D, plugin.getConfig().getDouble("stats.hud-height", 2.8D), 0D));
    }

    private TextDisplay ensureDisplay(Player player) {
        TextDisplay display = displays.get(player.getUniqueId());
        if (display != null && !display.isDead()) return display;

        display = player.getWorld().spawn(player.getLocation().add(0, 2.8, 0), TextDisplay.class);
        display.setBillboard(TextDisplay.Billboard.CENTER);
        display.setSeeThrough(true);
        display.setShadowed(false);
        display.setDefaultBackground(false);
        display.setPersistent(false);
        display.setViewRange(32F);
        display.setTransformation(new Transformation(
                new Vector3f(0F, 0F, 0F),
                display.getTransformation().getLeftRotation(),
                new Vector3f(1F, 1F, 1F),
                display.getTransformation().getRightRotation()));
        displays.put(player.getUniqueId(), display);
        return display;
    }

    private static String fmt(double value) {
        if (Math.abs(value - Math.rint(value)) < 0.001D) return Long.toString(Math.round(value));
        return String.format(java.util.Locale.ROOT, "%.1f", value);
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) { ensureDisplay(event.getPlayer()); }
    @EventHandler public void onRespawn(PlayerRespawnEvent event) { Bukkit.getScheduler().runTask(plugin, () -> ensureDisplay(event.getPlayer())); }
    @EventHandler public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        TextDisplay display = displays.remove(id);
        if (display != null && !display.isDead()) display.remove();
        lastText.remove(id);
        resetModifiers(event.getPlayer());
    }
    @EventHandler public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player) Bukkit.getScheduler().runTask(plugin, () -> updateStats(player));
    }
    @EventHandler public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getWhoClicked() instanceof Player player) Bukkit.getScheduler().runTask(plugin, () -> updateStats(player));
    }
}
