package com.tcgame.tutiencore.feature;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Lightweight rotating Aura/Bá Khí VFX. Purely cosmetic. */
public final class AuraSystem {
    private final TuTienCore plugin;
    private final Map<UUID, Boolean> enabled = new ConcurrentHashMap<>();
    private final BukkitTask task;

    public AuraSystem(TuTienCore plugin) {
        this.plugin = plugin;
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 2L, 2L);
    }

    public void toggle(Player player) {
        UUID id = player.getUniqueId();
        boolean next = !enabled.getOrDefault(id, false);
        enabled.put(id, next);
        player.sendMessage(next ? "§d✦ Aura §ađã bật." : "§7✦ Aura §cđã tắt.");
    }

    private void tick() {
        if (!plugin.getConfig().getBoolean("aura.enabled", true)) return;
        int points = Math.max(12, Math.min(32, plugin.getConfig().getInt("aura.points", 24)));
        double radius = Math.max(0.5D, Math.min(2.5D, plugin.getConfig().getDouble("aura.radius", 1.35D)));
        double speed = plugin.getConfig().getDouble("aura.speed", 1.4D);
        double phase = System.nanoTime() / 1_000_000_000D * speed;
        for (UUID id : enabled.keySet()) {
            if (!enabled.getOrDefault(id, false)) continue;
            Player p = plugin.getServer().getPlayer(id);
            if (p == null || !p.isOnline() || p.isDead()) { enabled.remove(id); continue; }
            PlayerData d = plugin.getCultivationService().getPlayerData(id);
            Color c = color(d.cultivationClass());
            Particle.DustOptions dust = new Particle.DustOptions(c, 0.9f);
            Location center = p.getLocation().clone().add(0, 1.05, 0);
            for (int i=0;i<points;i++) {
                double a = phase + Math.PI*2D*i/points;
                double y = 0.35D + 0.65D * (0.5D + 0.5D*Math.sin(a*2D));
                Location q = center.clone().add(Math.cos(a)*radius, y, Math.sin(a)*radius);
                p.spawnParticle(Particle.DUST, q, 1, 0,0,0,0,dust);
            }
            p.spawnParticle(Particle.END_ROD, center.clone().add(0,0.8,0), 1, 0.15,0.35,0.15,0.01);
        }
    }

    private Color color(String cls) {
        return switch (cls == null ? "" : cls.toUpperCase()) {
            case "KIEM_TU" -> Color.fromRGB(15,15,20);
            case "MA_TU", "QUY_TU" -> Color.fromRGB(210,20,25);
            case "PHAT_TU" -> Color.fromRGB(255,220,90);
            case "DOC_TU" -> Color.fromRGB(80,220,70);
            default -> Color.fromRGB(80,170,255);
        };
    }

    public void shutdown() { task.cancel(); enabled.clear(); }
}
