package com.tcgame.tutiencore.feature;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.cultivation.Realm;
import org.bukkit.*;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * V3.0.0 progression layer: karma, reincarnation, class-specific combat rules,
 * pet tribulation protection and the Tán Tu copy mechanic.
 * Bukkit world/entity operations intentionally stay on the main thread.
 */
public final class WorldRpgV3System implements Listener {
    private final TuTienCore plugin;
    private final NamespacedKey bloodKey;
    private final Map<UUID, Long> bloodSacrificeUntil = new ConcurrentHashMap<>();

    public WorldRpgV3System(TuTienCore plugin) {
        this.plugin = plugin;
        this.bloodKey = new NamespacedKey(plugin, "blood-sacrifice");
    }

    public boolean isBloodSacrificeActive(UUID id) {
        Long until = bloodSacrificeUntil.get(id);
        if (until == null) return false;
        if (until <= System.currentTimeMillis()) { bloodSacrificeUntil.remove(id); return false; }
        return true;
    }

    public boolean reincarnate(Player p) {
        PlayerData d = data(p);
        if (d.realm() != Realm.THIEN_DAO_CHU_TE || !d.finalTribulationPassed()) {
            p.sendMessage("§cBạn chưa đạt đỉnh phong Thiên Đạo Chủ Tể và vượt qua đại kiếp cuối.");
            return false;
        }
        long gain = Math.max(1L, 100L + d.congDuc() / 100L - d.nghiepLuc() / 200L);
        d.addThanLucLuanHoi(gain);
        int count = d.incrementLuanHoiCount();
        double damageGain = Math.min(25D, d.thanLucLuanHoi() * 0.05D);
        double cdGain = Math.min(30D, d.thanLucLuanHoi() * 0.03D);
        d.hiddenDamagePercent(damageGain);
        d.hiddenCooldownReductionPercent(cdGain);
        d.realm(Realm.LUYEN_KHI);
        d.realmStage(1);
        d.linhKhi(0);
        d.finalTribulationPassed(false);
        d.breakthroughCount(0);
        // Luân hồi keeps the chosen path, spirit root and learned knowledge; the character's realm progress resets.
        plugin.getCultivationService().save(p.getUniqueId());
        p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, p.getLocation().add(0,1,0), 80, .8,1,.8,.12);
        p.playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1f, .7f);
        p.sendMessage("§d§l✦ LUÂN HỒI THÀNH CÔNG ✦");
        p.sendMessage("§7Lần luân hồi: §f"+count+" §7| Thần Lực: §e+"+gain);
        p.sendMessage("§7Thiên Phú Ẩn: §c+"+String.format(Locale.ROOT,"%.2f",damageGain)+"% sát thương §7| §b-"+String.format(Locale.ROOT,"%.2f",cdGain)+"% hồi chiêu");
        return true;
    }

    public boolean bloodSacrifice(Player p) {
        PlayerData d = data(p);
        if (!(d.cultivationClass().equals("MA_TU") || d.cultivationClass().equals("QUY_TU"))) {
            p.sendMessage("§cChỉ Ma Tu và Quỷ Tu mới được dùng Huyết Tế Linh Thú."); return false;
        }
        if (d.activePetId().isBlank()) { p.sendMessage("§cBạn phải đang có Linh Thú hộ pháp mới có thể Huyết Tế."); return false; }
        if (isBloodSacrificeActive(p.getUniqueId())) { p.sendMessage("§eHuyết Tế đang còn hiệu lực."); return false; }
        plugin.getPetSystem().removeActive(p);
        long until = System.currentTimeMillis() + 15_000L;
        bloodSacrificeUntil.put(p.getUniqueId(), until);
        p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 15*20, 4, false, true, true));
        d.addNghiepLuc(500);
        plugin.getCultivationService().save(p.getUniqueId());
        p.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, p.getLocation().add(0,1,0), 70, .8,1,.8,.2);
        p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, .6f, 1.2f);
        p.sendMessage("§4§l✦ HUYẾT TẾ LINH THÚ ✦ §c+150% công lực trong 15 giây");
        p.sendMessage("§7Nghiệp lực §c+500§7. Linh Thú đã mất.");
        return true;
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        PlayerData d = data(p);
        if (e.getCause() == EntityDamageEvent.DamageCause.LIGHTNING && !d.activePetId().isBlank()) {
            double absorbed = e.getDamage() * .30D;
            e.setDamage(e.getDamage() * .70D);
            p.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, p.getLocation().add(0,1,0), 25, .5,.8,.5,.08);
            p.sendActionBar("§bLinh Thú hộ pháp đã gánh " + String.format(Locale.ROOT,"%.1f",absorbed) + " sát thương Lôi Kiếp");
        }
        if (isBloodSacrificeActive(p.getUniqueId())) {
            // PvP burst is offensive; the defensive side is unchanged.
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onDamageByEntity(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player attacker)) return;
        PlayerData a = data(attacker);
        if (isBloodSacrificeActive(attacker.getUniqueId()) && e.getEntity() instanceof Player) e.setDamage(e.getDamage()*2.5D);
        if (a.cultivationClass().equals("MA_TU") || a.cultivationClass().equals("QUY_TU")) {
            if (e.getEntity() instanceof Player victim) {
                PlayerData v = data(victim);
                if ((a.cultivationClass().equals("MA_TU") && v.cultivationClass().equals("QUY_TU")) || (a.cultivationClass().equals("QUY_TU") && v.cultivationClass().equals("MA_TU"))) {
                    e.setCancelled(true);
                    attacker.sendMessage("§5Ma Tu và Quỷ Tu đồng đạo không thể tàn sát lẫn nhau.");
                }
            }
        }
        double bonus = 1D + a.hiddenDamagePercent()/100D;
        if (bonus > 1D && a.luanHoiCount() > 0) e.setDamage(e.getDamage()*bonus);
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onDeath(EntityDeathEvent e) {
        LivingEntity dead = e.getEntity();
        Player killer = dead.getKiller();
        if (killer == null) return;
        PlayerData d = data(killer);
        if (d.cultivationClass().equals("MA_TU") || d.cultivationClass().equals("QUY_TU")) {
            double gain = dead instanceof Player ? 150D : 35D;
            d.addLinhKhi(gain);
            d.addNghiepLuc(dead instanceof Player ? 80 : 2);
            plugin.getCultivationService().save(killer.getUniqueId());
            killer.sendActionBar("§5+"+String.format(Locale.ROOT,"%.0f",gain)+" Linh Khí §8| §cNghiệp +"+(dead instanceof Player ? 80 : 2));
        }
        if (d.cultivationClass().equals("TAN_TU") && dead instanceof Player victim) {
            PlayerData vd = data(victim);
            var learned = plugin.getClassSkillSystem().skills(vd.cultivationClass()).stream().filter(s -> vd.classSkillLevel(s.id()) > 0).toList();
            if (!learned.isEmpty()) {
                var skill = learned.get(java.util.concurrent.ThreadLocalRandom.current().nextInt(learned.size()));
                if (!d.hasStolenSkill(skill.id())) {
                    d.addStolenSkill(skill.id());
                    d.classSkillLevel(skill.id(), 1);
                    plugin.getConfig().set("class-skill-selected."+killer.getUniqueId(), skill.id());
                    plugin.saveConfig();
                    killer.sendMessage("§d✦ Tán Tu học lỏm được bí kỹ §f"+skill.name()+" §d(Cấp 1)");
                    plugin.getCultivationService().save(killer.getUniqueId());
                }
            }
        }
    }


    @EventHandler(priority=EventPriority.HIGHEST)
    public void onTribulationDeath(PlayerDeathEvent e) {
        Player p=e.getEntity();
        if (!plugin.getTribulationSystem().isInTribulation(p.getUniqueId())) return;
        PlayerData d=data(p);
        if (d.congDuc() >= d.nghiepLuc()) {
            e.setKeepInventory(true);
            e.setKeepLevel(true);
            e.getDrops().clear();
            p.sendMessage("§a✦ Công Đức che chở: bạn giữ nguyên trang bị sau khi thất bại Thiên Kiếp.");
        } else {
            e.setKeepInventory(false);
            p.getWorld().spawnParticle(Particle.EXPLOSION, p.getLocation().add(0,1,0), 2, .4,.4,.4,.02);
            p.sendMessage("§4✦ Nghiệp Lực quá nặng: Thiên Kiếp phá hủy toàn bộ trang bị rơi xuống đất.");
        }
    }

    private PlayerData data(Player p) { return plugin.getCultivationService().getPlayerData(p.getUniqueId()); }
}
