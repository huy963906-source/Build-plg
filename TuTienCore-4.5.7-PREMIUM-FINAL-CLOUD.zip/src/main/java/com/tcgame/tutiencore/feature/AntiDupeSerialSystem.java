package com.tcgame.tutiencore.feature;

import com.tcgame.tutiencore.TuTienCore;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/** Serial/PDC protection for high-value items. It is deliberately conservative to avoid false positives on normal items. */
public final class AntiDupeSerialSystem implements Listener {
    private final TuTienCore plugin;
    private final NamespacedKey serialKey;
    private final BukkitTask scanTask;

    public AntiDupeSerialSystem(TuTienCore plugin) {
        this.plugin = plugin;
        this.serialKey = new NamespacedKey(plugin, "serial-id");
        scanTask = Bukkit.getScheduler().runTaskTimer(plugin, this::scanInventories, 100L, 100L);
    }

    public void shutdown() { scanTask.cancel(); }

    public ItemStack stamp(ItemStack item) {
        if (!valuable(item)) return item;
        ItemMeta meta = item.getItemMeta(); if (meta == null) return item;
        if (!meta.getPersistentDataContainer().has(serialKey, PersistentDataType.STRING)) {
            meta.getPersistentDataContainer().set(serialKey, PersistentDataType.STRING, UUID.randomUUID().toString());
            item.setItemMeta(meta);
        }
        return item;
    }

    public String serial(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(serialKey, PersistentDataType.STRING);
    }

    public boolean valuable(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        if (item.getType().name().contains("NETHERITE") || item.getType() == Material.ELYTRA || item.getType() == Material.MACE || item.getType() == Material.TRIDENT) return true;
        if (item.getEnchantments() != null && !item.getEnchantments().isEmpty()) return true;
        if (item.hasItemMeta()) {
            ItemMeta m=item.getItemMeta();
            return m.hasDisplayName() || m.hasLore() || m.getPersistentDataContainer().getKeys().stream().anyMatch(k -> !k.equals(serialKey));
        }
        return false;
    }

    private void scanInventories() {
        Map<String, Player> seen = new HashMap<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            ItemStack[] contents = p.getInventory().getContents();
            for (int slot=0; slot<contents.length; slot++) {
                ItemStack item=contents[slot]; if(!valuable(item)) continue; stamp(item);
                String id=serial(item); if(id==null) continue;
                Player old=seen.putIfAbsent(id,p);
                if(old!=null && !old.getUniqueId().equals(p.getUniqueId())) {
                    regenerate(p,slot,item,id,old.getName());
                }
            }
        }
    }

    private void regenerate(Player p,int slot,ItemStack item,String old,String other) {
        ItemMeta m=item.getItemMeta(); if(m==null)return;
        String newId=UUID.randomUUID().toString();
        m.getPersistentDataContainer().set(serialKey,PersistentDataType.STRING,newId);
        item.setItemMeta(m); p.getInventory().setItem(slot,item);
        plugin.getLogger().warning("[SERIAL-DUPE] Trùng serial "+old+" giữa "+p.getName()+" và "+other+"; đã đổi serial stack tại "+p.getName()+".");
        notifyStaff("§c[SERIAL] Phát hiện serial trùng: §f"+old+" §7("+p.getName()+" / "+other+")");
    }

    private void notifyStaff(String msg) { for(Player p:Bukkit.getOnlinePlayers()) if(p.isOp()||p.hasPermission("tutien.admin")||p.hasPermission("tutien.staff")) p.sendMessage(msg); }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true) public void onClick(InventoryClickEvent e){ if(e.getWhoClicked() instanceof Player p){ stamp(e.getCurrentItem()); stamp(e.getCursor()); Bukkit.getScheduler().runTask(plugin,this::scanInventories); } }
    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true) public void onDrag(InventoryDragEvent e){ stamp(e.getOldCursor()); if(e.getWhoClicked() instanceof Player) Bukkit.getScheduler().runTask(plugin,this::scanInventories); }
    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true) public void onMove(InventoryMoveItemEvent e){ stamp(e.getItem()); }
    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true) public void onClose(InventoryCloseEvent e){ if(e.getPlayer() instanceof Player) Bukkit.getScheduler().runTask(plugin,this::scanInventories); }
    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true) public void onDrop(PlayerDropItemEvent e){ stamp(e.getItemDrop().getItemStack()); }
    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true) public void onPickup(EntityPickupItemEvent e){ if(e.getEntity() instanceof Player p){ stamp(e.getItem().getItemStack()); Bukkit.getScheduler().runTask(plugin,this::scanInventories); } }
}
