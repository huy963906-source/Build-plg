package com.tcgame.tutiencore.feature;

import com.tcgame.tutiencore.TuTienCore;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.entity.Projectile;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Hộ Thể, Lôi Đài 1v1 sinh tử, Ma/Quỷ đồng minh và nhạc nền. */
public final class ServerFeatureSystem implements Listener {
    private final TuTienCore plugin;
    private final Set<UUID> hoThe = ConcurrentHashMap.newKeySet();
    private final Map<UUID, UUID> pending = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> duels = new ConcurrentHashMap<>();
    private final Set<UUID> music = ConcurrentHashMap.newKeySet();
    private BukkitTask musicTask;

    public ServerFeatureSystem(TuTienCore plugin) { this.plugin = plugin; startMusicLoop(); }
    public boolean isDuel(Player p) { return p != null && duels.containsKey(p.getUniqueId()); }

    public boolean handleHothe(Player p) {
        if (isDuel(p)) { p.sendMessage("§cĐang ở Lôi Đài, không thể dùng /hothe."); return true; }
        UUID id=p.getUniqueId(); if (hoThe.contains(id)) { p.sendMessage("§eHộ Thể đang hoạt động."); return true; }
        hoThe.add(id); p.setInvulnerable(true); p.setFireTicks(0); p.setFreezeTicks(0); p.setFallDistance(0);
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE,20*30,4,false,false,false));
        p.addPotionEffect(new PotionEffect(PotionEffectType.SATURATION,20*30,4,false,false,false));
        p.sendTitle("§b§l✦ HỘ THỂ ✦","§fBảo hộ trong §e30 giây",5,35,10); p.playSound(p.getLocation(),Sound.BLOCK_BEACON_ACTIVATE,1f,1.6f);
        Bukkit.getScheduler().runTaskLater(plugin,()->endHothe(p),20L*30L); return true;
    }
    private void endHothe(Player p){hoThe.remove(p.getUniqueId());if(p.isOnline()){p.setInvulnerable(false);p.removePotionEffect(PotionEffectType.RESISTANCE);p.removePotionEffect(PotionEffectType.SATURATION);p.sendMessage("§7✦ Hộ Thể đã kết thúc.");}}

    public boolean handleLoiDai(Player p,String[] args){
        if(args.length==0||args[0].equalsIgnoreCase("info")){p.sendMessage("§6§l✦ LÔI ĐÀI SINH TỬ ✦");p.sendMessage("§7Thách đấu: §f/loidai <player>");p.sendMessage("§7Chấp nhận: §f/loidai accept");p.sendMessage("§7Từ chối: §f/loidai deny");p.sendMessage("§7Đầu hàng: §f/loidai surrender");p.sendMessage("§8Admin: /loidai set1 | set2 | setlobby");return true;}
        String sub=args[0].toLowerCase(Locale.ROOT);
        if((sub.equals("set1")||sub.equals("set2")||sub.equals("setlobby"))&&p.hasPermission("tutien.admin")){plugin.getConfig().set("loidai."+sub,p.getLocation());plugin.saveConfig();p.sendMessage("§a✦ Đã đặt vị trí "+sub+" của Lôi Đài.");return true;}
        if(sub.equals("accept"))return accept(p,args.length>=2?args[1]:null);
        if(sub.equals("deny")){UUID challenger=pending.remove(p.getUniqueId());if(challenger!=null){Player c=Bukkit.getPlayer(challenger);if(c!=null)c.sendMessage("§cLời thách đấu đã bị từ chối.");p.sendMessage("§7Đã từ chối.");}else p.sendMessage("§7Không có lời mời.");return true;}
        if(sub.equals("surrender")){if(!isDuel(p)){p.sendMessage("§cBạn không ở Lôi Đài.");return true;}finish(p,getOpponent(p),true);return true;}
        Player target=Bukkit.getPlayerExact(args[0]);if(target==null){p.sendMessage("§cKhông tìm thấy người chơi online.");return true;}if(target.equals(p)){p.sendMessage("§cKhông thể tự thách đấu.");return true;}
        if(isDuel(p)||isDuel(target)){p.sendMessage("§cMột trong hai người đang ở Lôi Đài.");return true;}
        if(!compatibleClasses(p,target)){p.sendMessage("§cMa Tu và Quỷ Tu là đồng minh, không thể đánh nhau.");return true;}
        if(plugin.getConfig().getLocation("loidai.set1")==null||plugin.getConfig().getLocation("loidai.set2")==null){p.sendMessage("§cLôi Đài chưa được admin đặt đủ 2 vị trí.");return true;}
        pending.put(target.getUniqueId(),p.getUniqueId());p.sendMessage("§6⚔ Đã gửi lời thách đấu tới §f"+target.getName()+"§6.");target.sendMessage("§c⚔ §f"+p.getName()+" §cthách đấu bạn sinh tử tại Lôi Đài!");target.sendMessage("§a/loidai accept §7để nhận | §c/loidai deny §7để từ chối");return true;
    }
    private boolean accept(Player p,String challengerName){
        UUID challengerId=pending.remove(p.getUniqueId());if(challengerId==null){p.sendMessage("§cKhông có lời thách đấu đang chờ.");return true;}Player c=Bukkit.getPlayer(challengerId);if(c==null){p.sendMessage("§cNgười thách đấu đã offline.");return true;}
        if(challengerName!=null&&!c.getName().equalsIgnoreCase(challengerName)){p.sendMessage("§cSai tên người thách đấu.");pending.put(p.getUniqueId(),challengerId);return true;}if(!compatibleClasses(c,p)){p.sendMessage("§cMa Tu và Quỷ Tu không được đánh nhau.");return true;}
        Location a=plugin.getConfig().getLocation("loidai.set1"),b=plugin.getConfig().getLocation("loidai.set2");if(a==null||b==null){p.sendMessage("§cLôi Đài chưa được cấu hình.");return true;}
        endHothe(c); endHothe(p); duels.put(c.getUniqueId(),p.getUniqueId());duels.put(p.getUniqueId(),c.getUniqueId());prepare(c,a);prepare(p,b);broadcast("§6⚔ Lôi Đài Sinh Tử: §f"+c.getName()+" §6VS §f"+p.getName()+" §7— chiến đấu bắt đầu!");return true;
    }
    private void prepare(Player p,Location loc){p.teleport(loc);p.setFireTicks(0);p.setFreezeTicks(0);p.setFallDistance(0);p.setHealth(p.getMaxHealth());p.setFoodLevel(20);p.setSaturation(20);p.setInvulnerable(false);p.playSound(loc,Sound.ENTITY_ENDER_DRAGON_GROWL,.65f,1.25f);}
    private boolean compatibleClasses(Player a,Player b){String ca=plugin.getCultivationService().getPlayerData(a.getUniqueId()).cultivationClass(),cb=plugin.getCultivationService().getPlayerData(b.getUniqueId()).cultivationClass();return !((ca.equalsIgnoreCase("MA_TU")||ca.equalsIgnoreCase("QUY_TU"))&&(cb.equalsIgnoreCase("MA_TU")||cb.equalsIgnoreCase("QUY_TU")));}
    private Player getOpponent(Player p){UUID id=duels.get(p.getUniqueId());return id==null?null:Bukkit.getPlayer(id);}

    @EventHandler public void onDamage(EntityDamageEvent e){if(e.getEntity() instanceof Player p&&hoThe.contains(p.getUniqueId()))e.setCancelled(true);}
    @EventHandler public void onPlayerDamage(EntityDamageByEntityEvent e){
        if(!(e.getEntity() instanceof Player victim)) return;
        Player attacker=null;
        if(e.getDamager() instanceof Player p) attacker=p;
        else if(e.getDamager() instanceof Projectile projectile && projectile.getShooter() instanceof Player p) attacker=p;
        if(attacker==null || attacker.equals(victim) || isDuel(attacker) && isDuel(victim)) return;
        if(!compatibleClasses(attacker,victim)) e.setCancelled(true);
    }
    @EventHandler public void onPotion(EntityPotionEffectEvent e){if(e.getEntity() instanceof Player p&&hoThe.contains(p.getUniqueId()))e.setCancelled(true);}
    @EventHandler public void onFood(FoodLevelChangeEvent e){if(e.getEntity() instanceof Player p&&hoThe.contains(p.getUniqueId()))e.setCancelled(true);}
    @EventHandler public void onCombust(EntityCombustEvent e){if(e.getEntity() instanceof Player p&&hoThe.contains(p.getUniqueId()))e.setCancelled(true);}
    @EventHandler public void onVelocity(PlayerVelocityEvent e){if(hoThe.contains(e.getPlayer().getUniqueId()))e.setCancelled(true);}
    @EventHandler public void onMove(PlayerMoveEvent e){if(hoThe.contains(e.getPlayer().getUniqueId()))e.getPlayer().setFallDistance(0);}
    @EventHandler public void onDeath(PlayerDeathEvent e){Player loser=e.getEntity();if(!isDuel(loser))return;e.getDrops().clear();e.setDroppedExp(0);e.setKeepInventory(true);Player winner=getOpponent(loser);finish(loser,winner,false);}

    private void finish(Player loser,Player winner,boolean surrender){duels.remove(loser.getUniqueId());if(winner!=null)duels.remove(winner.getUniqueId());pending.remove(loser.getUniqueId());if(winner!=null)pending.remove(winner.getUniqueId());loser.getInventory().clear();String reason=surrender?"Đầu hàng tại Lôi Đài":"Thua Lôi Đài Sinh Tử";banThreeDays(loser,reason);if(winner!=null){winner.sendTitle("§6§lCHIẾN THẮNG","§fĐối thủ bị xóa đồ + ban 3 ngày",5,45,10);winner.playSound(winner.getLocation(),Sound.UI_TOAST_CHALLENGE_COMPLETE,1f,.8f);Location lobby=plugin.getConfig().getLocation("loidai.setlobby");if(lobby!=null)Bukkit.getScheduler().runTask(plugin,()->winner.teleport(lobby));}broadcast("§6⚔ Lôi Đài kết thúc: §f"+loser.getName()+" §6đã thua và bị ban 3 ngày.");}
    private void banThreeDays(Player p,String reason){Date until=Date.from(Instant.now().plus(3,ChronoUnit.DAYS));Bukkit.getBanList(BanList.Type.NAME).addBan(p.getName(),reason,until,"TuTienCore");if(p.isOnline())p.kickPlayer("§c§lLÔI ĐÀI SINH TỬ\n§7Bạn đã "+reason+".\n§7Ban còn 3 ngày.");}
    @EventHandler public void onQuit(PlayerQuitEvent e){Player p=e.getPlayer();if(isDuel(p)){Player winner=getOpponent(p);p.getInventory().clear();finish(p,winner,true);}if(hoThe.remove(p.getUniqueId()))p.setInvulnerable(false);}
    @EventHandler public void onJoin(PlayerJoinEvent e){if(hoThe.remove(e.getPlayer().getUniqueId()))e.getPlayer().setInvulnerable(false);}

    public void toggleMusic(Player p){UUID id=p.getUniqueId();if(music.remove(id)){p.stopSound(Sound.MUSIC_DISC_OTHERSIDE);p.sendMessage("§7♪ Nhạc nền: §cTẮT");}else{music.add(id);p.playSound(p.getLocation(),Sound.MUSIC_DISC_OTHERSIDE,.65f,1f);p.sendMessage("§d♪ Nhạc nền: §aBẬT");}}
    private void startMusicLoop(){musicTask=Bukkit.getScheduler().runTaskTimer(plugin,()->{if(!plugin.getConfig().getBoolean("background-music.enabled",true))return;for(UUID id:new ArrayList<>(music)){Player p=Bukkit.getPlayer(id);if(p==null||!p.isOnline()){music.remove(id);continue;}p.playSound(p.getLocation(),Sound.MUSIC_DISC_OTHERSIDE,(float)plugin.getConfig().getDouble("background-music.volume",.65),(float)plugin.getConfig().getDouble("background-music.pitch",1.0));}},20L,20L*Math.max(30,plugin.getConfig().getInt("background-music.loop-seconds",170)));}
    private void broadcast(String msg){Bukkit.broadcastMessage(msg);}
    public void shutdown(){if(musicTask!=null)musicTask.cancel();for(UUID id:new HashSet<>(hoThe)){Player p=Bukkit.getPlayer(id);if(p!=null)p.setInvulnerable(false);}hoThe.clear();pending.clear();duels.clear();music.clear();}
}
