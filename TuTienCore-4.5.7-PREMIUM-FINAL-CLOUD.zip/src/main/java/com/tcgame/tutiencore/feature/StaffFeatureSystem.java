package com.tcgame.tutiencore.feature;

import com.tcgame.tutiencore.TuTienCore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.block.DoubleChest;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Staff tools: silent vanish inspection, chat history/shadow mute,
 * rare-item crash insurance and ground-item trade logging.
 */
public final class StaffFeatureSystem implements Listener {
    private static final String INSPECT_TITLE = "§8§l✦ THÁM TỬ ẨN DANH ✦";
    private final TuTienCore plugin;
    private final Set<UUID> shadowMuted = ConcurrentHashMap.newKeySet();
    private final Map<UUID, InspectSession> inspectSessions = new ConcurrentHashMap<>();
    private final Map<UUID, DropRecord> recentDrops = new ConcurrentHashMap<>();
    private final Map<UUID, List<String>> recentChat = new ConcurrentHashMap<>();
    private final Set<UUID> insuranceQueued = ConcurrentHashMap.newKeySet();
    private final File chatFolder;
    private final File tradeFile;
    private final File insuranceFile;
    private final YamlConfiguration insurance;
    private final File crashMarker;
    private boolean previousRunCrashed;
    private BukkitTask cleanupTask;

    public StaffFeatureSystem(TuTienCore plugin) {
        this.plugin = plugin;
        chatFolder = new File(plugin.getDataFolder(), "chat-history");
        tradeFile = new File(plugin.getDataFolder(), "trade-history.txt");
        insuranceFile = new File(plugin.getDataFolder(), "insurance.yml");
        crashMarker = new File(plugin.getDataFolder(), "clean-shutdown.yml");
        chatFolder.mkdirs();
        insurance = YamlConfiguration.loadConfiguration(insuranceFile);
        previousRunCrashed = crashMarker.exists() && !YamlConfiguration.loadConfiguration(crashMarker).getBoolean("clean", true);
        markClean(false);
        cleanupTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            cleanupDrops();
            for (Player p : Bukkit.getOnlinePlayers()) saveRareSnapshot(p);
        }, 20L * 10L, 20L * 10L);
    }

    public boolean isStaff(Player p) {
        if (p == null) return false;
        return p.hasPermission("tutien.staff") || p.hasPermission("tutien.admin") ||
                p.hasPermission("admin") || p.hasPermission("mod") || p.hasPermission("police") ||
                p.hasPermission("helper") || p.hasPermission("internhelper");
    }

    public boolean handleCommand(Player staff, String label, String[] args) {
        if (!isStaff(staff)) { staff.sendMessage("§cBạn không có quyền Staff."); return true; }
        if (label.equalsIgnoreCase("lichsuchat")) {
            String target = args.length > 0 ? args[0] : staff.getName();
            int amount = args.length > 1 ? parseInt(args[1], 50) : 50;
            showChatHistory(staff, target, Math.min(100, Math.max(1, amount)));
            return true;
        }
        if (label.equalsIgnoreCase("smute")) {
            if (args.length < 1) { staff.sendMessage("§e/smute <player> [on|off]"); return true; }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) { staff.sendMessage("§cPlayer phải online để Shadow Mute."); return true; }
            boolean enable = args.length < 2 || !args[1].equalsIgnoreCase("off");
            if (enable) { shadowMuted.add(target.getUniqueId()); staff.sendMessage("§aShadow Mute §f" + target.getName() + " §ađã BẬT."); target.sendMessage("§7Bạn vẫn có thể gửi chat bình thường."); }
            else { shadowMuted.remove(target.getUniqueId()); staff.sendMessage("§eShadow Mute §f" + target.getName() + " §eđã TẮT."); target.sendMessage("§aBạn đã được mở chat."); }
            return true;
        }
        if (label.equalsIgnoreCase("giaodichlog")) {
            int amount = args.length > 0 ? parseInt(args[0], 20) : 20;
            showTradeLog(staff, Math.min(100, Math.max(1, amount)));
            return true;
        }
        if (label.equalsIgnoreCase("baohiem")) {
            return handleInsurance(staff, args);
        }
        return false;
    }

    private boolean handleInsurance(Player staff, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("status")) {
            staff.sendMessage("§b✦ Bảo hiểm tài sản: §f" + (previousRunCrashed ? "phát hiện lần chạy trước kết thúc bất thường" : "không phát hiện crash"));
            staff.sendMessage("§7/baohiem restore <player> §8- khôi phục thủ công snapshot đồ hiếm");
            return true;
        }
        if (args[0].equalsIgnoreCase("restore") && args.length >= 2) {
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { staff.sendMessage("§cPlayer phải online để restore."); return true; }
            int restored = restoreRareSnapshot(target, true);
            staff.sendMessage("§aBảo hiểm: đã khôi phục §f" + restored + " §astack cho §f" + target.getName());
            return true;
        }
        staff.sendMessage("§e/baohiem status §7| §e/baohiem restore <player>");
        return true;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        String msg = ChatColor.stripColor(e.getMessage()).replace('\n', ' ').trim();
        logChat(p, msg);
        if (shadowMuted.contains(p.getUniqueId())) {
            e.getRecipients().clear();
            e.getRecipients().add(p);
        }
    }

    private void logChat(Player p, String msg) {
        String line = "[" + new SimpleDateFormat("HH:mm:ss").format(new Date()) + "] " + p.getName() + ": " + msg;
        recentChat.computeIfAbsent(p.getUniqueId(), k -> Collections.synchronizedList(new ArrayList<>())).add(line);
        List<String> list = recentChat.get(p.getUniqueId());
        synchronized (list) { while (list.size() > 200) list.remove(0); }
        String day = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        File file = new File(chatFolder, day + ".txt");
        synchronized (this) {
            try (PrintWriter out = new PrintWriter(new FileWriter(file, true))) {
                out.println(line);
            } catch (IOException ex) { plugin.getLogger().warning("Không ghi được chat-history: " + ex.getMessage()); }
        }
    }

    private void showChatHistory(Player staff, String name, int amount) {
        Player online = Bukkit.getPlayerExact(name);
        UUID id = online == null ? null : online.getUniqueId();
        List<String> lines = id == null ? null : recentChat.get(id);
        staff.sendMessage("§b§l✦ LỊCH SỬ CHAT §f" + name);
        if (lines != null && !lines.isEmpty()) {
            synchronized (lines) {
                int from = Math.max(0, lines.size() - amount);
                for (int i = from; i < lines.size(); i++) staff.sendMessage("§7" + lines.get(i));
            }
            return;
        }
        List<String> matches = new ArrayList<>();
        if (chatFolder.isDirectory()) {
            File[] files = chatFolder.listFiles((dir, file) -> file.endsWith(".txt"));
            if (files != null) {
                Arrays.sort(files, Comparator.comparing(File::getName).reversed());
                for (File file : files) {
                    try {
                        List<String> fileLines = java.nio.file.Files.readAllLines(file.toPath());
                        for (String line : fileLines) if (line.contains("] " + name + ": ")) matches.add(line);
                        if (matches.size() >= amount) break;
                    } catch (IOException ignored) {}
                }
            }
        }
        int from = Math.max(0, matches.size() - amount);
        if (matches.isEmpty()) staff.sendMessage("§7Không tìm thấy lịch sử chat của §f" + name + "§7.");
        else for (int i = from; i < matches.size(); i++) staff.sendMessage("§7" + matches.get(i));
    }

    private void showTradeLog(Player staff, int amount) {
        if (!tradeFile.exists()) { staff.sendMessage("§7Chưa có giao dịch item rơi được ghi nhận."); return; }
        try {
            List<String> lines = java.nio.file.Files.readAllLines(tradeFile.toPath());
            staff.sendMessage("§6§l✦ NHẬT KÝ GIAO DỊCH ITEM RƠI");
            int from = Math.max(0, lines.size() - amount);
            for (int i = from; i < lines.size(); i++) staff.sendMessage("§7" + lines.get(i));
        } catch (IOException e) { staff.sendMessage("§cKhông đọc được trade-history.txt."); }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInventoryOpen(InventoryOpenEvent e) {
        if (!(e.getPlayer() instanceof Player staff) || !isStaff(staff) || !isVanished(staff)) return;
        Inventory inv = e.getInventory();
        InventoryHolder holder = inv.getHolder();
        Block block = null;
        if (holder instanceof Container container) block = container.getBlock();
        else if (holder instanceof DoubleChest dc && dc.getLeftSide() instanceof Container left) block = left.getBlock();
        if (block == null) return;
        Material type = block.getType();
        if (!type.name().contains("CHEST") && !type.name().contains("SHULKER_BOX") && type != Material.BARREL) return;

        e.setCancelled(true);
        final Player inspectStaff = staff;
        final Inventory inspectInventory = inv;
        final Block inspectBlock = block;
        Bukkit.getScheduler().runTask(plugin, () -> openInspect(inspectStaff, inspectInventory, inspectBlock));
    }

    private void openInspect(Player staff, Inventory source, Block block) {
        if (!staff.isOnline()) return;
        Inventory virtual = Bukkit.createInventory(new InspectHolder(block), source.getSize(), INSPECT_TITLE);
        virtual.setContents(Arrays.copyOf(source.getContents(), source.getSize()));
        inspectSessions.put(staff.getUniqueId(), new InspectSession(source, block));
        staff.openInventory(virtual);
        staff.sendActionBar("§8✦ Thám tử ẩn danh §7| §f" + block.getType().name());
    }

    @EventHandler
    public void onInspectClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player staff)) return;
        if (!(e.getInventory().getHolder() instanceof InspectHolder)) return;
        InspectSession session = inspectSessions.remove(staff.getUniqueId());
        if (session == null) return;
        // Staff changes are intentionally synchronized back to the real container.
        Inventory source = session.source;
        ItemStack[] copy = Arrays.copyOf(e.getInventory().getContents(), source.getSize());
        source.setContents(copy);
        staff.sendActionBar("§8✦ Đã đồng bộ thay đổi vào container.");
    }

    private boolean isVanished(Player p) {
        if (p.hasMetadata("vanished")) return true;
        if (p.hasMetadata("essentials.vanish")) return true;
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (viewer.equals(p)) continue;
            if (!viewer.canSee(p)) return true;
        }
        return false;
    }

    private void queueInsuranceSnapshot(Player p) {
        if (!insuranceQueued.add(p.getUniqueId())) return;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            insuranceQueued.remove(p.getUniqueId());
            if (p.isOnline()) saveRareSnapshot(p);
        }, 20L);
    }

    private void saveRareSnapshot(Player p) {
        List<ItemStack> rare = new ArrayList<>();
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < p.getInventory().getSize(); i++) {
            ItemStack item = p.getInventory().getItem(i);
            if (isRare(item)) { slots.add(i); rare.add(item.clone()); }
        }
        String base = "players." + p.getUniqueId();
        insurance.set(base + ".name", p.getName());
        insurance.set(base + ".time", System.currentTimeMillis());
        insurance.set(base + ".slots", slots);
        for (int i = 0; i < rare.size(); i++) insurance.set(base + ".items." + i, rare.get(i));
        try { insurance.save(insuranceFile); } catch (IOException ex) { plugin.getLogger().warning("Không lưu được insurance.yml: " + ex.getMessage()); }
    }

    private boolean isRare(ItemStack item) {
        if (item == null || item.getType().isAir()) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta != null && (meta.hasEnchants() || meta.hasDisplayName() || meta.hasLore() || meta.hasCustomModelData())) return true;
        String n = item.getType().name();
        return n.contains("NETHERITE") || n.contains("DIAMOND") || n.equals("ELYTRA") || n.equals("MACE") || n.equals("TRIDENT") || n.equals("BEACON") || n.equals("NETHER_STAR");
    }

    private int restoreRareSnapshot(Player p, boolean announce) {
        String base = "players." + p.getUniqueId();
        long saved = insurance.getLong(base + ".time", 0L);
        if (saved <= 0L || System.currentTimeMillis() - saved > 5 * 60_000L) return 0;
        int restored = 0;
        if (!insurance.isConfigurationSection(base + ".items")) return 0;
        for (String key : insurance.getConfigurationSection(base + ".items").getKeys(false)) {
            ItemStack savedItem = insurance.getItemStack(base + ".items." + key);
            if (savedItem == null || savedItem.getType().isAir()) continue;
            int targetAmount = savedItem.getAmount();
            int currentAmount = 0;
            for (ItemStack current : p.getInventory().getContents()) if (current != null && current.isSimilar(savedItem)) currentAmount += current.getAmount();
            if (currentAmount >= targetAmount) continue;
            ItemStack missing = savedItem.clone();
            missing.setAmount(targetAmount - currentAmount);
            Map<Integer, ItemStack> left = p.getInventory().addItem(missing);
            int added = missing.getAmount();
            for (ItemStack remain : left.values()) added -= remain.getAmount();
            if (added > 0) restored++;
        }
        if (announce && restored > 0) p.sendMessage("§b✦ Bảo hiểm tài sản đã khôi phục §f" + restored + " §bstack đồ hiếm từ snapshot gần nhất.");
        return restored;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!previousRunCrashed) return;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (e.getPlayer().isOnline()) {
                int restored = restoreRareSnapshot(e.getPlayer(), true);
                if (restored > 0) plugin.getLogger().info("Crash insurance restored " + restored + " rare stacks for " + e.getPlayer().getName());
            }
        }, 20L);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent e) {
        if (e.getWhoClicked() instanceof Player p && !e.getView().getTitle().equals(INSPECT_TITLE)) {
            queueInsuranceSnapshot(p);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        Item entity = e.getItemDrop();
        ItemStack stack = entity.getItemStack().clone();
        recentDrops.put(entity.getUniqueId(), new DropRecord(e.getPlayer().getUniqueId(), e.getPlayer().getName(), stack, entity.getLocation().clone(), System.currentTimeMillis()));
        saveRareSnapshot(e.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (!(e.getEntity() instanceof Player receiver)) return;
        DropRecord record = recentDrops.get(e.getItem().getUniqueId());
        if (record == null || record.owner.equals(receiver.getUniqueId())) return;
        if (System.currentTimeMillis() - record.time > 5000L) { recentDrops.remove(e.getItem().getUniqueId()); return; }
        if (!record.location.getWorld().equals(receiver.getWorld()) || record.location.distanceSquared(receiver.getLocation()) > 16D) return;
        logTrade(record, receiver, e.getItem().getItemStack());
        recentDrops.remove(e.getItem().getUniqueId());
        saveRareSnapshot(receiver);
    }

    private void logTrade(DropRecord record, Player receiver, ItemStack item) {
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        String itemName = item.getItemMeta() != null && item.getItemMeta().hasDisplayName() ? ChatColor.stripColor(item.getItemMeta().getDisplayName()) : item.getType().name();
        String line = "[GIAO DỊCH] " + record.ownerName + " -> " + receiver.getName() + " | [" + itemName + " x" + item.getAmount() + "] | " + time + " | " + formatLocation(record.location);
        synchronized (this) {
            try (PrintWriter out = new PrintWriter(new FileWriter(tradeFile, true))) { out.println(line); }
            catch (IOException ex) { plugin.getLogger().warning("Không ghi được trade-history: " + ex.getMessage()); }
        }
    }

    private String formatLocation(org.bukkit.Location l) {
        return l.getWorld().getName() + " " + l.getBlockX() + " " + l.getBlockY() + " " + l.getBlockZ();
    }

    private void cleanupDrops() {
        long now = System.currentTimeMillis();
        recentDrops.entrySet().removeIf(e -> { Entity entity = Bukkit.getEntity(e.getKey()); return now - e.getValue().time > 7000L || entity == null || !entity.isValid(); });
    }

    private int parseInt(String s, int fallback) { try { return Integer.parseInt(s); } catch (Exception e) { return fallback; } }

    private void markClean(boolean clean) {
        YamlConfiguration y = new YamlConfiguration();
        y.set("clean", clean);
        y.set("timestamp", System.currentTimeMillis());
        try { y.save(crashMarker); } catch (IOException e) { plugin.getLogger().warning("Không ghi được clean-shutdown.yml: " + e.getMessage()); }
    }

    public void shutdown() {
        if (cleanupTask != null) cleanupTask.cancel();
        for (Player p : Bukkit.getOnlinePlayers()) saveRareSnapshot(p);
        markClean(true);
        inspectSessions.clear();
        recentDrops.clear();
        insuranceQueued.clear();
    }

    private record DropRecord(UUID owner, String ownerName, ItemStack item, org.bukkit.Location location, long time) {}
    private record InspectSession(Inventory source, Block block) {}
    private static final class InspectHolder implements InventoryHolder {
        private final Block block;
        private InspectHolder(Block block) { this.block = block; }
        @Override public Inventory getInventory() { return null; }
        public Block block() { return block; }
    }
}
