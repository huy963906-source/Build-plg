package com.tcgame.tutiencore.alchemy;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class AlchemySystem implements Listener {
    public static final String TITLE = "§5§l✦ Luyện Đan ✦";
    private final TuTienCore plugin;
    private final NamespacedKey herbKey;
    private final NamespacedKey pillKey;

    public AlchemySystem(TuTienCore plugin) {
        this.plugin = plugin;
        herbKey = new NamespacedKey(plugin, "linh_thao");
        pillKey = new NamespacedKey(plugin, "tu_luyen_dan");
    }

    public ItemStack createHerbItem(int amount) {
        ItemStack item = new ItemStack(Material.FERN, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§a§lLinh Thảo");
        meta.setLore(List.of("§7Nguyên liệu luyện đan", "§8Hấp thụ linh khí của đất trời."));
        meta.getPersistentDataContainer().set(herbKey, PersistentDataType.BYTE, (byte)1);
        item.setItemMeta(meta);
        return item;
    }

    public ItemStack createPillItem(int amount) {
        ItemStack item = new ItemStack(Material.HONEY_BOTTLE, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§d§lTụ Linh Đan");
        meta.setLore(List.of("§7Dùng để tăng tốc tu luyện", "§e+" + plugin.getConfig().getDouble("alchemy.cultivation-pill-multiplier",1.5D) + "x tốc độ", "§8Chuột phải để uống"));
        meta.getPersistentDataContainer().set(pillKey, PersistentDataType.BYTE, (byte)1);
        item.setItemMeta(meta);
        return item;
    }

    public ItemStack createLinhThachItem(int amount) {
        ItemStack item = new ItemStack(Material.GOLD_NUGGET, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§e§lLinh Thạch");
        meta.setLore(List.of("§7Linh thạch vật phẩm", "§8Có thể rơi từ quái và nhận từ khu AFK."));
        meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "linh_thach_item"), PersistentDataType.BYTE, (byte)1);
        item.setItemMeta(meta);
        return item;
    }

    public void addHerb(Player p, int amount) {
        if (amount <= 0) return;
        // Linh Thảo từ tu luyện xuất hiện thành vật phẩm vật lý trong bán kính tối đa 3 block.
        // Khi nhặt, EntityPickupItemEvent bên dưới sẽ chuyển vật phẩm thành Linh Thảo trong dữ liệu người chơi.
        double angle = ThreadLocalRandom.current().nextDouble(0, Math.PI * 2);
        double radius = ThreadLocalRandom.current().nextDouble(0.8, 3.0);
        Location drop = p.getLocation().clone().add(Math.cos(angle) * radius, 0.35, Math.sin(angle) * radius);
        p.getWorld().dropItemNaturally(drop, createHerbItem(amount));
    }

    public void addLinhThach(Player p, int amount, boolean physical) {
        if (amount <= 0) return;
        if (physical) giveItems(p, createLinhThachItem(amount));
    }

    private void giveItems(Player p, ItemStack item) {
        for (ItemStack left : p.getInventory().addItem(item).values()) p.getWorld().dropItemNaturally(p.getLocation(), left);
    }

    public boolean isHerb(ItemStack item) { return has(item, herbKey); }
    public boolean isPill(ItemStack item) { return has(item, pillKey); }
    private boolean has(ItemStack item, NamespacedKey key) { return item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.BYTE); }


    @EventHandler
    public void onPillDrink(PlayerInteractEvent e) {
        if (e.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!isPill(e.getItem())) return;
        e.setCancelled(true);
        useCultivationPill(e.getPlayer());
    }

    @EventHandler
    public void onHerbPickup(EntityPickupItemEvent e) {
        if (!(e.getEntity() instanceof Player p) || !isHerb(e.getItem().getItemStack())) return;
        e.setCancelled(true);
        int amount = e.getItem().getItemStack().getAmount();
        e.getItem().remove();
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        d.addLinhThao(amount);
        plugin.getCultivationService().save(p.getUniqueId());
        p.sendActionBar("§a✿ +" + amount + " Linh Thảo");
    }

    public void open(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        inv.setItem(11, button(Material.FERN, "§a§lLinh Thảo", "§7Bạn có: §f" + d.linhThao(), "§73 Linh Thảo → 1 Tụ Linh Đan"));
        inv.setItem(13, button(Material.HONEY_BOTTLE, "§d§lLuyện Tụ Linh Đan", "§7Cần: §a3 Linh Thảo", "§eNhấn để luyện 1 viên"));
        inv.setItem(15, button(Material.GOLD_NUGGET, "§e§lLinh Thạch", "§7Trong túi: §f" + countLinhThach(p)));
        inv.setItem(22, button(Material.BARRIER, "§cĐóng", "§7Đóng menu"));
        p.openInventory(inv);
    }

    private ItemStack button(Material m, String name, String... lore) {
        ItemStack i = new ItemStack(m); ItemMeta meta=i.getItemMeta(); meta.setDisplayName(name); meta.setLore(List.of(lore)); i.setItemMeta(meta); return i;
    }

    @EventHandler public void click(InventoryClickEvent e) {
        if (!TITLE.equals(e.getView().getTitle()) || !(e.getWhoClicked() instanceof Player p)) return;
        e.setCancelled(true);
        if (e.getRawSlot() == 13) craftPill(p);
        else if (e.getRawSlot() == 22) p.closeInventory();
        else if (e.getRawSlot() == 11 || e.getRawSlot() == 15) open(p);
    }

    public int countLinhThach(Player p) {
        int total = 0;
        for (ItemStack i : p.getInventory().getContents()) if (isLinhThach(i)) total += i.getAmount();
        return total;
    }

    public boolean isLinhThach(ItemStack item) {
        return item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(new NamespacedKey(plugin, "linh_thach_item"), PersistentDataType.BYTE);
    }

    private void craftPill(Player p) {
        PlayerData d = plugin.getCultivationService().getPlayerData(p.getUniqueId());
        int cost = Math.max(1, plugin.getConfig().getInt("alchemy.recipes.tu-linh-dan.herb-cost", 3));
        if (!d.takeLinhThao(cost)) { p.sendMessage("§cBạn cần §a" + cost + " Linh Thảo§c."); return; }
        giveItems(p, createPillItem(1));
        plugin.getCultivationService().save(p.getUniqueId());
        p.sendMessage("§d✦ Luyện đan thành công: §f1 Tụ Linh Đan");
        open(p);
    }

    public boolean useCultivationPill(Player player) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (!isPill(hand)) { player.sendMessage("§cBạn cần cầm Tụ Linh Đan để sử dụng."); return false; }
        hand.setAmount(hand.getAmount()-1);
        PlayerData d = plugin.getCultivationService().getPlayerData(player.getUniqueId());
        long duration = plugin.getConfig().getLong("alchemy.cultivation-pill-duration-ms", 300_000L);
        d.alchemyMultiplier(plugin.getConfig().getDouble("alchemy.cultivation-pill-multiplier", 1.50D));
        d.alchemyBuffUntil(System.currentTimeMillis() + duration);
        player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, (int)Math.min(Integer.MAX_VALUE,duration/50L),0,false,false,false));
        player.sendMessage("§d✦ Bạn dùng Tụ Linh Đan. Tốc độ tu luyện được tăng tạm thời.");
        return true;
    }
}
