package com.tcgame.tutiencore;

import com.tcgame.tutiencore.api.CultivationAPI;
import com.tcgame.tutiencore.api.CultivationService;
import com.tcgame.tutiencore.alchemy.AlchemySystem;
import com.tcgame.tutiencore.artifact.ArtifactSystem;
import com.tcgame.tutiencore.breakthrough.BreakthroughServiceImpl;
import com.tcgame.tutiencore.command.TuTienAdminCommand;
import com.tcgame.tutiencore.command.TuTienUserCommand;
import com.tcgame.tutiencore.license.LicenseManager;
import com.tcgame.tutiencore.cultivation.CultivationServiceImpl;
import com.tcgame.tutiencore.cultivation.GsitBridge;
import com.tcgame.tutiencore.cultivation.LinhMachService;
import com.tcgame.tutiencore.cultivation.TrainingManager;
import com.tcgame.tutiencore.dungeon.DungeonSystem;
import com.tcgame.tutiencore.economy.EconomyService;
import com.tcgame.tutiencore.economy.LinhThachBankService;
import com.tcgame.tutiencore.listener.CoreListener;
import com.tcgame.tutiencore.listener.CraftingFixListener;
import com.tcgame.tutiencore.listener.ResourceListener;
import com.tcgame.tutiencore.menu.AdminMenu;
import com.tcgame.tutiencore.menu.SpiritRootMenu;
import com.tcgame.tutiencore.menu.CultivationMenu;
import com.tcgame.tutiencore.menu.BreakthroughMenu;
import com.tcgame.tutiencore.menu.SectMenu;
import com.tcgame.tutiencore.menu.ClassSelectMenu;
import com.tcgame.tutiencore.menu.CuaHangMenu;
import com.tcgame.tutiencore.menu.KarmaMenu;
import com.tcgame.tutiencore.pet.PetSystem;
import com.tcgame.tutiencore.placeholder.TuTienPlaceholderExpansion;
import com.tcgame.tutiencore.quest.QuestSystem;
import com.tcgame.tutiencore.quest.InitiationSystem;
import com.tcgame.tutiencore.quest.AutoQuestSystem;
import com.tcgame.tutiencore.sect.SectSystem;
import com.tcgame.tutiencore.technique.TechniqueSystem;
import com.tcgame.tutiencore.skill.SkillSwordSystem;
import com.tcgame.tutiencore.skill.ClassSkillSystem;
import com.tcgame.tutiencore.rank.RankSystem;
import com.tcgame.tutiencore.ngukiem.NguKiemService;
import com.tcgame.tutiencore.tribulation.TribulationSystem;
import com.tcgame.tutiencore.feature.ServerFeatureSystem;
import com.tcgame.tutiencore.storage.StorageSystem;
import com.tcgame.tutiencore.feature.StaffFeatureSystem;
import com.tcgame.tutiencore.feature.WorldRpgV3System;
import com.tcgame.tutiencore.feature.AntiDupeSerialSystem;
import com.tcgame.tutiencore.feature.StatsHudSystem;
import com.tcgame.tutiencore.anticheat.AntiCheatSystem;
import com.tcgame.tutiencore.adapter.bukkit.movement.BukkitMovementAPI;
import com.tcgame.tutiencore.adapter.bukkit.movement.BukkitMovementTrustService;
import com.tcgame.tutiencore.adapter.bukkit.movement.NgukiemCommand;
import com.tcgame.tutiencore.adapter.bukkit.movement.NgukiemListener;
import com.tcgame.tutiencore.adapter.bukkit.movement.PaperInputProvider;
import com.tcgame.tutiencore.adapter.bukkit.movement.SimpleFlightResourceService;
import com.tcgame.tutiencore.feature.AuraSystem;
import com.tcgame.tutiencore.feature.HyperVN430System;
import com.tcgame.tutiencore.menu.SkillKeybindMenu;
import com.tcgame.tutiencore.menu.QuestMenu;
import com.tcgame.tutiencore.adapter.bukkit.movement.PhiKhongService;
import com.tcgame.tutiencore.domain.movement.controller.DefaultMovementController;
import com.tcgame.tutiencore.domain.movement.model.DismountReason;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

public final class TuTienCore extends JavaPlugin {
    private CultivationService cultivationService;
    private EconomyService economyService;
    private LinhThachBankService linhThachBankService;
    private TechniqueSystem techniqueSystem;
    private SkillSwordSystem skillSwordSystem;
    private ClassSkillSystem classSkillSystem;
    private AlchemySystem alchemySystem;
    private ArtifactSystem artifactSystem;
    private PetSystem petSystem;
    private SectSystem sectSystem;
    private QuestSystem questSystem;
    private AutoQuestSystem autoQuestSystem;
    private QuestMenu questMenu;
    private InitiationSystem initiationSystem;
    private DungeonSystem dungeonSystem;
    private LinhMachService linhMachService;
    private GsitBridge gsitBridge;
    private TrainingManager trainingManager;
    private com.tcgame.tutiencore.cultivation.LinhZoneManager linhZoneManager;
    private TribulationSystem tribulationSystem;
    private BreakthroughServiceImpl breakthroughService;
    private CultivationMenu cultivationMenu;
    private AdminMenu adminMenu;
    private SpiritRootMenu spiritRootMenu;
    private BreakthroughMenu breakthroughMenu;
    private SectMenu sectMenu;
    private ClassSelectMenu classSelectMenu;
    private CuaHangMenu cuaHangMenu;
    private KarmaMenu karmaMenu;
    private RankSystem rankSystem;
    private NguKiemService nguKiemService;
    private ResourceListener resourceListener;
    private ServerFeatureSystem serverFeatureSystem;
    private AntiCheatSystem antiCheatSystem;
    private com.tcgame.tutiencore.anticheat.AntiCheatMenu antiCheatMenu;
    private StorageSystem storageSystem;
    private StaffFeatureSystem staffFeatureSystem;
    private WorldRpgV3System worldRpgV3System;
    private AntiDupeSerialSystem antiDupeSerialSystem;
    private StatsHudSystem statsHudSystem;
    private BukkitMovementAPI movementAPI;
    private AuraSystem auraSystem;
    private SkillKeybindMenu skillKeybindMenu;
    private PhiKhongService phiKhongService;
    private PaperInputProvider movementInputs;
    private HyperVN430System hyperVN430System;

    @Override public void onEnable() {
        saveDefaultConfig();
        LicenseManager licenseManager = new LicenseManager(this);
        licenseManager.ensureDefaultKeyPool();
        licenseManager.registerCommand();
        if (!licenseManager.isActivatedForThisServer()) {
            getLogger().warning("TuTienCore Premium chưa kích hoạt. Các hệ thống gameplay chưa được khởi tạo.");
            getLogger().warning("Dùng /ttlicense activate <key> từ console, sau đó khởi động lại server.");
            return;
        }
        com.tcgame.tutiencore.cultivation.Realm.loadCustomDisplayNames(getConfig().getConfigurationSection("custom-realms.names"));
        cultivationService = new CultivationServiceImpl(this);
        economyService = new EconomyService();
        linhThachBankService = new LinhThachBankService(this);
        if (getServer().getPluginManager().isPluginEnabled("Vault")) economyService.hook();
        techniqueSystem = new TechniqueSystem(this);
        skillSwordSystem = new SkillSwordSystem(this);
        classSkillSystem = new ClassSkillSystem(this);
        serverFeatureSystem = new ServerFeatureSystem(this);
        antiCheatSystem = new AntiCheatSystem(this);
        antiCheatMenu = new com.tcgame.tutiencore.anticheat.AntiCheatMenu(this);
        storageSystem = new StorageSystem(this);
        staffFeatureSystem = new StaffFeatureSystem(this);
        worldRpgV3System = new WorldRpgV3System(this);
        antiDupeSerialSystem = new AntiDupeSerialSystem(this);
        statsHudSystem = new StatsHudSystem(this);
        hyperVN430System = new HyperVN430System(this);

        // Phase A / Mũi 3: Ngự Kiếm Bukkit Adapter (single-plugin integration).
        // Resource is intentionally MOCK/FREE for Alpha playtest and never touches Tu Vi.
        movementInputs = new PaperInputProvider();
        var movementController = new DefaultMovementController(
                getConfig().getDouble("flight.horizontal-speed", 0.55D),
                getConfig().getDouble("flight.vertical-speed", 0.45D));
        var movementResources = new SimpleFlightResourceService();
        var movementTrust = new BukkitMovementTrustService();
        movementAPI = new BukkitMovementAPI(this, movementController, movementInputs, movementResources, movementTrust,
                getConfig().getDouble("flight.chan-khi-drain-per-tick", 0.0D));
        auraSystem = new AuraSystem(this);
        skillKeybindMenu = new SkillKeybindMenu(this);
        phiKhongService = new PhiKhongService(this);
        alchemySystem = new AlchemySystem(this);
        artifactSystem = new ArtifactSystem();
        petSystem = new PetSystem(this);
        sectSystem = new SectSystem(this);
        questSystem = new QuestSystem(this);
        autoQuestSystem = new AutoQuestSystem(this);
        questMenu = new QuestMenu(this);
        initiationSystem = new InitiationSystem(this);
        dungeonSystem = new DungeonSystem(this);
        linhMachService = new LinhMachService(this);
        gsitBridge = new GsitBridge();
        if (getServer().getPluginManager().isPluginEnabled("GSit") && gsitBridge.hook()) getLogger().info("GSit integration: READY");
        else getLogger().warning("GSit chưa có hoặc API không khả dụng; /tuluyen sẽ không thể ngồi bằng GSit.");
        tribulationSystem = new TribulationSystem(this);
        breakthroughService = new BreakthroughServiceImpl(this,cultivationService,tribulationSystem);
        tribulationSystem.setCompletionHandler((player,realm)->breakthroughService.resolveTribulation(player,realm));
        rankSystem = new RankSystem(this);
        nguKiemService = new NguKiemService(this);
        rankSystem.setupLuckPermsGroups();
        rankSystem.setupStaffGroups();
        linhZoneManager = new com.tcgame.tutiencore.cultivation.LinhZoneManager(this);
        trainingManager = new TrainingManager(this,gsitBridge,linhMachService,techniqueSystem,artifactSystem,petSystem,questSystem);
        cultivationMenu = new CultivationMenu(this); adminMenu = new AdminMenu(this); spiritRootMenu = new SpiritRootMenu(this); breakthroughMenu = new BreakthroughMenu(this); sectMenu = new SectMenu(this); classSelectMenu = new ClassSelectMenu(this); cuaHangMenu = new CuaHangMenu(this); karmaMenu = new KarmaMenu(this);

        getServer().getServicesManager().register(CultivationAPI.class,new CultivationAPI(cultivationService),this,ServicePriority.Normal);
        if (getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) new TuTienPlaceholderExpansion(this,economyService).register();
        getServer().getPluginManager().registerEvents(new CoreListener(this),this);
        getServer().getPluginManager().registerEvents(skillSwordSystem,this);
        getServer().getPluginManager().registerEvents(classSkillSystem,this);
        getServer().getPluginManager().registerEvents(classSelectMenu,this);
        getServer().getPluginManager().registerEvents(serverFeatureSystem,this);
        getServer().getPluginManager().registerEvents(antiCheatSystem,this);
        getServer().getPluginManager().registerEvents(antiCheatMenu,this);
        getServer().getPluginManager().registerEvents(storageSystem,this);
        getServer().getPluginManager().registerEvents(staffFeatureSystem,this);
        getServer().getPluginManager().registerEvents(worldRpgV3System,this);
        getServer().getPluginManager().registerEvents(antiDupeSerialSystem,this);
        getServer().getPluginManager().registerEvents(statsHudSystem,this);
        getServer().getPluginManager().registerEvents(hyperVN430System,this);
        getServer().getPluginManager().registerEvents(skillKeybindMenu,this);
        getServer().getPluginManager().registerEvents(cultivationMenu,this);
        getServer().getPluginManager().registerEvents(autoQuestSystem,this);
        getServer().getPluginManager().registerEvents(questMenu,this);
        statsHudSystem.start();
        getServer().getPluginManager().registerEvents(new NgukiemListener(movementInputs, movementAPI), this);
        getServer().getScheduler().runTaskTimer(this, movementAPI::tick, 1L, 1L);
        getServer().getScheduler().runTaskTimer(this, () -> phiKhongService.tick(movementInputs), 1L, 1L);
        getServer().getScheduler().runTaskTimer(this, movementAPI::hardResetTaggedEntities, 1200L, 1200L);
        getServer().getPluginManager().registerEvents(petSystem,this);
        getServer().getPluginManager().registerEvents(cuaHangMenu,this);
        getServer().getPluginManager().registerEvents(karmaMenu,this);
        getServer().getPluginManager().registerEvents(nguKiemService,this);
        getServer().getPluginManager().registerEvents(new CraftingFixListener(),this);
        getServer().getPluginManager().registerEvents(alchemySystem,this);
        resourceListener = new ResourceListener(this);
        getServer().getPluginManager().registerEvents(resourceListener,this);

        TuTienUserCommand uc=new TuTienUserCommand(this);
        String[] userCommands={"tutien","cuahang","tuluyen","dotpha","dokiep","rank","thongtin","tongmon","bicanh","nhiemvu","autoquest","luyendan","phapbao","linhthu","congphap","tamphap","linhmach","donthuat","linhcan","catlinhthach","phai","hothe","loidai","nhacnen","autocatlt","truvat","tuitruvat","luanhoi","congduc","huyettelinhthu","kinang","phaptuong","bakhi","tuvi","phikhong"};
        for(String commandName:userCommands){
            var cmd=getCommand(commandName);
            if(cmd!=null){cmd.setExecutor(uc);cmd.setTabCompleter(uc);}
        }
        var ngukiemCommand = getCommand("ngukiem");
        if (ngukiemCommand != null) ngukiemCommand.setExecutor(new NgukiemCommand(movementAPI));

        TuTienAdminCommand adminCommand = new TuTienAdminCommand(this);
        for (String adminCommandName : new String[]{"tutiencore", "tutienad", "kiem", "setafk", "setafklinhthach", "lichsuchat", "smute", "giaodichlog", "baohiem", "anticheat"}) {
            var cmd = getCommand(adminCommandName);
            if (cmd != null) { cmd.setExecutor(adminCommand); cmd.setTabCompleter(adminCommand); }
        }
        getLogger().info("=============================================");
        getLogger().info("TuTienCore CultivationCore 4.2.0 | Minecraft 1.21.11");
        getLogger().info("zyas x XuanHai26 | TC GAME");
        getLogger().info("Cultivation + Breakthrough + Tribulation + Sect + Pet + Rank + GUI + API");
        getLogger().info("=============================================");
    }

    @Override public void onDisable(){if(hyperVN430System!=null)hyperVN430System.shutdown();if(phiKhongService!=null)phiKhongService.cleanup();if(movementAPI!=null)movementAPI.cleanupAll(DismountReason.SYSTEM);if(auraSystem!=null)auraSystem.shutdown();if(staffFeatureSystem!=null)staffFeatureSystem.shutdown();if(antiDupeSerialSystem!=null)antiDupeSerialSystem.shutdown();if(statsHudSystem!=null)statsHudSystem.shutdown();if(storageSystem!=null)storageSystem.saveAllOpen();if(antiCheatSystem!=null)antiCheatSystem.shutdown();if(serverFeatureSystem!=null)serverFeatureSystem.shutdown();if(resourceListener!=null)resourceListener.shutdown();if(nguKiemService!=null)nguKiemService.shutdown();if(tribulationSystem!=null)tribulationSystem.shutdown();if(trainingManager!=null)trainingManager.shutdown();if(sectSystem!=null)sectSystem.save();if(cultivationService!=null)cultivationService.saveAll();if(linhThachBankService!=null)linhThachBankService.save();}
    public CultivationService getCultivationService(){return cultivationService;} public EconomyService getEconomyService(){return economyService;} public LinhThachBankService getLinhThachBankService(){return linhThachBankService;}
    public InitiationSystem getInitiationSystem(){return initiationSystem;}
    public TechniqueSystem getTechniqueSystem(){return techniqueSystem;} public SkillSwordSystem getSkillSwordSystem(){return skillSwordSystem;} public ClassSkillSystem getClassSkillSystem(){return classSkillSystem;} public AlchemySystem getAlchemySystem(){return alchemySystem;} public ArtifactSystem getArtifactSystem(){return artifactSystem;} public PetSystem getPetSystem(){return petSystem;}
    public SectSystem getSectSystem(){return sectSystem;} public QuestSystem getQuestSystem(){return questSystem;} public DungeonSystem getDungeonSystem(){return dungeonSystem;} public LinhMachService getLinhMachService(){return linhMachService;}
    public TrainingManager getTrainingManager(){return trainingManager;} public com.tcgame.tutiencore.cultivation.LinhZoneManager getLinhZoneManager(){return linhZoneManager;} public TribulationSystem getTribulationSystem(){return tribulationSystem;} public BreakthroughServiceImpl getBreakthroughService(){return breakthroughService;}
    public CultivationMenu getCultivationMenu(){return cultivationMenu;} public AdminMenu getAdminMenu(){return adminMenu;}
    public RankSystem getRankSystem(){return rankSystem;}
    public NguKiemService getNguKiemService(){return nguKiemService;}
    public BukkitMovementAPI getMovementAPI(){return movementAPI;} public AuraSystem getAuraSystem(){return auraSystem;} public SkillKeybindMenu getSkillKeybindMenu(){return skillKeybindMenu;} public PhiKhongService getPhiKhongService(){return phiKhongService;}
    public ServerFeatureSystem getServerFeatureSystem(){return serverFeatureSystem;}
    public StaffFeatureSystem getStaffFeatureSystem(){return staffFeatureSystem;}
    public CuaHangMenu getCuaHangMenu(){return cuaHangMenu;}
    public AntiCheatSystem getAntiCheatSystem(){return antiCheatSystem;} public com.tcgame.tutiencore.anticheat.AntiCheatMenu getAntiCheatMenu(){return antiCheatMenu;} public StorageSystem getStorageSystem(){return storageSystem;}
    public WorldRpgV3System getWorldRpgV3System(){return worldRpgV3System;} public AntiDupeSerialSystem getAntiDupeSerialSystem(){return antiDupeSerialSystem;}
    public StatsHudSystem getStatsHudSystem(){return statsHudSystem;}
    public HyperVN430System getHyperVN430System(){return hyperVN430System;}
    public SpiritRootMenu getSpiritRootMenu(){return spiritRootMenu;} public BreakthroughMenu getBreakthroughMenu(){return breakthroughMenu;} public SectMenu getSectMenu(){return sectMenu;} public ClassSelectMenu getClassSelectMenu(){return classSelectMenu;} public KarmaMenu getKarmaMenu(){return karmaMenu;}

    public AutoQuestSystem getAutoQuestSystem() { return autoQuestSystem; }
    public QuestMenu getQuestMenu() { return questMenu; }
}

