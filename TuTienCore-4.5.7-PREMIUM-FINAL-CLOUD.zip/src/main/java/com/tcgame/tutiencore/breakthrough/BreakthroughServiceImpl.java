package com.tcgame.tutiencore.breakthrough;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.CultivationService;
import com.tcgame.tutiencore.api.PlayerData;
import com.tcgame.tutiencore.cultivation.Realm;
import com.tcgame.tutiencore.tribulation.TribulationSystem;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Every /dotpha starts a nine-wave thunder tribulation before the breakthrough is resolved. */
public final class BreakthroughServiceImpl {
    public enum Result {
        SUCCESS, TRIBULATION_STARTED, FAIL, NOT_ENOUGH_LINHKHI, NO_NEXT_REALM,
        CONDITIONS_FAILED, ALREADY_IN_TRIBULATION
    }

    private final TuTienCore plugin;
    private final CultivationService cultivation;
    private final TribulationSystem tribulation;

    public BreakthroughServiceImpl(TuTienCore plugin, CultivationService cultivation, TribulationSystem tribulation) {
        this.plugin = plugin;
        this.cultivation = cultivation;
        this.tribulation = tribulation;
    }

    /**
     * /dotpha entry point. The player always enters the Cửu Lôi tribulation first;
     * the actual chance check is resolved only after the tribulation is survived.
     */
    public Result attempt(Player player) {
        PlayerData data = cultivation.getPlayerData(player.getUniqueId());

        if (tribulation.isInTribulation(player.getUniqueId())) {
            player.sendMessage("§cBạn đang ở trong Thiên Kiếp.");
            return Result.ALREADY_IN_TRIBULATION;
        }

        if (data.realm() == Realm.PHAM_NHAN) {
            player.sendMessage("§cBạn phải hoàn thành nhiệm vụ mở khóa Luyện Khí Tầng 1 trước.");
            return Result.CONDITIONS_FAILED;
        }

        if (data.realm() == Realm.LUYEN_KHI && data.realmStage() >= 10
                && data.linhKhi() >= data.nextLinhKhiStageThreshold()) {
            player.sendMessage("§cLuyện Khí Tầng 10 đã đầy Linh Khí: §f/dotpha §cđã bị khóa. Hãy dùng §e/dokiep §cđể Độ Kiếp Trúc Cơ.");
            return Result.CONDITIONS_FAILED;
        }

        if (data.linhKhi() < data.nextLinhKhiStageThreshold()) {
            player.sendMessage("§cChưa đủ Linh Khí. Cần §b" + data.nextLinhKhiStageThreshold() + "§c Linh Khí.");
            return Result.NOT_ENOUGH_LINHKHI;
        }

        if (data.canCot() < plugin.getConfig().getDouble("breakthrough.min-can-cot", 1D)
                || data.ngoTinh() < plugin.getConfig().getDouble("breakthrough.min-ngo-tinh", 1D)) {
            player.sendMessage("§cCăn Cốt hoặc Ngộ Tính chưa đạt điều kiện đột phá.");
            return Result.CONDITIONS_FAILED;
        }

        Realm target = data.realmStage() >= data.realm().maxStage() ? data.realm().next() : data.realm();
        if (target == null) return Result.NO_NEXT_REALM;

        if (target == Realm.TRUC_CO) {
            if (tribulation.prepareTrucCo(player, target)) {
                player.playSound(player, Sound.BLOCK_BEACON_ACTIVATE, 1f, 0.6f);
                player.sendMessage("§c⚡ §dBạn đã bước vào trạng thái chuẩn bị Độ Kiếp Trúc Cơ. Dùng §f/dokiep§d để bắt đầu.");
                return Result.TRIBULATION_STARTED;
            }
        } else if (tribulation.start(player, target)) {
            player.playSound(player, Sound.BLOCK_BEACON_ACTIVATE, 1f, 0.6f);
            player.sendMessage("§6⚡ §dĐột phá đã kích hoạt Hồng Lôi tôi luyện đạo cơ.");
            return Result.TRIBULATION_STARTED;
        }
        return Result.ALREADY_IN_TRIBULATION;
    }

    /** Đột phá nhanh: bỏ qua toàn bộ Cửu Lôi/particle để giảm tải cho máy yếu. */
    public Result quickAttempt(Player player) {
        PlayerData data = cultivation.getPlayerData(player.getUniqueId());
        if (data.realm() == Realm.PHAM_NHAN) {
            player.sendMessage("§cBạn phải hoàn thành nhiệm vụ mở khóa Luyện Khí Tầng 1 trước.");
            return Result.CONDITIONS_FAILED;
        }
        if (data.realm() == Realm.LUYEN_KHI && data.realmStage() >= 10
                && data.linhKhi() >= data.nextLinhKhiStageThreshold()) {
            player.sendMessage("§cLuyện Khí Tầng 10 đã đầy Linh Khí: §f/dotpha nhanh §cđã bị khóa. Hãy dùng §e/dokiep§c.");
            return Result.CONDITIONS_FAILED;
        }
        if (data.linhKhi() < data.nextLinhKhiStageThreshold()) {
            player.sendMessage("§cChưa đủ Linh Khí. Cần §b" + data.nextLinhKhiStageThreshold() + "§c Linh Khí.");
            return Result.NOT_ENOUGH_LINHKHI;
        }
        if (data.canCot() < plugin.getConfig().getDouble("breakthrough.min-can-cot", 1D)
                || data.ngoTinh() < plugin.getConfig().getDouble("breakthrough.min-ngo-tinh", 1D)) {
            player.sendMessage("§cCăn Cốt hoặc Ngộ Tính chưa đạt điều kiện đột phá.");
            return Result.CONDITIONS_FAILED;
        }
        if (data.realmStage() >= data.realm().maxStage() && data.realm().next() == null) {
            return Result.NO_NEXT_REALM;
        }
        if (ThreadLocalRandom.current().nextDouble() > successRate(player)) {
            punish(player);
            return Result.FAIL;
        }

        double required = data.nextLinhKhiStageThreshold();
        double surplus = Math.max(0D, data.linhKhi() - required);
        if (data.realmStage() < data.realm().maxStage()) {
            data.realmStage(data.realmStage() + 1);
        } else {
            Realm next = data.realm().next();
            if (next == null) return Result.NO_NEXT_REALM;
            data.realm(next);
            data.realmStage(1);
        }
        data.linhKhi(surplus);
        data.incrementBreakthroughCount();
        data.addSpiritRootRolls(1);
        applyPermanentStats(player);
        healForBreakthrough(player);
        cultivation.save(player.getUniqueId());

        // Chính xác 10 tim. Nếu có tim vàng/Absorption thì trừ tim vàng trước, giống cơ chế cứu mạng.
        double damage = plugin.getConfig().getDouble("breakthrough.quick.damage-hearts", 10D) * 2D;
        applyExactDamageWithAbsorption(player, damage);

        player.sendTitle("§b§l✦ ĐỘT PHÁ NHANH ✦", "§f" + data.realmDisplay(), 5, 45, 10);
        player.sendMessage("§b✦ Đột phá nhanh thành công: §f" + data.realmDisplay());
        player.sendMessage("§7Bạn nhận §a+1 lượt Roll Linh Căn §7và chịu §c10 tim §7sát thương.");
        player.playSound(player, Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.35f);
        return Result.SUCCESS;
    }

    private void applyExactDamageWithAbsorption(Player player, double damage) {
        if (damage <= 0 || player.isDead()) return;
        double absorption = player.getAbsorptionAmount();
        double absorbed = Math.min(absorption, damage);
        player.setAbsorptionAmount(Math.max(0D, absorption - absorbed));
        double remaining = damage - absorbed;
        if (remaining <= 0) return;
        double health = player.getHealth();
        if (remaining >= health) {
            player.setHealth(0D);
        } else {
            player.setHealth(health - remaining);
        }
    }

    /** Called by TribulationSystem only after all 9 waves have been survived. */
    public Result resolveTribulation(Player player, Realm ignoredTarget) {
        PlayerData data = cultivation.getPlayerData(player.getUniqueId());

        if (tribulation.consumeFinalAscent(player.getUniqueId())) {
            Realm next = data.realm().next();
            double surplus = Math.max(0D, data.linhKhi() - data.nextLinhKhiStageThreshold());
            data.finalTribulationPassed(true);
            if (next != null) {
                data.incrementBreakthroughCount();
                data.addSpiritRootRolls(1);
                applyPermanentStats(player);
                healForBreakthrough(player);
                data.realm(next);
                data.realmStage(1);
                // Không làm mất Linh Khí dư sau lần Độ Kiếp cuối.
                data.linhKhi(surplus);
                player.sendTitle("§d§l✦ PHI THĂNG THÀNH CÔNG ✦", "§f" + data.realmDisplay(), 10, 70, 20);
                player.sendMessage("§d✦ Cửu Lôi Độ Kiếp cuối đã hoàn thành! §7Bạn đã bước vào §f" + data.realmDisplay() + "§7.");
            } else {
                player.sendMessage("§d✦ Cửu Lôi Độ Kiếp cuối đã hoàn thành. §7Bạn đã đạt cảnh giới tối cao hiện tại.");
            }
            cultivation.save(player.getUniqueId());
            return Result.SUCCESS;
        }

        if (ThreadLocalRandom.current().nextDouble() > successRate(player)) {
            punish(player);
            return Result.FAIL;
        }

        // Preserve all Linh Khí dư khi đột phá.
        // Ví dụ: 1725/1700 -> đột phá -> 25 Linh Khí được giữ lại.
        double required = data.nextLinhKhiStageThreshold();
        double surplus = Math.max(0D, data.linhKhi() - required);

        if (data.realmStage() < data.realm().maxStage()) {
            data.realmStage(data.realmStage() + 1);
            data.linhKhi(surplus);
        } else {
            Realm next = data.realm().next();
            if (next == null) return Result.NO_NEXT_REALM;
            data.realm(next);
            data.realmStage(1);
            data.linhKhi(surplus);
        }

        data.incrementBreakthroughCount();
        data.addSpiritRootRolls(1);
        applyPermanentStats(player);
        healForBreakthrough(player);
        cultivation.save(player.getUniqueId());
        player.sendTitle("§6§l✦ ĐỘT PHÁ THÀNH CÔNG ✦", "§f" + data.realmDisplay(), 10, 60, 20);
        player.sendMessage("§a✦ Cửu Lôi đã tôi luyện đạo cơ. Bạn đã đột phá thành §f" + data.realmDisplay() + "§a.");
        player.playSound(player, Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.25f);
        tribulation.breakthroughStorm(player);
        return Result.SUCCESS;
    }

    /** Áp dụng toàn bộ chỉ số vĩnh viễn theo số lần đột phá thành công. */
    public void applyPermanentStats(Player player) {
        PlayerData data = cultivation.getPlayerData(player.getUniqueId());
        int count = data.breakthroughCount();
        if (count <= 0) return;

        addOrReplaceModifier(player, Attribute.MAX_HEALTH, "tutien_breakthrough_health", count * plugin.getConfig().getDouble("breakthrough.stats.health-per-breakthrough", 2.0D), AttributeModifier.Operation.ADD_NUMBER);
        addOrReplaceModifier(player, Attribute.MOVEMENT_SPEED, "tutien_breakthrough_speed", count * plugin.getConfig().getDouble("breakthrough.stats.speed-per-breakthrough", 0.01D), AttributeModifier.Operation.ADD_SCALAR);
        applyPermanentFlightSpeed(player, count);
        addOrReplaceModifier(player, Attribute.ATTACK_DAMAGE, "tutien_breakthrough_attack", count * plugin.getConfig().getDouble("breakthrough.stats.attack-damage-per-breakthrough", 1.0D), AttributeModifier.Operation.ADD_NUMBER);

        // Sức mạnh II vĩnh viễn sau khi đã có ít nhất một lần đột phá.
        int amplifier = Math.max(0, plugin.getConfig().getInt("breakthrough.stats.strength-amplifier", 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, amplifier, false, false, true));

        player.setHealth(Math.min(player.getHealth(), player.getAttribute(Attribute.MAX_HEALTH).getValue()));
        player.sendHealthUpdate();
    }

    private void applyPermanentFlightSpeed(Player player, int count) {
        double base = plugin.getConfig().getDouble("breakthrough.stats.base-fly-speed", 0.10D);
        double per = plugin.getConfig().getDouble("breakthrough.stats.flying-speed-per-breakthrough", 0.005D);
        float speed = (float) Math.max(0.05D, Math.min(1.0D, base + count * per));
        player.setFlySpeed(speed);
    }

    private void healForBreakthrough(Player player) {
        AttributeInstance max = player.getAttribute(Attribute.MAX_HEALTH);
        if (max == null) return;
        double heal = plugin.getConfig().getDouble("breakthrough.stats.health-per-breakthrough", 2.0D);
        player.setHealth(Math.min(max.getValue(), player.getHealth() + heal));
    }

    private void addOrReplaceModifier(Player player, Attribute attribute, String name, double amount, AttributeModifier.Operation operation) {
        AttributeInstance instance = player.getAttribute(attribute);
        if (instance == null) return;
        for (AttributeModifier old : instance.getModifiers()) {
            if (name.equals(old.getName())) instance.removeModifier(old);
        }
        UUID uuid = UUID.nameUUIDFromBytes((player.getUniqueId() + ":" + name).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        instance.addModifier(new AttributeModifier(uuid, name, amount, operation));
    }

    private double successRate(Player player) {
        PlayerData data = cultivation.getPlayerData(player.getUniqueId());
        double rate = plugin.getConfig().getDouble("breakthrough.base-success-rate", 0.80D);
        rate *= 1D + (data.canCot() - 1D) / 200D;
        rate *= 1D + (data.ngoTinh() - 1D) / 200D;
        // Nhân quả V3: Công Đức hỗ trợ độ kiếp, Nghiệp Lực làm giảm tỷ lệ thành công.
        rate += Math.min(0.15D, data.congDuc() / 10000D);
        rate -= Math.min(0.35D, data.nghiepLuc() / 5000D);
        return Math.max(0.05D, Math.min(0.98D, rate));
    }

    private void punish(Player player) {
        PlayerData data = cultivation.getPlayerData(player.getUniqueId());
        double loss = plugin.getConfig().getDouble("breakthrough.tau-hoa-loss-percent", 0.20D);
        long keep = Math.max(0, (long) (data.linhKhi() * (1D - loss)));
        data.linhKhi(keep);

        int seconds = plugin.getConfig().getInt("breakthrough.tau-hoa-duration-seconds", 20);
        player.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, seconds * 20, 0));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, seconds * 20, 0));
        cultivation.save(player.getUniqueId());

        player.sendTitle("§4§lTẨU HỎA NHẬP MA", "§cĐột phá thất bại", 10, 50, 10);
        player.sendMessage("§c✦ Tẩu Hỏa Nhập Ma! §7Linh Khí bị tổn thất và cơ thể suy yếu.");
        player.playSound(player, Sound.BLOCK_ANVIL_LAND, 1f, 0.65f);
    }
}
