package com.tcgame.tutiencore.ngukiem;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Độn Thuật: một lệnh /donthuat, bay theo hướng nhìn, tự hủy khi sneak hoặc chạm đất. */
public final class NguKiemService implements Listener {
    private final TuTienCore plugin;
    private final Map<UUID, BukkitTask> active = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> previousAllowFlight = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> previousFlying = new ConcurrentHashMap<>();
    private final Map<UUID, Long> startedAt = new ConcurrentHashMap<>();
    private final Map<String, Long> cooldowns = new ConcurrentHashMap<>();

    public NguKiemService(TuTienCore plugin) { this.plugin = plugin; }

    public boolean isFlying(Player player) { return active.containsKey(player.getUniqueId()); }
    public void toggle(Player player) { if (isFlying(player)) stop(player, true); else start(player); }

    public void start(Player player) {
        if (!plugin.getConfig().getBoolean("don-thuat.enabled", true) || isFlying(player)) return;
        UUID id = player.getUniqueId();
        previousAllowFlight.put(id, player.getAllowFlight());
        previousFlying.put(id, player.isFlying());
        startedAt.put(id, System.currentTimeMillis());
        player.setAllowFlight(true);
        player.setFlying(false);
        player.setFallDistance(0);
        player.sendMessage("§b✦ Độn Thuật §fđã khởi động. §7Shift hoặc chạm đất để kết thúc.");
        player.playSound(player.getLocation(), Sound.ITEM_TRIDENT_RIPTIDE_3, 0.9f, 1.0f);

        long period = Math.max(1L, plugin.getConfig().getLong("don-thuat.tick-period", 1L));
        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline() || player.isDead()) { stop(player, false); return; }
            if (player.isSneaking()) { stop(player, true); return; }

            Vector direction = player.getEyeLocation().getDirection();
            if (direction.lengthSquared() < 0.0001D) direction = new Vector(0, 0, 1);
            direction.normalize();

            PlayerData data = plugin.getCultivationService().getPlayerData(id);
            int breakthroughs = data.breakthroughCount();
            double base = plugin.getConfig().getDouble("don-thuat.speed", 1.25D);
            double perBreakthrough = plugin.getConfig().getDouble("don-thuat.speed-per-breakthrough", 0.06D);
            double speed = base + (breakthroughs * perBreakthrough);
            player.setVelocity(direction.multiply(speed));
            player.setFallDistance(0);
            if (!player.getAllowFlight()) player.setAllowFlight(true);

            Vector back = direction.clone().multiply(-0.75);
            Location tail = player.getLocation().clone().add(0, 0.35, 0).add(back);
            player.getWorld().spawnParticle(Particle.CLOUD, tail, 2, 0.12, 0.08, 0.12, 0.01);
            player.getWorld().spawnParticle(Particle.END_ROD, tail, 1, 0.06, 0.06, 0.06, 0.01);
            double spin = (System.currentTimeMillis() % 3600L) / 3600.0 * Math.PI * 2.0;
            for (int ring = 0; ring < 4; ring++) {
                double a = spin + ring * (Math.PI / 2.0);
                Location orbit = player.getLocation().clone().add(Math.cos(a) * 0.7, 0.25 + Math.sin(a * 2.0) * 0.12, Math.sin(a) * 0.7);
                player.getWorld().spawnParticle(Particle.END_ROD, orbit, 1, 0, 0, 0, 0);
            }
        }, 0L, period);
        active.put(id, task);
    }

    /** Stop and create exactly one visual explosion burst; no actual explosion damage. */
    public void stop(Player player, boolean visualBurst) {
        UUID id = player.getUniqueId();
        BukkitTask task = active.remove(id);
        if (task != null) task.cancel();
        startedAt.remove(id);
        player.setVelocity(new Vector(0, 0, 0));
        Boolean allow = previousAllowFlight.remove(id);
        Boolean flying = previousFlying.remove(id);
        if (allow != null) player.setAllowFlight(allow);
        if (flying != null && player.getAllowFlight()) player.setFlying(flying);
        player.setFallDistance(0);
        if (visualBurst && player.isOnline()) {
            Location at = player.getLocation().clone().add(0, 0.8, 0);
            player.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, at, 1);
            player.getWorld().spawnParticle(Particle.CLOUD, at, 12, 0.35, 0.25, 0.35, 0.08);
            player.playSound(at, Sound.ENTITY_GENERIC_EXPLODE, 0.45f, 1.35f);
        }
        if (player.isOnline()) player.sendMessage("§7✦ Độn Thuật §fđã kết thúc.");
    }

    public void stop(Player player) { stop(player, true); }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent event) {
        if (event.isSneaking() && isFlying(event.getPlayer())) stop(event.getPlayer(), true);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player p = event.getPlayer();
        if (!isFlying(p)) return;
        // Give the launch tick a moment before checking the original ground state.
        long started = startedAt.getOrDefault(p.getUniqueId(), 0L);
        if (System.currentTimeMillis() - started < 250L) return;
        if (p.isOnGround()) stop(p, true);
    }

    public boolean useSkill(Player p, String raw) {
        String skill = raw == null ? "" : raw.toLowerCase(Locale.ROOT);
        if (!isFlying(p)) { p.sendMessage("§cHãy bật /donthuat trước khi dùng skill."); return false; }
        long now = System.currentTimeMillis();
        String key = p.getUniqueId() + ":" + skill;
        long ready = cooldowns.getOrDefault(key, 0L);
        if (now < ready) { p.sendMessage("§cSkill đang hồi: §f" + ((ready - now + 99) / 1000.0) + "s"); return false; }

        int count = plugin.getConfig().getInt("don-thuat.skills." + skill + ".cooldown-seconds", 4);
        cooldowns.put(key, now + Math.max(1, count) * 1000L);
        Vector dir = p.getEyeLocation().getDirection().normalize();
        Location at = p.getLocation().clone().add(0, 0.8, 0);
        switch (skill) {
            case "phi-hanh", "phihanh" -> {
                p.setVelocity(dir.multiply(2.8 + plugin.getCultivationService().getPlayerData(p.getUniqueId()).breakthroughCount() * 0.08));
                p.getWorld().spawnParticle(Particle.CLOUD, at, 24, 0.35, 0.25, 0.35, 0.12);
                p.playSound(at, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 0.8f, 1.6f);
            }
            case "luu-quang", "luuquang" -> {
                p.setVelocity(dir.multiply(4.0).add(new Vector(0, 0.15, 0)));
                p.getWorld().spawnParticle(Particle.END_ROD, at, 28, 0.25, 0.25, 0.25, 0.08);
                p.playSound(at, Sound.ENTITY_ENDER_DRAGON_FLAP, 0.5f, 1.8f);
            }
            case "thang-thien", "thangthien" -> {
                p.setVelocity(new Vector(0, 2.2, 0).add(dir.multiply(0.25)));
                p.getWorld().spawnParticle(Particle.CLOUD, at, 20, 0.3, 0.4, 0.3, 0.08);
                p.playSound(at, Sound.ENTITY_PHANTOM_FLAP, 0.7f, 1.2f);
            }
            case "hoan-luu", "hoanluu" -> {
                p.setVelocity(dir.multiply(0.15));
                p.getWorld().spawnParticle(Particle.SWEEP_ATTACK, at, 8, 0.5, 0.25, 0.5, 0);
                p.playSound(at, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.8f, 1.5f);
            }
            case "phong-ba", "phongba" -> {
                for (int i = 0; i < 3; i++) {
                    double a = i * Math.PI * 2 / 3.0;
                    p.getWorld().spawnParticle(Particle.CLOUD, at.clone().add(Math.cos(a), 0, Math.sin(a)), 10, 0.15, 0.15, 0.15, 0.05);
                }
                p.playSound(at, Sound.ENTITY_WIND_CHARGE_WIND_BURST, 0.8f, 1.0f);
            }
            case "thien-mon", "thienmon" -> {
                Vector target = dir.clone().multiply(6.0);
                p.teleport(p.getLocation().add(target));
                p.getWorld().spawnParticle(Particle.PORTAL, p.getLocation(), 36, 0.5, 0.6, 0.5, 0.2);
                p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.7f, 1.4f);
            }
            case "tinh-van", "tinhvan" -> {
                p.getWorld().spawnParticle(Particle.END_ROD, at, 36, 0.7, 0.4, 0.7, 0.12);
                p.getWorld().spawnParticle(Particle.ENCHANT, at, 30, 0.8, 0.5, 0.8, 0.25);
                p.playSound(at, Sound.BLOCK_BEACON_AMBIENT, 0.7f, 1.8f);
            }
            default -> { cooldowns.remove(key); p.sendMessage("§cKhông có skill đó. §7/donthuat skills"); return false; }
        }
        p.sendMessage("§d✦ Độn Thuật Skill: §f" + skill);
        return true;
    }

    public void sendSkills(Player p) {
        p.sendMessage("§b§l✦ ĐỘN THUẬT — SKILLS ✦");
        p.sendMessage("§f/donthuat §7- bật/tắt bay");
        p.sendMessage("§f/donthuat skill phi-hanh §7- lướt nhanh");
        p.sendMessage("§f/donthuat skill luu-quang §7- lao cực tốc");
        p.sendMessage("§f/donthuat skill thang-thien §7- vọt lên");
        p.sendMessage("§f/donthuat skill hoan-luu §7- hãm tốc");
        p.sendMessage("§f/donthuat skill phong-ba §7- vòng gió đẩy lùi");
        p.sendMessage("§f/donthuat skill thien-mon §7- dịch chuyển 6 block");
        p.sendMessage("§f/donthuat skill tinh-van §7- bùng particle");
    }

    public void shutdown() {
        for (UUID id : active.keySet()) {
            Player p = plugin.getServer().getPlayer(id);
            if (p != null) stop(p, false);
            else {
                BukkitTask task = active.remove(id);
                if (task != null) task.cancel();
                previousAllowFlight.remove(id); previousFlying.remove(id); startedAt.remove(id);
            }
        }
        active.values().forEach(BukkitTask::cancel);
        active.clear(); previousAllowFlight.clear(); previousFlying.clear(); startedAt.clear(); cooldowns.clear();
    }
}
