package com.tcgame.tutiencore.spiritroot;

import com.tcgame.tutiencore.TuTienCore;
import com.tcgame.tutiencore.api.PlayerData;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class SpiritRootRerollService {
    private final TuTienCore plugin;
    public SpiritRootRerollService(TuTienCore plugin) { this.plugin = plugin; }

    public void setDefault(PlayerData data) {
        data.spiritRootQuality(SpiritRootQuality.NGUY_LINH_CAN);
        data.spiritRoots(List.of(SpiritRootType.KIM, SpiritRootType.MOC, SpiritRootType.THUY, SpiritRootType.HOA, SpiritRootType.THO));
        data.spiritRoot(SpiritRootType.NGU_HANH);
    }

    public SpiritRootQuality reroll(PlayerData data) {
        SpiritRootQuality q = rollQuality();
        data.spiritRootQuality(q);
        if (q == SpiritRootQuality.BIEN_DI) { data.spiritRoot(SpiritRootType.BIEN_DI); data.spiritRoots(List.of()); return q; }
        List<SpiritRootType> c = new ArrayList<>(List.of(SpiritRootType.KIM, SpiritRootType.MOC, SpiritRootType.THUY, SpiritRootType.HOA, SpiritRootType.THO));
        Collections.shuffle(c);
        List<SpiritRootType> selected = new ArrayList<>(c.subList(0, q.rootCount()));
        data.spiritRoots(selected);
        data.spiritRoot(selected.size() == 1 ? selected.get(0) : SpiritRootType.NGU_HANH);
        return q;
    }

    private SpiritRootQuality rollQuality() {
        double total = 0D;
        for (SpiritRootQuality q : SpiritRootQuality.values()) total += weight(q);
        double roll = ThreadLocalRandom.current().nextDouble(total);
        double cursor = 0D;
        for (SpiritRootQuality q : SpiritRootQuality.values()) { cursor += weight(q); if (roll < cursor) return q; }
        return SpiritRootQuality.NGUY_LINH_CAN;
    }

    public double weight(SpiritRootQuality q) {
        return Math.max(0D, plugin.getConfig().getDouble("initiation.reroll.quality-weights." + q.name(), 1D));
    }

    public double weightPercent(SpiritRootQuality q) {
        double total = 0D; for (SpiritRootQuality value : SpiritRootQuality.values()) total += weight(value);
        return total <= 0D ? 0D : weight(q) * 100D / total;
    }
}
