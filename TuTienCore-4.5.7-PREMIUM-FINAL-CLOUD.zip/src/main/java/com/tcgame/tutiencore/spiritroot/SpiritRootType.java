package com.tcgame.tutiencore.spiritroot;

public enum SpiritRootType {
    KIM("Kim"), MOC("Mộc"), THUY("Thủy"), HOA("Hỏa"), THO("Thổ"),
    NGU_HANH("Ngũ Hành"), BIEN_DI("Biến Dị");
    private final String displayName;
    SpiritRootType(String displayName) { this.displayName = displayName; }
    public String displayName() { return displayName; }
    public static SpiritRootType byName(String s) {
        for (SpiritRootType r : values()) if (r.name().equalsIgnoreCase(s) || r.displayName().equalsIgnoreCase(s)) return r;
        return null;
    }
}
