package com.tcgame.tutiencore.spiritroot;

/** Chất lượng linh căn và hệ số tốc độ tu luyện. */
public enum SpiritRootQuality {
    NGUY_LINH_CAN("Ngụy Linh Căn", 5, 2.0D),
    HA_PHAM("Hạ Phẩm", 4, 4.0D),
    TRUNG_PHAM("Trung Phẩm", 3, 8.0D),
    CAO_PHAM("Cao Phẩm", 2, 16.0D),
    THIEN_PHAM("Thiên Phẩm", 1, 32.0D),
    BIEN_DI("Biến Dị", 0, 64.0D);

    private final String displayName;
    private final int rootCount;
    private final double trainingMultiplier;

    SpiritRootQuality(String displayName, int rootCount, double trainingMultiplier) {
        this.displayName = displayName;
        this.rootCount = rootCount;
        this.trainingMultiplier = trainingMultiplier;
    }
    public String displayName() { return displayName; }
    public int rootCount() { return rootCount; }
    public double trainingMultiplier() { return trainingMultiplier; }
    public static SpiritRootQuality byName(String s) {
        if (s == null) return null;
        for (SpiritRootQuality q : values()) if (q.name().equalsIgnoreCase(s) || q.displayName().equalsIgnoreCase(s)) return q;
        return null;
    }
}
