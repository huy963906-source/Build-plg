# TuTienCore 4.5.6 PREMIUM — requested gameplay patch

- Added `/tongmon disband` (aliases `giaitan`, `huy`) restricted to the sect owner; attempts to clear members' sect IDs, remove known core blocks, and remove the WorldGuard claim.
- `/linhthu` and `/pet` without arguments now open a Linh Thú GUI; owned pets can be mounted and unowned configured pets can be purchased by clicking.
- Standardized class skill cooldown to 3 seconds.
- Increased particle count and added End Rod, Critical, Flash and attack-sweep sound to class skill impacts; still uses vanilla particles, no resource pack/model required.
- Breakthrough health and movement-speed modifiers already existed in this source and continue to scale with breakthrough count.

Build status: source edits only. Maven compilation and live Paper 1.21.11 testing have NOT yet been completed. The requested four-input M1/M2/Shift bindings are not yet implemented in this patch and must not be treated as complete.
