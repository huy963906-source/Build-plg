# TuTienCore 4.5.4-PREMIUM — local license activation

## Activation
Run from the Minecraft server console:

`ttlicense activate TTCPLG-TAJS-YWIA`

or another unconsumed customer key. Then restart the server. Check with:

`ttlicense status`

The customer key is removed from `license.available-keys` in `plugins/TuTienCoreCultivationCore/config.yml` when activation succeeds. The activated key and a server fingerprint are stored in that config. The admin key `TTCPLG-ZYAS-DEPTRAI` is accepted as a special key and is not part of the customer pool.

## Reset
There is intentionally no public reset command. If the server is moved or its fingerprint changes, contact zyas on Discord `qhuy963906` for review/reset instructions.

## Important security limitation
This is a local/offline license gate. The key pool is embedded in the plugin's default config and can be extracted by a determined person. Copying a fresh JAR/default config to another server can reproduce unused keys. Reliable global one-time activation requires a central online license service. Do not market this local build as tamper-proof.
